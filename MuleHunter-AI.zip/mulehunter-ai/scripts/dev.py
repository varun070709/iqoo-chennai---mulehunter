#!/usr/bin/env python3
"""Start both local services with one command after installing dependencies.

Usage: python scripts/dev.py [--check] [--production]
The parent forwards shutdown to both subprocess groups. Never runs migrations
against external systems; the backend seeds its own fictional SQLite database.
"""

import argparse
import importlib.util
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]


def prerequisites():
    missing = [
        m
        for m in [
            "fastapi",
            "uvicorn",
            "sqlalchemy",
            "networkx",
            "sklearn",
            "reportlab",
        ]
        if not importlib.util.find_spec(m)
    ]
    if missing:
        raise SystemExit(
            "Missing Python dependencies: "
            + ", ".join(missing)
            + "\nActivate your virtual environment and run: pip install -r requirements.txt"
        )
    npm = shutil.which("npm")
    if not npm:
        raise SystemExit("Node.js 20+ and npm are required.")
    if not (ROOT / "frontend" / "node_modules").is_dir():
        raise SystemExit(
            "Frontend dependencies are missing. Run: cd frontend && npm ci"
        )
    return npm


def main():
    parser = argparse.ArgumentParser(
        description="MuleHunter AI local workspace launcher"
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Check dependencies without starting servers",
    )
    parser.add_argument(
        "--production",
        action="store_true",
        help="Build and preview the optimized frontend",
    )
    args = parser.parse_args()
    npm = prerequisites()
    if args.check:
        print("Dependencies ready. Run: python scripts/dev.py")
        return
    if args.production:
        subprocess.run([npm, "run", "build"], cwd=ROOT / "frontend", check=True)
    commands = [
        (
            [
                sys.executable,
                "-m",
                "uvicorn",
                "app.main:app",
                "--host",
                "0.0.0.0",
                "--port",
                "8000",
            ],
            ROOT / "backend",
        ),
        ([npm, "run", "preview" if args.production else "dev"], ROOT / "frontend"),
    ]
    processes = []
    try:
        for command, cwd in commands:
            kwargs = (
                {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}
                if os.name == "nt"
                else {"start_new_session": True}
            )
            processes.append(subprocess.Popen(command, cwd=cwd, **kwargs))
        print(
            "\nMuleHunter AI: http://localhost:5173\nLanding: http://localhost:5173/welcome\nAPI: http://localhost:8000/docs\nCtrl+C stops both services.\n",
            flush=True,
        )
        while all(p.poll() is None for p in processes):
            time.sleep(0.5)
    except KeyboardInterrupt:
        print("\nStopping the synthetic intelligence workspace…", flush=True)
    finally:
        for process in processes:
            if process.poll() is not None:
                continue
            try:
                if os.name == "nt":
                    process.send_signal(signal.CTRL_BREAK_EVENT)
                else:
                    os.killpg(process.pid, signal.SIGTERM)
                process.wait(timeout=8)
            except (ProcessLookupError, subprocess.TimeoutExpired):
                process.kill()


if __name__ == "__main__":
    main()
