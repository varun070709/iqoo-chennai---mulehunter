# Intelligence methodology

## Scope

MuleHunter AI implements transparent, local experiments over fictional account and payment data. It is a decision-support prototype, not a validated fraud classifier, AML compliance service or real-time banking gateway.

The detector receives account metadata and payment facts. The `Transaction.scenario` audit column is deliberately omitted when payment rows are loaded into the detector. A regression test changes synthetic scenario labels and confirms identical risk outputs.

## Observational windows

| Signal | Window / interpretation |
|---|---|
| Account amounts, transaction counts, counterparties | Stored ledger context |
| Velocity and fan-in/fan-out | Last 20 minutes |
| Active graph | Last hour, payments of at least INR 2,000 |
| Temporal forwarding and cash-out | Last hour |
| Average transaction spacing | Recent active hour if it has at least two payments; otherwise the stored account history |
| Network explorer | User-selected 1, 6 or 24 hours; API permits longer windows |
| Command-center activity chart | Twelve hourly buckets, labeled in IST |
| Ledger default | Payments with event times in the last 24 hours, sorted by ingestion ID |

Storage/event timestamps use UTC. The UI formats event times in `Asia/Kolkata`. Newly ingested backdated simulation transfers can appear above newer event times in the live feed because that feed represents ingestion order.

## Behavioral models

The feature vector is:

1. average transaction amount;
2. transaction count in the recent 20-minute window;
3. unique stored counterparties;
4. incoming/outgoing value ratio;
5. average transaction interval;
6. degree centrality;
7. sampled betweenness centrality;
8. recent fan-in score;
9. recent fan-out score;
10. network exposure.

`AnomalyModel` creates 2,400 synthetic normal reference observations and 2,400 synthetic anomalous observations. A RobustScaler and 80-tree Isolation Forest are fitted on the normal reference. A 72-tree, depth-limited Random Forest is fitted on the combined synthetic populations. Both use random seed 42.

Isolation Forest's decision function is transformed monotonically into a bounded 0–100 anomaly score. `normality_score` is its complement, not an independently calibrated probability. The Random Forest class estimate is returned as `fraud_probability` for API compatibility, with an explicit warning that it is synthetic and uncalibrated. Behavioral risk combines these outputs at 55% / 45%.

The first pass has zero propagated exposure and is used to select network-risk sources. A second model prediction includes computed exposure. Sources remain fixed to the first pass, preventing an unbounded model/propagation feedback loop.

This is not a claim of real-world accuracy, discrimination, calibration, robustness or predictive value. The rule-derived features and model inputs are correlated; weighting does not make them statistically independent.

## Velocity

`velocity_risk = min(100, recent_count × 7 + burst_bonus)`.

The burst bonus is 25 when there are at least six recent payments and the recent average spacing is below 90 seconds. Velocity alone contributes at most 20 points to final account risk.

## Graph intelligence

NetworkX builds a directed graph with aggregated account-pair amounts, payment counts and most recent event time. It computes:

- degree centrality;
- approximate betweenness, with at most 40 sampled pivots and seed 42;
- weighted Louvain communities on an undirected view;
- weakly connected components;
- bounded directed cycles in the active graph;
- recent fan-in and fan-out structure.

The aggregate graph used for communities and centrality covers stored payments. Active-cycle, propagation and ring analysis use the time-local graph. Community edge weight is a square-root transformation of transfer value; it is a heuristic, not a formally calibrated graph likelihood.

Each unique incoming or outgoing peer in the last 20 minutes contributes 12.5 points to its corresponding fan score, capped at 100. Account graph risk combines the stronger fan signal or a detected-cycle signal with a small activity term. The complete module is capped at 100.

Cycle search covers directed cycles of two to four accounts and is capped at 150, with a share of the budget allocated to each cyclic strongly connected component. It is not exhaustive over all lengths or all dense-network cycles. The `circular_transaction_probability` field is 90 for an observed short cycle and 0 otherwise: an explicitly labeled heuristic propensity, not a probability.

## Temporal forwarding

The temporal analyzer processes incoming and outgoing events chronologically for each account. It maintains a FIFO queue of unmatched incoming amounts. Outgoing value consumes pending incoming value, and each incoming unit can be matched only once.

A match counts as rapid when an outgoing transfer follows its matched incoming value within five minutes. The rapid-forwarding ratio is bounded to `[0, 1]`. A separate simulated cash-out amount signal can increase temporal risk.

FIFO is a flow heuristic. It does not model actual available balances, legal ownership, customer intent or commingled funds, and it is not forensic proof that identical funds followed a particular path.

## Multi-hop candidates

Chronological path search requires:

- transfers of at least INR 2,000;
- two to five hops;
- strictly forward event time;
- no more than five minutes between successive hops;
- each next transfer worth at least 25% of the previous transfer;
- no reuse of the same transaction within a candidate chain.

The search is limited to 16 returned paths, at most 100 outgoing candidates per account, and 6,000 search visits. Returned paths are sorted by hop count. Different paths can overlap; minimum hop value is displayed as a useful bound, not as verified traced proceeds.

## Risk propagation

First-pass independent account scores are normalized without the exposure layer. Accounts at or above 62 in that first-pass scale can be sources.

On the active undirected graph, each link receives strength from:

- 30% normalized payment frequency;
- 35% normalized transferred value;
- 35% exponentially decayed recency.

Strength is multiplied along candidate paths and decays by 0.66 at every hop. Influence is bounded to three hops and capped at 100 aggregate exposure. Existing source risk controls signal strength. The strongest supported path updates are retained while avoiding endless cyclic amplification.

The UI stores/displays the top eight source-provenance entries per account. A displayed source contribution is not exhaustive Shapley-style attribution. Exposure is context, not guilt by association, and has only 15% final weight.

## Account scoring

```text
risk = round(0.25 × behavior
           + 0.20 × velocity
           + 0.25 × graph
           + 0.15 × temporal
           + 0.15 × exposure)
```

All components and the final result are bounded to 0–100. Categories are SAFE 0–30, SUSPICIOUS 31–60, HIGH RISK 61–80, and CRITICAL 81–100.

Evidence is generated from measured conditions: recent peer counts and amounts, transaction frequency, time spacing, FIFO forwarding, cycles, cash-out amount, current high-risk neighbors and model deviation. Statements sharing a module share its weighted contribution; summing evidence-item points would overcount.

Recommendations are threshold-dependent labels for human review: Monitor, Request Additional Verification, Temporarily Flag, or Escalate for Investigation. They never execute those actions.

## Transaction scoring

Transaction risk is based on 90% of the larger current endpoint score plus a bounded amount contribution. An unusually large transfer above both INR 200,000 and five times the lower endpoint's average transfer value uses a 25-point extreme-value contribution and records an additional flag. The result is clamped and categorized.

Consequently transaction risk and account risk can differ. Historical transaction scores are re-evaluated using current network context; they are not immutable observations of risk at original event time.

## Potential fraud rings

Ring candidates are built from active connections among accounts scoring at least 50. Small weakly connected components are evaluated directly; large components are subdivided using Louvain communities.

A potential ring must have:

- at least three members;
- average account risk of at least 48;
- internal transferred volume of at least INR 50,000;
- at least two independent *types* of structural/behavioral condition: substantial directed density, a detected cycle, at least two rapid pass-through accounts, or at least three independently high-risk members.

Cluster risk combines average member risk and the count of observed signal types. “Average risk” and “cluster risk” are different fields. Cases preserve the maximum member account risk at creation, not necessarily the cluster score.

Simulation injection does not force a ring or a critical label. Incomplete motifs, low values or insufficient combined signals may legitimately remain below detection thresholds.

## Investigations and reports

Cases persist account scope, creation-time peak risk, creation-time structured evidence, analyst notes, local status, recommended review action and timestamps. The case network, current account table and payment trail are recomputed from current data; the UI labels the distinction.

Connected case volume counts each in-scope transaction once, but the same underlying funds can reappear at multiple hops. It is not net loss. A risk score or report must not be used as the sole basis for an adverse real-world decision.

## Scaling boundaries

The local engine deliberately favors interpretability and reproducibility over banking-scale throughput. It recomputes a guarded full-network snapshot after every analysis batch, using a single process-local event hub. It is limited to 2,000 accounts and 50,000 payments, and model latency includes full analysis/persistence rather than an individual payment's execution time.

A real deployment would require model validation, streaming feature stores, durable jobs/events, source-system integrations, transaction-time evidence snapshots, access control, monitoring and qualified compliance review. None of those assurances is implied by a successful synthetic demonstration.
