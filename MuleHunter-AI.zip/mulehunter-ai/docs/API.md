# HTTP and WebSocket API

Direct API root: `http://localhost:8000`.
Frontend proxy root: `http://localhost:5173/api` (or `http://localhost:8080/api` with Docker).

All bodies are JSON unless otherwise noted. Mutating operations that collide with an active analysis return **409**, validation errors return **422**, and missing entities return **404**. Wait for the current operation and retry a 409; do not submit duplicate attack jobs continuously.

## Read models

### `GET /dashboard`

Returns total stored transactions/accounts, non-safe transaction count, high-risk account count, active network count, gross potential exposure, measured average analysis-cycle duration, hourly activity, risk distributions, priority alerts, live stream state, attack progress and analysis version.

### `GET /transactions`

Parameters:

- `query`: partial transaction ID or endpoint ID, maximum 100 characters;
- `level`: `ALL`, `SAFE`, `SUSPICIOUS`, `HIGH RISK`, `CRITICAL`;
- `limit`: 1–500, default 50;
- `offset`: nonnegative, default 0;
- `hours`: 1–8,760, default 24.

Response: `{ "items": [transaction], "total": 123 }`.

Payments are ordered by descending ingestion ID. Each item contains the generated `transaction_id`, sender, receiver, positive INR amount, UTC event time, rail, simulated device/location, current score, category, explanatory flags and `synthetic: true`.

### `GET /transactions/export`

Downloads the entire stored ledger as CSV. This export is not limited by the ledger page's active search/risk filters. Scenario audit labels are not included.

### `GET /accounts`

Parameters: `query`, `level`, `limit` (1–2,000, default 100), `offset`.

Response: `{ "items": [account analysis], "total": 500 }`, sorted by descending risk and then ID.

### `GET /accounts/{account_id}`

Returns account metadata, score/category, behavioral and graph metrics, five module scores, weighted contributions, model output and caveat, deterministic explanation, normalized radar values, recent account transactions, current ring membership and bounded propagation provenance.

### `GET /network`

Parameters:

- `limit`: 1–2,000, default 90;
- `level`: risk category, default `ALL`;
- `hours`: 1–8,760, default 24;
- `focus`: optional existing account ID; selects the account and its directly connected neighbors.

Response contains nodes, aggregated directed edges, total account/transaction context, visible and aggregated edge counts, communities, connected components, bounded cycle count, ring count and version.

The default representative view includes detected ring members and influential reference accounts. An edge contains summed amount, payment count, highest current transaction score, most recent event time and representative rail. Only 1,500 aggregated edges are rendered; the complete transaction ledger remains available.

### `GET /fraud-rings`

Response: `{ "items": [ring], "total": 4 }`.

Ring fields include stable membership-derived ID, title, members, member count, mean member risk, cluster score, gross internal volume, directed density, observed reasons/patterns, highest-risk hub and analysis timestamp. Membership changes can produce a new ID and a separate case snapshot.

### `GET /flows?account_id=ACC-…`

Returns bounded, time-ordered candidate chains from the selected account. Each path has an ID, hop count, duration, minimum hop value, circular-return indicator and actual transaction events. The response includes detector assumptions and account-associated patterns.

### `GET /propagation/{account_id}`

Returns the one-hour, three-hop graph around the chosen source, up to 120 accounts. Nodes include distance, aggregate exposure and retained contribution from that source. `source_risk` and an interpretation caveat are included.

## Simulations

### `POST /simulate`

```json
{
  "action": "generate",
  "number_of_accounts": 500,
  "number_of_transactions": 5000,
  "fraud_percentage": 8,
  "transaction_speed": 1,
  "fraud_pattern": "fraud_ring"
}
```

- `action`: `generate`, `reset`, `start`, `stop`.
- Account count: 20–2,000.
- Transfer count: 20–20,000.
- Fraud percentage: 0–50.
- Speed: 0.2–10 target normal payments per second.
- Pattern: `normal`, `suspicious`, `mule`, `fraud_ring`, `fan_in`, `fan_out`, `circular`, `multi_hop`, `demo`.

**Generate/reset are destructive:** they replace accounts and transactions and delete existing investigation cases. The web UI asks for confirmation; API clients must provide their own confirmation workflow.

Generation honors an approximate motif share expressed as an exact integer number of labeled attack transfers, `floor(transactions × percentage / 100)`, by repeating/truncating generated motifs. The `normal` pattern has zero attack share. Truncation can remove the evidence needed for a ring.

For streaming, the percentage means **motif injection probability per analysis batch**, not a guaranteed fraction of individual transfers. Payments are generated in three-second batches at a target rate, subject to analysis time. `stop` pauses the stream and can cancel a staged demo attack; already committed transfers remain available for review.

Response contains an operation message and the current dashboard.

### `POST /simulate/inject-fraud`

```json
{ "pattern": "fan_in", "number_of_accounts": 12 }
```

Adds 8–15 new fictional accounts and the selected motif without clearing the existing network. Returns newly added account/transaction counts, the collector ID, member IDs, current rings and dashboard.

### `POST /simulate/demo-attack`

No request body needed. Returns **202** and starts a staged attack in a background task. Progress and completion are sent over WebSocket and available in `/dashboard`.

Only one mutating analysis operation runs at a time. On completion, the relevant connected cluster is evaluated, the highest-risk new account is identified, and available ring cases are persisted. These outcomes are computed rather than assigned from scenario labels.

## Analysis

### `POST /analyze/transaction`

```json
{
  "sender": "ACC-S001",
  "receiver": "ACC-S002",
  "amount": 25000,
  "transaction_type": "UPI",
  "persist": false
}
```

- Sender and receiver must exist and be distinct.
- Amount must be finite, positive and no more than INR 10,000,000.
- Rails: `UPI`, `IMPS`, `NEFT`, `WALLET`, `CASHOUT`.
- Optional `timestamp`: ISO-8601; UTC is preferred. It must be within the last year and not materially in the future.
- `persist` defaults to **true**. False runs against a copied candidate snapshot and changes neither ledger nor account analysis.

Response: `transaction`, `sender_analysis`, `receiver_analysis`, and `persisted`.

A non-persisted preview's candidate ID is provisional and is not reserved in the database.

### `POST /analyze/account`

```json
{ "account_id": "ACC-S001" }
```

Recomputes the full contextual network analysis and returns the selected account's updated profile.

## Cases and reports

### `GET /cases`

Returns `{ "items": [case] }`, newest cases first.

### `POST /cases`

```json
{
  "title": "Suspected mule account network",
  "account_ids": ["ACC-S001", "ACC-S002"],
  "ring_id": null
}
```

Creates a persisted case and returns **201**. Account scope must contain 1–200 existing IDs; title length is 3–160 characters. Creation captures the peak account score and that account's structured evidence. Current graph/account analysis remains separately available.

### `PATCH /cases/{case_id}`

```json
{
  "status": "in_review",
  "recommended_action": "Request Additional Verification",
  "notes": "Synthetic findings for investigator review."
}
```

Fields are optional. Status values: `open`, `in_review`, `escalated`, `closed`. Notes are limited to 8,000 characters. Recommended actions are `Monitor`, `Request Additional Verification`, `Temporarily Flag`, and `Escalate for Investigation`.

These are **local case records only**. Changing a label does not block an account, send a notification to a bank, or escalate outside the application.

### `GET /investigation/{case_id}`

Returns case metadata, captured evidence, current account analyses, gross connected volume, transaction count, up to 200 recent in-scope payment events, current graph and observed patterns.

### `GET /investigation/{case_id}/report`

Downloads a PDF generated from persisted case metadata/notes plus current in-scope analysis. Contains methodology and synthetic-data limitations. The PDF uses `INR` currency labels to avoid unsupported currency glyphs in standard PDF fonts.

## Operational endpoints

- `GET /health`: database/model/graph status, active WebSocket count, analysis version, dataset size and explicit demo authentication mode.
- `GET /docs`: interactive Swagger reference, with relative URLs compatible with direct and proxied access.
- `GET /openapi.json`: generated machine-readable schema.

The application frontend does not need external fonts/scripts. The optional Swagger UI loads its documentation assets from a CDN.

## WebSocket

Direct path: `/ws/live-transactions`.
Frontend path: `/api/ws/live-transactions`.

Connect using the current web origin:

```ts
const ws = new WebSocket(
  `${location.protocol === 'https:' ? 'wss:' : 'ws:'}//${location.host}/api/ws/live-transactions`
);
```

Representative event:

```json
{
  "type": "attack",
  "dashboard": { "version": 8, "total_accounts": 512 },
  "transactions": [],
  "progress": {
    "step": 3,
    "total_steps": 7,
    "title": "Fan-in detected",
    "complete": false
  }
}
```

The actual dashboard and transaction objects are complete snapshots, not the abbreviated example above. Event types include `connected`, `snapshot`, `simulation`, `injection`, `analysis`, `transaction`, `attack`, `attack_complete` and `error`.

Send the plain text `ping` periodically; the server responds `{ "type": "pong" }`. The application pings every 20 seconds and reconnects with bounded exponential backoff. Inactive connections are closed after a heartbeat timeout.

## Security boundary

No authentication is implemented. These endpoints can mutate and reset the fictional dataset. Use an isolated local demo environment; do not publish the API with real data or assume it implements financial authorization, regulatory access controls, transactional enforcement or durable distributed event delivery.
