# Verification record

Validated in the development workspace on **5 September 2026**.

## Environment

- Python 3.13.14
- Node.js 20.20.2 / npm 10.8.2
- SQLite / SQLAlchemy
- FastAPI / Uvicorn
- Vite production build served through its same-origin HTTP/WebSocket proxy
- Chromium browser automation with Playwright

## Results

| Check | Result |
|---|---|
| Python compile check | Passed |
| Backend pytest suite | **31 passed** |
| TypeScript + Vite production build | **Passed**, route/vendor code splitting enabled |
| Frontend Prettier check | Passed |
| Backend Black formatting check | Passed |
| Production-build browser interactions | **9 passed** |
| Desktop page-route smoke check | All product routes loaded without runtime errors |
| Mobile route/overflow check | No unintended horizontal page overflow at 390 px |
| Direct and proxied OpenAPI document | Passed |
| Generated PDF content/download | Passed; valid `%PDF-` document |
| Local launcher dependency check | Passed |
| Compose YAML / referenced Dockerfile check | Passed |
| Docker container build/run | **Not executed**; Docker runtime unavailable in this workspace |

### Backend coverage

The suite exercises risk boundaries and clamping, additive weighting, FIFO value conservation, chronological path direction and value continuity, graph cycles/components/propagation, exact dataset sizes, all eight generator patterns, exclusion of scenario labels from inference, model output bounds, API pagination and validation, account DNA, graph filters, non-mutating transaction preview, persisted ingestion, case creation/update, reports, CSV export, mutation validation and the staged WebSocket attack.

The backend suite runs against a temporary SQLite database and does not overwrite the running workspace dataset.

### Browser coverage

1. Real dashboard metrics, rendered account graph and WebSocket transport.
2. Critical-risk filtering, node interaction, Fraud DNA and structured evidence tabs.
3. Global account search, focused network views and zoom/fit controls.
4. Money-flow playback, pause and reset.
5. Case creation, stored notes across reload, local escalation, recommendation recording and PDF download.
6. Manual payment analysis/ingestion, reset confirmation cancellation and fan-in injection.
7. A complete staged attack: new accounts, an additional detected ring, a critical live result and account evidence.
8. Real transaction-count changes on stream resume, and stopping the stream.
9. Mobile navigation, landing-page launch and responsive page width.

Browser tests intentionally operate on and reset a running synthetic sandbox. They are not appropriate for an environment containing cases you wish to retain.

## Boundaries of this verification

These results establish the tested application's behavior in this local synthetic environment. They do **not** establish production reliability, financial-crime detection accuracy, real-world fraud probabilities, regulatory compliance, security certification, multi-tenant safety or banking-scale throughput. No real customer/payment data were used.
