# Security, privacy and deployment boundaries

## Current operating mode

MuleHunter AI is an **isolated, synthetic-data prototype** with production-style structure and interactions. It is not a production-ready financial crime system.

- All account identifiers, devices, locations and payment events are fictional.
- No real bank, UPI provider, cash-out processor, identity service or regulatory gateway is connected.
- There is no authentication or role-based authorization.
- Any client with access to the API can create simulations, submit synthetic transactions, edit cases and reset the demo dataset.
- Live events and the derived analysis snapshot are process-local. Run exactly one Uvicorn application worker.
- The browser uses a same-origin API/WebSocket proxy. It does not embed credentials or external AI keys.
- React escapes ordinary text, report text is escaped before PDF rendering, API inputs are bounded by Pydantic, database access uses SQLAlchemy, and SQLite enforces foreign keys.
- The server imposes dataset and per-request resource budgets, serializes mutating analysis operations, bounds graph/path search, and closes stale WebSocket sessions.
- These safeguards do not replace authentication, adversarial testing, rate limiting or banking-grade isolation.

**Do not connect real personal/banking data or expose this demo to the public internet.** Vite's host allowlist is intentionally permissive for sandbox preview compatibility and is not a production access policy. The provided Docker ports can be reachable from the host network; isolate them with host/firewall controls.

## Before considering a real pilot

A qualified engineering, security, compliance and model-risk team would need to implement and validate at least:

1. **Identity and access:** SSO, MFA, RBAC/ABAC, per-tenant scoping, least privilege, authorization on every entity/action, analyst session management and explicit privileges for resets or case exports.
2. **Data governance:** documented lawful access, data minimization, retention/deletion schedules, encrypted storage/backups, transport TLS, key management, lineage and a process for data-subject/customer rights.
3. **Auditing:** tamper-evident append-only access/action logs, actor identity, before/after state, stable event/analysis IDs, immutable transaction-time evidence snapshots and report provenance.
4. **Resilience:** a durable job queue, shared event bus, transactional outbox, idempotency keys, backpressure, failure recovery, schema migrations, tested backups and disaster recovery.
5. **Scale:** incremental/windowed graph and feature updates, partitioned transactional storage, workload isolation, service-level objectives and representative load testing. The current full-snapshot recomputation is intentionally a local-demo strategy.
6. **Application security:** threat modeling, penetration tests, dependency scanning/SBOM, rate limits, CSRF and WebSocket-origin policies, security headers appropriate to deployment, request/body caps, secret rotation and incident response procedures.
7. **Model validation:** representative approved datasets, temporal holdouts, leakage checks, calibration, threshold selection, precision/recall/false-positive evaluation, subgroup fairness testing, concept drift monitoring, retraining governance and independent validation.
8. **Investigation controls:** human review, evidence quality standards, uncertainty display, dual-control workflows for adverse actions, case assignment, appeals and correction processes.
9. **Bank/regulatory integration:** legally reviewed real payment connectors, reconciled balances, identity resolution, sanctions/PEP/KYC controls where appropriate, approved reporting workflows and jurisdiction-specific compliance review.
10. **Monitoring:** structured logs, metrics, tracing, health/readiness separation, durable alerts and operational ownership.

## Interpretation and human impact

High network proximity does not establish intent. A low score does not establish legitimacy. Circular transfers, bursts, large payments, fan-in and fan-out can have legitimate explanations. Synthetic classifier outputs are uncalibrated and must not be presented as real-world fraud probabilities.

Recommendations in this application only update the local case record. No customer account is restricted, no transaction is reversed, no person is accused and no external authority is notified.

## Test environment safety

Backend pytest tests use a temporary SQLite database. Browser E2E tests intentionally operate through the running UI/API and reset that sandbox. Never point those tests at an environment containing data or cases you intend to retain.

The source archive does not include the running workspace's generated database, reports, screenshots, caches, dependency directories or credentials. A fresh local run seeds its own fictional dataset.
