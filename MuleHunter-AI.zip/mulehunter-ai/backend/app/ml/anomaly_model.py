"""Reproducible, local synthetic models. No external AI or fraud-label shortcut.

Isolation Forest is fitted on a generated normal reference population. The random
forest is a deliberately synthetic experimental classifier, NOT calibrated on
real payments. Its output must not be represented as a real-world probability.
"""

import numpy as np
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.preprocessing import RobustScaler

FEATURES = [
    "transaction_amount",
    "transaction_frequency",
    "unique_counterparties",
    "incoming_outgoing_ratio",
    "average_transaction_interval",
    "network_degree",
    "centrality_score",
    "fan_in_score",
    "fan_out_score",
    "risk_exposure",
]


class AnomalyModel:
    def __init__(self):
        rng = np.random.default_rng(42)
        n = 2400
        normal = np.column_stack(
            [
                rng.lognormal(7.55, 0.65, n),
                rng.poisson(2, n),
                rng.integers(3, 36, n),
                rng.uniform(0.2, 3.4, n),
                rng.uniform(250, 12000, n),
                rng.uniform(0.005, 0.09, n),
                rng.uniform(0, 0.035, n),
                rng.uniform(0, 34, n),
                rng.uniform(0, 34, n),
                rng.uniform(0, 25, n),
            ]
        )
        anomalous = np.column_stack(
            [
                rng.lognormal(10, 0.7, n),
                rng.integers(8, 65, n),
                rng.integers(5, 48, n),
                rng.uniform(0.05, 6, n),
                rng.uniform(2, 200, n),
                rng.uniform(0.01, 0.12, n),
                rng.uniform(0.005, 0.12, n),
                rng.uniform(30, 100, n),
                rng.uniform(30, 100, n),
                rng.uniform(20, 95, n),
            ]
        )
        self.scaler = RobustScaler().fit(normal)
        self.isolation = IsolationForest(
            n_estimators=80, contamination=0.04, random_state=42, n_jobs=1
        )
        self.isolation.fit(self.scaler.transform(normal))
        self.forest = RandomForestClassifier(
            n_estimators=72, max_depth=8, random_state=42, n_jobs=1
        )
        self.forest.fit(np.vstack([normal, anomalous]), np.r_[np.zeros(n), np.ones(n)])

    def predict(self, feature_rows: list[list[float]]) -> list[dict]:
        if not feature_rows:
            return []
        data = np.nan_to_num(np.asarray(feature_rows, dtype=float))
        raw = self.isolation.decision_function(self.scaler.transform(data))
        anomalies = np.clip((0.13 - raw) / 0.37, 0, 1)
        probabilities = self.forest.predict_proba(data)[:, 1]
        return [
            {
                "anomaly_score": round(float(a * 100), 1),
                "normality_score": round(float((1 - a) * 100), 1),
                "fraud_probability": round(float(p), 3),
                "model_risk": round(float(0.55 * a + 0.45 * p) * 100, 1),
                "model_note": "Experimental estimate from synthetic training data; not a calibrated real-world fraud probability.",
            }
            for a, p in zip(anomalies, probabilities)
        ]
