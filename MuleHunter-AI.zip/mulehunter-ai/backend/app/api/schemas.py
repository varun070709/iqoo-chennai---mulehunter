from datetime import datetime
from typing import Literal
from pydantic import BaseModel, Field, field_validator, model_validator

Pattern = Literal[
    "normal",
    "suspicious",
    "mule",
    "fraud_ring",
    "fan_in",
    "fan_out",
    "circular",
    "multi_hop",
    "demo",
]


class SimulationRequest(BaseModel):
    action: Literal["generate", "start", "stop", "reset"] = "generate"
    number_of_accounts: int = Field(default=500, ge=20, le=2000)
    number_of_transactions: int = Field(default=5000, ge=20, le=20000)
    fraud_percentage: float = Field(default=8, ge=0, le=50)
    transaction_speed: float = Field(default=1, ge=0.2, le=10)
    fraud_pattern: Pattern = "demo"


class InjectionRequest(BaseModel):
    pattern: Pattern = "demo"
    number_of_accounts: int = Field(default=12, ge=8, le=15)


class AccountRequest(BaseModel):
    account_id: str = Field(min_length=1, max_length=32)


class TransactionRequest(BaseModel):
    sender: str = Field(min_length=1, max_length=32)
    receiver: str = Field(min_length=1, max_length=32)
    amount: float = Field(gt=0, le=10000000, allow_inf_nan=False)
    timestamp: datetime | None = None
    transaction_type: Literal["UPI", "IMPS", "NEFT", "WALLET", "CASHOUT"] = "UPI"
    persist: bool = True

    @model_validator(mode="after")
    def distinct_accounts(self):
        if self.sender == self.receiver:
            raise ValueError("Sender and receiver must be different accounts.")
        return self


class CaseRequest(BaseModel):
    account_ids: list[str] = Field(min_length=1, max_length=200)
    title: str = Field(
        default="Suspected mule account network", min_length=3, max_length=160
    )
    ring_id: str | None = Field(default=None, max_length=32)


class CaseUpdate(BaseModel):
    status: Literal["open", "in_review", "escalated", "closed"] | None = None
    recommended_action: (
        Literal[
            "Monitor",
            "Request Additional Verification",
            "Temporarily Flag",
            "Escalate for Investigation",
        ]
        | None
    ) = None
    notes: str | None = Field(default=None, max_length=8000)
