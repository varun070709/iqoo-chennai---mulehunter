"""Actual account topology, time-local communities and bounded exposure."""

import hashlib
import math
from datetime import timedelta
from itertools import islice
import networkx as nx


class GraphAnalyzer:
    def __init__(self, accounts, transactions, now):
        self.graph = nx.DiGraph()
        self.graph.add_nodes_from(a["id"] for a in accounts)
        self.active = nx.DiGraph()
        self.active.add_nodes_from(self.graph)
        cutoff = now - timedelta(hours=1)
        for tx in transactions:
            s, r = tx["sender"], tx["receiver"]
            old = self.graph.get_edge_data(s, r, {"amount": 0, "count": 0})
            self.graph.add_edge(
                s,
                r,
                amount=round(old["amount"] + tx["amount"], 2),
                count=old["count"] + 1,
                latest=max(old.get("latest", tx["timestamp"]), tx["timestamp"]),
            )
            if tx["timestamp"] >= cutoff and tx["amount"] >= 2000:
                old = self.active.get_edge_data(s, r, {"amount": 0, "count": 0})
                self.active.add_edge(
                    s,
                    r,
                    amount=old["amount"] + tx["amount"],
                    count=old["count"] + 1,
                    latest=max(old.get("latest", tx["timestamp"]), tx["timestamp"]),
                )
        undirected = self.graph.to_undirected()
        for _, _, d in undirected.edges(data=True):
            d["weight"] = math.sqrt(d["amount"] / 1000)
        self.communities = (
            list(nx.community.louvain_communities(undirected, weight="weight", seed=42))
            if undirected.number_of_edges()
            else [{n} for n in undirected]
        )
        self.community_map = {n: i for i, c in enumerate(self.communities) for n in c}
        degree = nx.degree_centrality(self.graph)
        between = (
            nx.betweenness_centrality(
                self.graph, k=min(40, len(self.graph)), seed=42, normalized=True
            )
            if len(self.graph) > 1
            else {}
        )
        # Enumeration is bounded to remain responsive even in dense synthetic graphs.
        self.cycles = []
        cyclic_components = [
            c for c in nx.strongly_connected_components(self.active) if len(c) >= 2
        ]
        # Give each strongly connected component a share of the bounded budget;
        # one dense old ring must not hide cycles in a newly emerging network.
        per_component = max(1, 150 // max(1, len(cyclic_components)))
        for component in cyclic_components:
            self.cycles.extend(
                islice(
                    nx.simple_cycles(self.active.subgraph(component), length_bound=4),
                    per_component,
                )
            )
            if len(self.cycles) >= 150:
                self.cycles = self.cycles[:150]
                break
        cycle_nodes = {n for cycle in self.cycles for n in cycle}
        self.stats = {
            n: {
                "degree": round(degree.get(n, 0), 5),
                "betweenness": round(between.get(n, 0), 5),
                "community": self.community_map.get(n, 0),
                "in_cycle": n in cycle_nodes,
            }
            for n in self.graph
        }
        self.components = list(nx.weakly_connected_components(self.graph))
        self.now = now

    def account_graph_risk(self, account_id, metrics):
        fan = max(metrics["fan_in_score"], metrics["fan_out_score"])
        cyc = 75 if metrics["in_cycle"] else 0
        flow = min(25, metrics["recent_count"] * 1.8)
        # A single graph signal never dominates the complete final risk score.
        return min(100, max(fan * 0.85, cyc) + flow)

    def propagate(self, base_scores):
        graph = self.active.to_undirected()
        exposures = {n: 0.0 for n in self.graph}
        sources = [n for n, s in base_scores.items() if s >= 62]
        provenance = {n: [] for n in self.graph}
        for source in sources:
            queue = [(source, 0, 1.0)]
            best = {source: 1.0}
            while queue:
                node, distance, path_strength = queue.pop(0)
                if distance >= 3:
                    continue
                for neighbor, data in graph[node].items():
                    if neighbor == source:
                        continue
                    age = max(0, (self.now - data["latest"]).total_seconds())
                    strength = (
                        0.3 * min(data["count"] / 4, 1)
                        + 0.35 * min(data["amount"] / 100000, 1)
                        + 0.35 * math.exp(-age / 3600)
                    )
                    product = path_strength * strength * 0.66
                    if product <= best.get(neighbor, 0):
                        continue
                    best[neighbor] = product
                    value = base_scores[source] * product
                    exposures[neighbor] = min(100, exposures[neighbor] + value * 0.65)
                    provenance[neighbor].append(
                        {
                            "source": source,
                            "hops": distance + 1,
                            "contribution": round(value * 0.65, 1),
                        }
                    )
                    queue.append((neighbor, distance + 1, product))
        return {n: round(v, 1) for n, v in exposures.items()}, provenance

    def detect_rings(self, analyses):
        suspects = [n for n, a in analyses.items() if a["risk_score"] >= 50]
        active = self.active.subgraph(suspects)
        candidates = []
        for component in nx.weakly_connected_components(active):
            if len(component) < 3:
                continue
            if len(component) > 30:
                candidates.extend(
                    nx.community.louvain_communities(
                        active.subgraph(component).to_undirected(), seed=42
                    )
                )
            else:
                candidates.append(component)
        rings = []
        for members in candidates:
            if len(members) < 3:
                continue
            sub = active.subgraph(members)
            edges = list(sub.edges(data=True))
            volume = sum(d["amount"] for _, _, d in edges)
            avg = sum(analyses[n]["risk_score"] for n in members) / len(members)
            density = nx.density(sub)
            circular = any(set(c).issubset(members) for c in self.cycles)
            rapid = sum(
                analyses[n]["metrics"]["rapid_forward_ratio"] >= 0.5 for n in members
            )
            high_risk = sum(analyses[n]["risk_score"] >= 61 for n in members)
            # At least 2 independent network signals plus meaningful volume/risk.
            signals = (
                int(density >= 0.15)
                + int(circular)
                + int(rapid >= 2)
                + int(high_risk >= 3)
            )
            if avg < 48 or volume < 50000 or signals < 2:
                continue
            ordered = sorted(
                members, key=lambda n: analyses[n]["risk_score"], reverse=True
            )
            identifier = (
                hashlib.sha1("|".join(sorted(members)).encode()).hexdigest()[:6].upper()
            )
            reasons = []
            patterns = []
            if density >= 0.15:
                reasons.append(
                    f"{density:.0%} internal network density across {len(members)} accounts."
                )
            if rapid:
                reasons.append(
                    f"{rapid} accounts forward at least 50% of received value within five minutes."
                )
                patterns.extend(["Rapid multi-hop", "Layering"])
            if circular:
                reasons.append(
                    "Directed circular fund movement detected in the last hour."
                )
                patterns.append("Circular flow")
            if high_risk:
                reasons.append(
                    f"{high_risk} members independently score above the high-risk threshold."
                )
            if any(analyses[n]["metrics"]["fan_in_score"] >= 60 for n in members):
                patterns.append("Fan-in")
            if any(analyses[n]["metrics"]["fan_out_score"] >= 60 for n in members):
                patterns.append("Fan-out")
            if any(analyses[n]["metrics"]["cashout_amount"] > 50000 for n in members):
                patterns.append("Rapid cash-out")
            score = min(100, round(avg + 5 * signals))
            rings.append(
                {
                    "id": f"FR-{identifier}",
                    "title": "Potential mule network",
                    "members": ordered,
                    "member_count": len(members),
                    "average_risk": round(avg),
                    "risk_score": score,
                    "volume": round(volume, 2),
                    "density": round(density, 3),
                    "reasons": reasons,
                    "patterns": list(dict.fromkeys(patterns)),
                    "hub": ordered[0],
                    "detected_at": self.now.isoformat() + "Z",
                    "edge_count": len(edges),
                }
            )
        rings.sort(key=lambda r: (r["risk_score"], r["volume"]), reverse=True)
        for i, ring in enumerate(rings):
            ring["title"] = f"Potential fraud ring #{i + 1:02}"
        return rings
