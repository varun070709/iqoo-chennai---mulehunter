from datetime import datetime, timezone
from sqlalchemy import String, Float, Integer, DateTime, ForeignKey, JSON, Index
from sqlalchemy.orm import Mapped, mapped_column
from app.database.session import Base


def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Account(Base):
    __tablename__ = "accounts"
    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    label: Mapped[str] = mapped_column(String(100))
    account_type: Mapped[str] = mapped_column(String(32), default="wallet")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    device_hash: Mapped[str] = mapped_column(String(60), default="SIMULATED-DEVICE")
    location_cluster: Mapped[str] = mapped_column(String(40), default="SIMULATED")
    risk_score: Mapped[float] = mapped_column(Float, default=0)
    risk_level: Mapped[str] = mapped_column(String(20), default="SAFE", index=True)
    analysis: Mapped[dict] = mapped_column(JSON, default=dict)


class Transaction(Base):
    __tablename__ = "transactions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    sender: Mapped[str] = mapped_column(ForeignKey("accounts.id"), index=True)
    receiver: Mapped[str] = mapped_column(ForeignKey("accounts.id"), index=True)
    amount: Mapped[float] = mapped_column(Float)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    transaction_type: Mapped[str] = mapped_column(String(20), default="UPI")
    device_hash: Mapped[str] = mapped_column(String(60), default="SIMULATED-DEVICE")
    location_cluster: Mapped[str] = mapped_column(String(40), default="SIMULATED")
    risk_score: Mapped[float] = mapped_column(Float, default=0)
    risk_level: Mapped[str] = mapped_column(String(20), default="SAFE", index=True)
    flags: Mapped[list] = mapped_column(JSON, default=list)
    # Scenario labels are stored for audit only. Detection never reads this column.
    scenario: Mapped[str] = mapped_column(String(40), default="normal")
    __table_args__ = (Index("ix_tx_sender_time", "sender", "timestamp"),)


class InvestigationCase(Base):
    __tablename__ = "cases"
    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    title: Mapped[str] = mapped_column(String(180))
    ring_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    account_ids: Mapped[list] = mapped_column(JSON, default=list)
    risk_score: Mapped[float] = mapped_column(Float, default=0)
    status: Mapped[str] = mapped_column(String(32), default="open")
    recommended_action: Mapped[str] = mapped_column(
        String(100), default="Request Additional Verification"
    )
    notes: Mapped[str] = mapped_column(String(8000), default="")
    evidence: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
