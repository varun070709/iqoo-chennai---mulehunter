import asyncio
import copy
import logging
from contextlib import asynccontextmanager
from datetime import timezone, timedelta
from fastapi import FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.responses import Response
from fastapi.openapi.docs import get_swagger_ui_html
from app.api.schemas import (
    SimulationRequest,
    InjectionRequest,
    AccountRequest,
    TransactionRequest,
    CaseRequest,
    CaseUpdate,
)
from app.models.entities import utcnow
from app.services.platform import Platform, tx_json
from app.services.report import build_report

log = logging.getLogger("mulehunter")
platform: Platform | None = None
clients: set[WebSocket] = set()
jobs: set[asyncio.Task] = set()
operation_lock = asyncio.Lock()


def get_platform() -> Platform:
    if platform is None:
        raise HTTPException(
            503, "The intelligence engine is initializing. Please retry."
        )
    return platform


async def broadcast(kind="snapshot"):
    p = get_platform()

    def snapshot():
        return {
            "type": kind,
            "dashboard": p.dashboard(),
            "transactions": p.transaction_list(limit=15)["items"],
            "progress": p.attack_progress,
        }

    payload = await asyncio.to_thread(snapshot)
    for ws in list(clients):
        try:
            await asyncio.wait_for(ws.send_json(payload), timeout=2)
        except Exception:
            clients.discard(ws)


async def live_loop():
    while True:
        await asyncio.sleep(3)
        p = get_platform()
        if p.stream_running and not p.attack_running and not operation_lock.locked():
            try:
                async with operation_lock:
                    await asyncio.to_thread(p.tick)
                await broadcast()
            except Exception as exc:
                log.exception("Live simulation stopped")
                p.stream_running = False
                p.attack_progress = {
                    "error": str(exc),
                    "title": "Simulation paused",
                    "step": 0,
                    "total_steps": 7,
                }
                await broadcast("error")


async def demo_attack():
    p = get_platform()
    try:
        async with operation_lock:
            p.attack_progress = {
                "step": 1,
                "total_steps": 7,
                "title": "Establishing normal activity",
                "complete": False,
            }
            await asyncio.to_thread(p.tick)
            await broadcast("attack")
            await asyncio.sleep(0.8)
            accounts, batches = p.simulator.attack(
                [a["id"] for a in p.accounts],
                utcnow(),
                "demo",
                12,
                prefix=f"D{len(p.accounts):04X}",
            )
            p.attack_progress.update(
                {
                    "step": 2,
                    "title": "12 synthetic wallets created",
                    "account_id": accounts[0]["id"],
                    "account_ids": [a["id"] for a in accounts],
                }
            )
            await asyncio.to_thread(p.insert, accounts, [])
            await broadcast("attack")
            await asyncio.sleep(0.7)
            for index, (title, txs) in enumerate(batches):
                await asyncio.to_thread(p.insert, [], txs)
                p.attack_progress.update({"step": index + 3, "title": title})
                await broadcast("attack")
                await asyncio.sleep(1.0)
            await asyncio.to_thread(p.auto_cases)
            hub = max(accounts, key=lambda a: p.analyses[a["id"]]["risk_score"])["id"]
            related = [r for r in p.rings if hub in r["members"]]
            p.attack_progress.update(
                {
                    "step": 7,
                    "title": "Emerging fraud network detected",
                    "complete": True,
                    "account_id": hub,
                    "risk_score": p.analyses[hub]["risk_score"],
                    "ring_id": related[0]["id"] if related else None,
                    "explanation": p.analyses[hub]["explanation"]["summary"],
                }
            )
    except asyncio.CancelledError:
        p.attack_progress = {
            "error": "Stopped by the analyst. Already ingested synthetic transfers remain available for review.",
            "title": "Demo attack stopped",
            "step": 0,
            "total_steps": 7,
            "complete": False,
        }
    except Exception as exc:
        log.exception("Demo attack failed")
        p.attack_progress = {
            "error": str(exc),
            "title": "Attack interrupted",
            "step": 0,
            "total_steps": 7,
            "complete": False,
        }
    finally:
        p.attack_running = False
        await broadcast("attack_complete")


@asynccontextmanager
async def lifespan(app):
    global platform
    platform = await asyncio.to_thread(Platform)
    task = asyncio.create_task(live_loop())
    yield
    task.cancel()
    for job in jobs:
        job.cancel()
    await asyncio.gather(task, *list(jobs), return_exceptions=True)


app = FastAPI(
    title="MuleHunter AI",
    version="1.0.0",
    description="Synthetic financial network intelligence and decision support. Not a production fraud verdict service.",
    lifespan=lifespan,
    docs_url=None,
    redoc_url=None,
    servers=[{"url": ".", "description": "Relative API root, direct or proxied"}],
)


@app.get("/", include_in_schema=False)
def api_home():
    return {
        "application": "MuleHunter AI API",
        "docs": "docs",
        "health": "health",
        "frontend": "Open the MuleHunter AI web preview (port 5173), or port 8080 with Docker.",
        "synthetic": True,
    }


@app.get("/docs", include_in_schema=False)
def api_docs():
    return get_swagger_ui_html(
        openapi_url="./openapi.json", title="MuleHunter AI · API documentation"
    )


@app.get("/health")
def health():
    p = get_platform()
    return {
        "status": "healthy",
        "database": "connected",
        "engine": "ready",
        "model": "Isolation Forest + Random Forest (synthetic)",
        "graph": "NetworkX",
        "active_connections": len(clients),
        "accounts": len(p.accounts),
        "version": p.version,
        "synthetic": True,
        "limits": {"accounts": 2000, "transactions": 50000},
        "authentication": "local-demo-no-auth",
    }


@app.get("/dashboard")
def dashboard():
    return get_platform().dashboard()


@app.get("/transactions")
def transactions(
    query: str = Query("", max_length=100),
    level: str = "ALL",
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
    hours: int = Query(24, ge=1, le=8760),
):
    return get_platform().transaction_list(query, level, limit, offset, hours)


@app.get("/transactions/export")
def export_transactions():
    return Response(
        get_platform().export_csv(),
        media_type="text/csv",
        headers={
            "Content-Disposition": 'attachment; filename="mulehunter-synthetic-transactions.csv"'
        },
    )


@app.get("/accounts")
def accounts(
    query: str = Query("", max_length=100),
    level: str = "ALL",
    limit: int = Query(100, ge=1, le=2000),
    offset: int = Query(0, ge=0),
):
    return get_platform().account_list(query, level, limit, offset)


@app.get("/accounts/{account_id}")
def account(account_id: str):
    try:
        return get_platform().account(account_id)
    except KeyError:
        raise HTTPException(404, "Account not found in this synthetic network.")


@app.get("/network")
def network(
    limit: int = Query(90, ge=1, le=2000),
    level: str = "ALL",
    hours: int = Query(24, ge=1, le=8760),
    focus: str | None = None,
):
    p = get_platform()
    if focus and focus not in p.analyses:
        raise HTTPException(
            404,
            "Account not found. Clear the account focus or search an existing synthetic ID.",
        )
    return p.network(limit, level, hours, focus)


@app.get("/fraud-rings")
def fraud_rings():
    p = get_platform()
    with p.lock:
        return {"items": p.rings, "total": len(p.rings)}


@app.get("/flows")
def flows(account_id: str):
    try:
        return get_platform().flows(account_id)
    except KeyError:
        raise HTTPException(404, "Account not found.")


@app.get("/propagation/{account_id}")
def propagation(account_id: str):
    try:
        return get_platform().propagation(account_id)
    except KeyError:
        raise HTTPException(404, "Account not found.")


@app.get("/cases")
def cases():
    return {"items": get_platform().cases()}


@app.post("/cases", status_code=201)
def create_case(request: CaseRequest):
    try:
        return get_platform().create_case(
            request.account_ids, request.title, request.ring_id
        )
    except ValueError as exc:
        raise HTTPException(422, str(exc))


@app.patch("/cases/{case_id}")
def update_case(case_id: str, request: CaseUpdate):
    try:
        return get_platform().update_case(
            case_id, request.model_dump(exclude_none=True)
        )
    except KeyError:
        raise HTTPException(404, "Investigation case not found.")


@app.get("/investigation/{case_id}")
def investigation(case_id: str):
    try:
        return get_platform().investigation(case_id)
    except KeyError:
        raise HTTPException(404, "Investigation case not found.")


@app.get("/investigation/{case_id}/report")
def report(case_id: str):
    try:
        case = get_platform().investigation(case_id)
    except KeyError:
        raise HTTPException(404, "Investigation case not found.")
    return Response(
        build_report(case),
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{case_id}-mulehunter.pdf"'
        },
    )


@app.post("/simulate")
async def simulate(request: SimulationRequest):
    p = get_platform()
    if request.action in {"generate", "reset"}:
        if operation_lock.locked() or p.attack_running:
            raise HTTPException(
                409, "An analysis operation is already running. Please wait."
            )
        async with operation_lock:
            try:
                await asyncio.to_thread(
                    p.reset,
                    request.number_of_accounts,
                    request.number_of_transactions,
                    request.fraud_percentage,
                    request.fraud_pattern,
                )
            except ValueError as exc:
                raise HTTPException(422, str(exc))
    elif request.action == "start":
        p.stream_speed = request.transaction_speed
        p.stream_fraud_percentage = request.fraud_percentage
        p.stream_pattern = request.fraud_pattern
        p.stream_running = True
    else:
        p.stream_running = False
        if p.attack_running:
            active_jobs = list(jobs)
            for task in active_jobs:
                task.cancel()
            await asyncio.gather(*active_jobs, return_exceptions=True)
    await broadcast("simulation")
    return {
        "message": f"Simulation {request.action} complete",
        "dashboard": p.dashboard(),
    }


@app.post("/simulate/inject-fraud")
async def inject_fraud(request: InjectionRequest):
    p = get_platform()
    if operation_lock.locked() or p.attack_running:
        raise HTTPException(409, "Another simulation is already running.")
    async with operation_lock:
        try:
            result = await asyncio.to_thread(
                p.inject, request.pattern, request.number_of_accounts
            )
        except ValueError as exc:
            raise HTTPException(422, str(exc))
    await broadcast("injection")
    return result


@app.post("/simulate/demo-attack", status_code=202)
async def start_attack():
    p = get_platform()
    if p.attack_running or operation_lock.locked():
        raise HTTPException(409, "A simulation is already running.")
    p.attack_running = True
    task = asyncio.create_task(demo_attack())
    jobs.add(task)
    task.add_done_callback(jobs.discard)
    return {
        "status": "started",
        "message": "Staged synthetic network attack is running.",
        "steps": 7,
    }


@app.post("/analyze/account")
async def analyze_account(request: AccountRequest):
    p = get_platform()
    if request.account_id not in p.analyses:
        raise HTTPException(404, "Account not found.")
    if operation_lock.locked():
        raise HTTPException(409, "Analysis in progress. Please retry shortly.")
    async with operation_lock:
        await asyncio.to_thread(p.refresh)
    await broadcast("analysis")
    return p.account(request.account_id)


@app.post("/analyze/transaction")
async def analyze_transaction(request: TransactionRequest):
    p = get_platform()
    if request.sender not in p.analyses or request.receiver not in p.analyses:
        raise HTTPException(
            404, "Both sender and receiver must be existing synthetic accounts."
        )
    timestamp = request.timestamp or utcnow()
    if timestamp.tzinfo:
        timestamp = timestamp.astimezone(timezone.utc).replace(tzinfo=None)
    if timestamp > utcnow() + timedelta(seconds=3) or timestamp < utcnow() - timedelta(
        days=365
    ):
        raise HTTPException(
            422, "Transaction time must be within the last year and not in the future."
        )
    tx = p.simulator.tx(
        request.sender,
        request.receiver,
        request.amount,
        timestamp,
        "manual",
        request.transaction_type,
    )
    if operation_lock.locked():
        raise HTTPException(409, "Analysis in progress. Please retry shortly.")
    async with operation_lock:
        if request.persist:
            try:
                await asyncio.to_thread(p.insert, [], [tx])
            except ValueError as exc:
                raise HTTPException(422, str(exc))
            tx = max(p.transactions, key=lambda t: t["id"])
            result = {
                "transaction": tx_json(tx),
                "sender_analysis": p.analyses[request.sender],
                "receiver_analysis": p.analyses[request.receiver],
                "persisted": True,
            }
        else:
            with p.lock:
                candidate = {
                    **tx,
                    "id": max((t["id"] for t in p.transactions), default=0) + 1,
                }
                snapshot = copy.deepcopy(p.transactions) + [candidate]
                acc = copy.deepcopy(p.accounts)
            analyses, _, _ = await asyncio.to_thread(
                p.detector.analyze, acc, snapshot, utcnow()
            )
            result = {
                "transaction": tx_json(candidate),
                "sender_analysis": analyses[request.sender],
                "receiver_analysis": analyses[request.receiver],
                "persisted": False,
            }
    if request.persist:
        await broadcast("transaction")
    return result


@app.websocket("/ws/live-transactions")
async def live_transactions(ws: WebSocket):
    await ws.accept()
    clients.add(ws)
    try:
        p = get_platform()
        await ws.send_json(
            {
                "type": "connected",
                "dashboard": p.dashboard(),
                "transactions": p.transaction_list(limit=15)["items"],
                "progress": p.attack_progress,
            }
        )
        while True:
            try:
                message = await asyncio.wait_for(ws.receive_text(), timeout=65)
            except asyncio.TimeoutError:
                await ws.close(
                    code=1000, reason="Heartbeat timeout; reconnect to resume."
                )
                break
            if message == "ping":
                await ws.send_json({"type": "pong"})
    except WebSocketDisconnect:
        pass
    finally:
        clients.discard(ws)
