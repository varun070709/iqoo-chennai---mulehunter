"""Interpretable weighted additive risk. Scores are decision support, not verdicts."""

WEIGHTS = {
    "behavioral": 0.25,
    "velocity": 0.20,
    "graph": 0.25,
    "temporal": 0.15,
    "exposure": 0.15,
}


def risk_level(score: float) -> str:
    score = round(score)
    return (
        "SAFE"
        if score <= 30
        else "SUSPICIOUS" if score <= 60 else "HIGH RISK" if score <= 80 else "CRITICAL"
    )


def combine_scores(scores: dict) -> tuple[int, dict]:
    contributions = {
        k: round(max(0, min(100, scores.get(k, 0))) * v, 2) for k, v in WEIGHTS.items()
    }
    return max(0, min(100, round(sum(contributions.values())))), contributions


def velocity_risk(metrics: dict) -> float:
    burst = metrics["recent_count"]
    interval = metrics["average_transaction_interval"]
    return min(100, burst * 7 + (25 if burst >= 6 and interval < 90 else 0))
