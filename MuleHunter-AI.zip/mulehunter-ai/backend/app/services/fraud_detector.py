from app.services.behavior_analyzer import build_behavior, feature_vector
from app.services.temporal_analyzer import analyze_temporal
from app.services.risk_engine import combine_scores, velocity_risk, risk_level
from app.services.explainer import explain
from app.graph.graph_analyzer import GraphAnalyzer


class FraudDetector:
    def __init__(self, model):
        self.model = model

    def analyze(self, accounts, transactions, now):
        graph = GraphAnalyzer(accounts, transactions, now)
        metrics = build_behavior(accounts, transactions, now, graph.stats)
        temporal = analyze_temporal(accounts, transactions, now)
        ids = list(metrics)
        predictions = self.model.predict([feature_vector(metrics[n]) for n in ids])
        scores, base, models = {}, {}, {}
        for aid, ml in zip(ids, predictions):
            m = metrics[aid]
            m.update(temporal[aid])
            models[aid] = ml
            scores[aid] = {
                "behavioral": ml["model_risk"],
                "velocity": velocity_risk(m),
                "graph": graph.account_graph_risk(aid, m),
                "temporal": m["temporal_risk"],
                "exposure": 0,
            }
            # Normalize the no-exposure score for seed selection, not the final score.
            raw, _ = combine_scores(scores[aid])
            base[aid] = round(raw / 0.85, 1)
        exposures, provenance = graph.propagate(base)
        # Second model pass uses the measured exposure feature; propagation seeds
        # remain fixed to the independently computed first pass (no feedback loop).
        for aid in ids:
            metrics[aid]["risk_exposure"] = exposures[aid]
        updated_models = self.model.predict([feature_vector(metrics[n]) for n in ids])
        for aid, ml in zip(ids, updated_models):
            models[aid] = ml
            scores[aid]["behavioral"] = ml["model_risk"]
            scores[aid]["exposure"] = exposures[aid]
        final_scores = {aid: combine_scores(scores[aid])[0] for aid in ids}
        analyses = {}
        for aid in ids:
            m = metrics[aid]
            m["risk_exposure"] = exposures[aid]
            neighbors = set(graph.active.predecessors(aid)) | set(
                graph.active.successors(aid)
            )
            m["suspicious_connections"] = sum(
                final_scores.get(n, 0) >= 61 for n in neighbors
            )
            scores[aid]["exposure"] = exposures[aid]
            risk, contributions = combine_scores(scores[aid])
            explanation = explain(m, scores[aid], models[aid], risk)
            normal = {
                "Velocity": 20,
                "Value": 23,
                "Fan-in": 18,
                "Fan-out": 18,
                "Centrality": 22,
                "Exposure": 12,
            }
            radar = {
                "Velocity": min(100, m["recent_count"] * 7),
                "Value": min(100, m["average_transaction_value"] / 500),
                "Fan-in": m["fan_in_score"],
                "Fan-out": m["fan_out_score"],
                "Centrality": min(100, m["network_centrality"] * 1800),
                "Exposure": m["risk_exposure"],
            }
            analyses[aid] = {
                "risk_score": risk,
                "risk_level": risk_level(risk),
                "metrics": m,
                "scores": {k: round(v, 1) for k, v in scores[aid].items()},
                "contributions": contributions,
                "ml": models[aid],
                "explanation": explanation,
                "radar": [
                    {"axis": k, "baseline": normal[k], "current": round(v)}
                    for k, v in radar.items()
                ],
                "propagation_sources": sorted(
                    provenance[aid], key=lambda p: -p["contribution"]
                )[:8],
            }
        rings = graph.detect_rings(analyses)
        for tx in transactions:
            a, b = analyses[tx["sender"]], analyses[tx["receiver"]]
            # Endpoint risk + transaction magnitude. No scenario label used here.
            magnitude = min(10, tx["amount"] / 20000)
            extreme = tx["amount"] > max(
                200000,
                min(
                    a["metrics"]["average_transaction_value"],
                    b["metrics"]["average_transaction_value"],
                )
                * 5,
            )
            score = round(
                max(a["risk_score"], b["risk_score"]) * 0.9
                + (25 if extreme else magnitude)
            )
            tx["risk_score"] = min(100, score)
            tx["risk_level"] = risk_level(score)
            highest = a if a["risk_score"] >= b["risk_score"] else b
            tx["flags"] = (
                ["Transfer value exceeds the account reference threshold"]
                if extreme
                else []
            ) + [
                e["title"]
                for e in highest["explanation"]["evidence"]
                if e["severity"] != "SAFE"
            ][
                :3
            ]
        return analyses, rings, graph
