import math
from io import BytesIO
from html import escape
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.graphics.shapes import Drawing, Circle, Line, String, Rect, Polygon
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    KeepTogether,
)


def network_drawing(network):
    """Small, real topology snapshot; not a fabricated decorative graph."""
    nodes = sorted(network["nodes"], key=lambda n: -n["risk_score"])[:24]
    drawing = Drawing(511, 220)
    drawing.add(
        Rect(
            0,
            0,
            511,
            220,
            fillColor=colors.HexColor("#f3f6f0"),
            strokeColor=colors.HexColor("#dde5d7"),
        )
    )
    positions = {}
    for i, node in enumerate(nodes):
        if i == 0:
            x, y = 255, 119
        else:
            angle = (i - 1) * 2 * math.pi / max(1, len(nodes) - 1)
            x, y = 255 + 192 * math.cos(angle), 119 + 75 * math.sin(angle)
        positions[node["id"]] = (x, y)
    for edge in network["edges"][:400]:
        if edge["source"] not in positions or edge["target"] not in positions:
            continue
        x, y = positions[edge["source"]]
        xx, yy = positions[edge["target"]]
        length = max(1, math.hypot(xx - x, yy - y))
        ux, uy = (xx - x) / length, (yy - y) / length
        endx, endy = xx - ux * 10, yy - uy * 10
        shade = colors.HexColor("#b67962" if edge["risk_score"] >= 61 else "#95ae8b")
        drawing.add(
            Line(x + ux * 9, y + uy * 9, endx, endy, strokeColor=shade, strokeWidth=0.5)
        )
        drawing.add(
            Polygon(
                [
                    endx,
                    endy,
                    endx - ux * 5 + uy * 2,
                    endy - uy * 5 - ux * 2,
                    endx - ux * 5 - uy * 2,
                    endy - uy * 5 + ux * 2,
                ],
                fillColor=shade,
                strokeColor=None,
            )
        )
    palette = {
        "SAFE": "#4a805b",
        "SUSPICIOUS": "#b29841",
        "HIGH RISK": "#bd7e43",
        "CRITICAL": "#b95951",
    }
    for node in nodes:
        x, y = positions[node["id"]]
        shade = colors.HexColor(palette[node["risk_level"]])
        drawing.add(
            Circle(
                x,
                y,
                8 if node["risk_score"] >= 81 else 5.5,
                fillColor=colors.white,
                strokeColor=shade,
                strokeWidth=1.2,
            )
        )
        drawing.add(Circle(x, y, 2, fillColor=shade, strokeColor=None))
        drawing.add(
            String(
                x,
                y - 17,
                node["id"][-11:],
                fontName="Helvetica",
                fontSize=6.5,
                textAnchor="middle",
                fillColor=colors.HexColor("#485440"),
            )
        )
    for i, (level, color) in enumerate(palette.items()):
        drawing.add(
            Circle(
                30 + i * 122,
                15,
                2.5,
                fillColor=colors.HexColor(color),
                strokeColor=None,
            )
        )
        drawing.add(
            String(
                39 + i * 122,
                12,
                level,
                fontName="Helvetica",
                fontSize=6.5,
                fillColor=colors.HexColor("#63715b"),
            )
        )
    return drawing


def build_report(case):
    buf = BytesIO()
    doc = SimpleDocTemplate(
        buf,
        pagesize=(595.27, 841.89),
        rightMargin=42,
        leftMargin=42,
        topMargin=42,
        bottomMargin=44,
        title=f"MuleHunter AI | {case['id']}",
        author="MuleHunter AI synthetic investigation workspace",
    )
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="Brand",
            fontName="Helvetica-Bold",
            fontSize=23,
            textColor=colors.HexColor("#203c2a"),
            spaceAfter=8,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Eyebrow",
            fontSize=9,
            textColor=colors.HexColor("#568d62"),
            spaceAfter=16,
        )
    )
    styles["BodyText"].leading = 15
    story = [
        Paragraph("MuleHunter AI", styles["Brand"]),
        Paragraph(
            "FINANCIAL NETWORK INTELLIGENCE / INVESTIGATION REPORT", styles["Eyebrow"]
        ),
        Paragraph(escape(case["id"]), styles["Heading2"]),
        Paragraph(escape(case["title"]), styles["Title"]),
        Paragraph(
            "SYNTHETIC DATA — PROTOTYPE — HUMAN REVIEW REQUIRED", styles["Eyebrow"]
        ),
    ]
    summary = [
        ["Case status", case["status"].replace("_", " ").title()],
        ["Risk at case creation", f"{case['risk_score']}/100 · {case['risk_level']}"],
        ["Accounts in scope", str(len(case["account_ids"]))],
        ["Gross connected transaction volume", f"INR {case['volume']:,.2f}"],
        ["Transactions in scope", str(case["transaction_count"])],
        ["Created (UTC)", case["created_at"][:19]],
        ["Recommended action", case["recommended_action"]],
    ]
    table = Table(summary, colWidths=[245, 266])
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f1f5f0")),
                ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
                ("TOPPADDING", (0, 0), (-1, -1), 9),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 9),
                ("LINEBELOW", (0, 0), (-1, -1), 0.5, colors.white),
            ]
        )
    )
    story.extend(
        [
            Spacer(1, 14),
            table,
            Spacer(1, 18),
            Paragraph(
                "Structured evidence (captured at case creation)", styles["Heading2"]
            ),
        ]
    )
    for e in case["evidence"]:
        story.extend(
            [
                Paragraph(escape(e["title"]), styles["Heading3"]),
                Paragraph(escape(e["detail"]), styles["BodyText"]),
            ]
        )
    story.extend(
        [
            Spacer(1, 16),
            KeepTogether(
                [
                    Paragraph("Current investigation topology", styles["Heading2"]),
                    network_drawing(case["network"]),
                    Paragraph(
                        "Directed account-pair edges. Up to 24 highest-risk in-scope accounts are drawn; labels may be abbreviated. Full identifiers appear below.",
                        styles["BodyText"],
                    ),
                ]
            ),
            Spacer(1, 16),
            Paragraph("Current account analysis", styles["Heading2"]),
        ]
    )
    rows = [["Account", "Risk", "Transfers", "Exposure"]]
    for a in sorted(case["accounts"], key=lambda a: -a["risk_score"]):
        rows.append(
            [
                a["id"],
                f"{a['risk_score']}/100",
                str(a["metrics"]["transaction_count"]),
                f"{a['metrics']['risk_exposure']:.0f}/100",
            ]
        )
    table = Table(rows, colWidths=[200, 95, 110, 106], repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#203c2a")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
                ("TOPPADDING", (0, 0), (-1, -1), 8),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                (
                    "ROWBACKGROUNDS",
                    (0, 1),
                    (-1, -1),
                    [colors.HexColor("#f1f5f0"), colors.white],
                ),
            ]
        )
    )
    story.extend(
        [
            table,
            Spacer(1, 16),
            Paragraph("Observed patterns", styles["Heading2"]),
            Paragraph(
                escape(
                    ", ".join(case["patterns"])
                    or "No active network motifs in the current window."
                ),
                styles["BodyText"],
            ),
        ]
    )
    recent = case["timeline"][-25:]
    if recent:
        story.extend(
            [
                Spacer(1, 16),
                Paragraph("Recent transaction trail", styles["Heading2"]),
                Paragraph(
                    f"Latest {len(recent)} of {case['transaction_count']} in-scope payments, in event-time order. Amounts are INR; times below are UTC.",
                    styles["BodyText"],
                ),
                Spacer(1, 10),
            ]
        )
        rows = [["Transaction", "Sender", "Receiver", "Amount (INR)", "Time (UTC)"]]
        rows.extend(
            [
                [
                    t["transaction_id"],
                    t["sender"],
                    t["receiver"],
                    f"{t['amount']:,.0f}",
                    t["timestamp"][11:19],
                ]
                for t in recent
            ]
        )
        trail = Table(rows, colWidths=[90, 112, 112, 102, 95], repeatRows=1)
        trail.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#203c2a")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("FONTSIZE", (0, 0), (-1, -1), 7),
                    ("TOPPADDING", (0, 0), (-1, -1), 6),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                    (
                        "ROWBACKGROUNDS",
                        (0, 1),
                        (-1, -1),
                        [colors.HexColor("#f1f5f0"), colors.white],
                    ),
                ]
            )
        )
        story.append(trail)
    story.extend(
        [
            Paragraph("Analyst notes", styles["Heading2"]),
            Paragraph(
                escape(case["notes"] or "No analyst notes recorded.").replace(
                    "\n", "<br/>"
                ),
                styles["BodyText"],
            ),
            Spacer(1, 16),
            Paragraph("Methodology & limitations", styles["Heading2"]),
            Paragraph(
                "Weighted additive score: behavioral 25%, velocity 20%, graph 25%, temporal 15%, exposure 15%. Isolation Forest and Random Forest use synthetic reference populations. Model probabilities are uncalibrated experimental estimates. NetworkX computes communities, centralities, short directed cycles and three-hop exposure. Timing matches and candidate paths do not establish fund provenance.",
                styles["BodyText"],
            ),
            Paragraph(
                "All accounts and payments are fictional. Potential exposure is gross high-risk transaction volume and can count the same funds at multiple hops. This is not verified loss or prevented fraud. A high score is a signal for human review, not proof of wrongdoing. No account blocking, bank reporting, or enforcement occurs.",
                styles["BodyText"],
            ),
        ]
    )

    def footer(canvas, _):
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#6b7b70"))
        canvas.drawString(
            42,
            26,
            f"MuleHunter AI  |  {case['id']}  |  Synthetic decision-support prototype",
        )
        canvas.drawRightString(550, 26, str(doc.page))

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return buf.getvalue()
