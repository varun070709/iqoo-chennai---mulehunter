"""Value-conserving FIFO flow matching; chronological, bounded path detection."""

from collections import defaultdict, deque
from datetime import timedelta


def analyze_temporal(accounts: list, transactions: list, now) -> dict:
    events = defaultdict(list)
    recent_cutoff = now - timedelta(hours=1)
    for tx in transactions:
        if recent_cutoff <= tx["timestamp"] <= now:
            events[tx["sender"]].append(
                (tx["timestamp"], "out", tx["amount"], tx["transaction_type"])
            )
            events[tx["receiver"]].append(
                (tx["timestamp"], "in", tx["amount"], tx["transaction_type"])
            )
    result = {}
    for account in accounts:
        pending = deque()
        received, rapidly_forwarded, cashout = 0.0, 0.0, 0.0
        for time, kind, amount, tx_type in sorted(
            events[account["id"]], key=lambda e: (e[0], e[1] != "in")
        ):
            if kind == "in":
                pending.append([time, amount])
                received += amount
                continue
            if tx_type == "CASHOUT":
                cashout += amount
            left = amount
            while pending and left > 0:
                origin, available = pending[0]
                matched = min(left, available)
                if 0 <= (time - origin).total_seconds() <= 300:
                    rapidly_forwarded += matched
                pending[0][1] -= matched
                left -= matched
                if pending[0][1] <= 0.001:
                    pending.popleft()
        ratio = min(1, rapidly_forwarded / max(received, 1))
        score = min(100, ratio * 100 + (30 if cashout >= 50000 else 0))
        result[account["id"]] = {
            "rapid_forward_ratio": round(ratio, 3),
            "cashout_amount": round(cashout, 2),
            "temporal_risk": round(score, 1),
            "matched_volume": round(rapidly_forwarded, 2),
        }
    return result


def chronological_paths(
    transactions: list, start: str, max_hops=5, max_gap=300, limit=16
) -> list:
    """A path must move forward in time, use unique edges, and preserve at least
    25% of the previous transfer value. These are plausible flows, not proof of
    fund provenance (balances and mixed funds are not modeled)."""
    outgoing = defaultdict(list)
    for tx in sorted(transactions, key=lambda t: t["timestamp"]):
        if tx["amount"] >= 2000:
            outgoing[tx["sender"]].append(tx)
    paths, seen = [], set()
    explored = 0

    def visit(node, chain):
        nonlocal explored
        explored += 1
        if len(paths) >= limit or explored > 6000:
            return
        if len(chain) >= 2:
            key = tuple(t["id"] for t in chain)
            if key not in seen:
                paths.append(chain[:])
                seen.add(key)
        if len(chain) >= max_hops:
            return
        for tx in outgoing[node][-100:]:
            if chain:
                gap = (tx["timestamp"] - chain[-1]["timestamp"]).total_seconds()
                if not 0 < gap <= max_gap or tx["amount"] < chain[-1]["amount"] * 0.25:
                    continue
                if tx["id"] in {t["id"] for t in chain}:
                    continue
            visit(tx["receiver"], chain + [tx])
            if len(paths) >= limit:
                break

    visit(start, [])
    return sorted(paths, key=len, reverse=True)
