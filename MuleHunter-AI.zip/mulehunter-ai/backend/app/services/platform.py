"""Single-process orchestration service. SQLite is the source of persistence;
immutable API snapshots are derived after each atomic analysis cycle."""

import csv
import io
import os
import threading
import time
from collections import Counter, deque
from datetime import timedelta
from sqlalchemy import select, delete, update
from app.database.session import Base, engine, SessionLocal
from app.models.entities import Account, Transaction, InvestigationCase, utcnow
from app.ml.anomaly_model import AnomalyModel
from app.services.fraud_detector import FraudDetector
from app.services.temporal_analyzer import chronological_paths
from app.services.risk_engine import risk_level
from app.simulation.simulation_engine import SimulationEngine


def iso(value):
    return value.isoformat() + "Z" if value else None


def tx_json(tx):
    return {
        "id": tx["id"],
        "transaction_id": f"TXN-{tx['id']:06d}",
        "sender": tx["sender"],
        "receiver": tx["receiver"],
        "amount": tx["amount"],
        "timestamp": iso(tx["timestamp"]),
        "transaction_type": tx["transaction_type"],
        "device_hash": tx.get("device_hash", "SIMULATED-DEVICE"),
        "location_cluster": tx.get("location_cluster", "SIMULATED"),
        "risk_score": tx.get("risk_score", 0),
        "risk_level": tx.get("risk_level", "SAFE"),
        "flags": tx.get("flags", []),
        "synthetic": True,
    }


class Platform:
    def __init__(self):
        self.lock = threading.RLock()
        self.simulator = SimulationEngine()
        self.detector = FraudDetector(AnomalyModel())
        self.durations = deque(maxlen=20)
        self.stream_running = os.getenv("MULEHUNTER_AUTO_STREAM", "true").lower() in {
            "1",
            "true",
            "yes",
        }
        self.stream_speed = 1.0
        self.stream_fraud_percentage = 0
        self.stream_pattern = "normal"
        self.attack_running = False
        self.attack_progress = None
        self.version = 0
        self.accounts = []
        self.transactions = []
        self.analyses = {}
        self.rings = []
        self.graph = None
        self.last_analysis = utcnow()
        Base.metadata.create_all(engine)
        with SessionLocal() as db:
            exists = db.scalar(select(Account.id).limit(1))
        if not exists:
            accounts, txs = self.simulator.seed(utcnow())
            self.insert(accounts, txs, analyze=False)
        self.reload()
        self.refresh()
        self.auto_cases()

    def reload(self):
        with self.lock, SessionLocal() as db:
            self.accounts = [
                {
                    "id": a.id,
                    "label": a.label,
                    "account_type": a.account_type,
                    "created_at": a.created_at,
                    "device_hash": a.device_hash,
                    "location_cluster": a.location_cluster,
                }
                for a in db.scalars(select(Account)).all()
            ]
            self.transactions = [
                {
                    "id": t.id,
                    "sender": t.sender,
                    "receiver": t.receiver,
                    "amount": t.amount,
                    "timestamp": t.timestamp,
                    "transaction_type": t.transaction_type,
                    "device_hash": t.device_hash,
                    "location_cluster": t.location_cluster,
                    "risk_score": t.risk_score,
                    "risk_level": t.risk_level,
                    "flags": t.flags,
                }
                for t in db.scalars(
                    select(Transaction).order_by(Transaction.timestamp)
                ).all()
            ]

    def insert(self, accounts, transactions, analyze=True):
        with self.lock, SessionLocal() as db:
            if (
                len(self.accounts) + len(accounts) > 2000
                or len(self.transactions) + len(transactions) > 50000
            ):
                raise ValueError(
                    "Local prototype capacity reached (2,000 accounts / 50,000 transfers). Export cases and reset the network."
                )
            db.add_all([Account(**a) for a in accounts])
            db.flush()
            db.add_all([Transaction(**t) for t in transactions])
            db.commit()
        if analyze:
            self.reload()
            self.refresh()

    def refresh(self):
        with self.lock:
            started = time.perf_counter()
            now = utcnow()
            self.analyses, self.rings, self.graph = self.detector.analyze(
                self.accounts, self.transactions, now
            )
            with SessionLocal() as db:
                db.execute(
                    update(Account),
                    [
                        {
                            "id": aid,
                            "risk_score": a["risk_score"],
                            "risk_level": a["risk_level"],
                            "analysis": a,
                        }
                        for aid, a in self.analyses.items()
                    ],
                )
                if self.transactions:
                    db.execute(
                        update(Transaction),
                        [
                            {
                                "id": t["id"],
                                "risk_score": t["risk_score"],
                                "risk_level": t["risk_level"],
                                "flags": t["flags"],
                            }
                            for t in self.transactions
                        ],
                    )
                db.commit()
            self.durations.append((time.perf_counter() - started) * 1000)
            self.last_analysis = now
            self.version += 1

    def dashboard(self):
        with self.lock:
            counts = Counter(t["risk_level"] for t in self.transactions)
            account_counts = Counter(a["risk_level"] for a in self.analyses.values())
            now = utcnow()
            cutoff = now - timedelta(hours=1)
            recent = [t for t in self.transactions if t["timestamp"] >= cutoff]
            hourly = []
            for h in range(11, -1, -1):
                begin = now.replace(minute=0, second=0, microsecond=0) - timedelta(
                    hours=h
                )
                bucket = [
                    t
                    for t in self.transactions
                    if begin <= t["timestamp"] < begin + timedelta(hours=1)
                ]
                hourly.append(
                    {
                        "time": iso(begin),
                        "transactions": len(bucket),
                        "flagged": sum(t["risk_score"] >= 31 for t in bucket),
                        "volume": round(sum(t["amount"] for t in bucket), 2),
                    }
                )
            return {
                "total_transactions": len(self.transactions),
                "total_accounts": len(self.accounts),
                "suspicious_transactions": sum(
                    v for k, v in counts.items() if k != "SAFE"
                ),
                "high_risk_accounts": sum(
                    a["risk_score"] >= 61 for a in self.analyses.values()
                ),
                "active_fraud_networks": len(self.rings),
                "average_detection_time": round(
                    sum(self.durations) / max(1, len(self.durations)), 1
                ),
                "potential_fraud_amount": round(
                    sum(
                        t["amount"] for t in self.transactions if t["risk_score"] >= 61
                    ),
                    2,
                ),
                "total_volume": round(sum(t["amount"] for t in self.transactions), 2),
                "last_hour_transactions": len(recent),
                "last_hour_flagged": sum(t["risk_score"] >= 31 for t in recent),
                "risk_distribution": [
                    {"level": k, "count": account_counts[k], "transactions": counts[k]}
                    for k in ["SAFE", "SUSPICIOUS", "HIGH RISK", "CRITICAL"]
                ],
                "hourly": hourly,
                "alerts": self.alerts(),
                "stream_running": self.stream_running,
                "stream_speed": self.stream_speed,
                "attack_running": self.attack_running,
                "attack_progress": self.attack_progress,
                "last_analysis_at": iso(self.last_analysis),
                "version": self.version,
                "model_status": "synthetic-trained",
                "synthetic": True,
            }

    def alerts(self):
        return [
            {
                "id": r["id"],
                "title": (
                    "Coordinated mule network"
                    if "Fan-in" in r["patterns"]
                    else (
                        "Circular fund movement"
                        if "Circular flow" in r["patterns"]
                        else "Rapid fund layering"
                    )
                ),
                "risk_score": r["risk_score"],
                "risk_level": risk_level(r["risk_score"]),
                "account_id": r["hub"],
                "member_count": r["member_count"],
                "volume": r["volume"],
                "patterns": r["patterns"],
                "description": (
                    r["reasons"][0]
                    if r["reasons"]
                    else "Connected behavioral and graph signals."
                ),
                "timestamp": r["detected_at"],
            }
            for r in self.rings[:8]
        ]

    def account(self, aid):
        with self.lock:
            meta = next((a for a in self.accounts if a["id"] == aid), None)
            if not meta:
                raise KeyError(aid)
            related = [
                t
                for t in self.transactions
                if t["sender"] == aid or t["receiver"] == aid
            ]
            return {
                **meta,
                "created_at": iso(meta["created_at"]),
                **self.analyses[aid],
                "transactions": [
                    tx_json(t)
                    for t in sorted(
                        related, key=lambda t: t["timestamp"], reverse=True
                    )[:80]
                ],
                "rings": [r["id"] for r in self.rings if aid in r["members"]],
                "synthetic": True,
            }

    def account_list(self, query="", level="ALL", limit=100, offset=0):
        with self.lock:
            rows = [
                {
                    "id": a["id"],
                    "label": a["label"],
                    "account_type": a["account_type"],
                    **self.analyses[a["id"]],
                }
                for a in self.accounts
                if query.lower() in a["id"].lower()
                and (level == "ALL" or self.analyses[a["id"]]["risk_level"] == level)
            ]
            rows.sort(key=lambda a: (-a["risk_score"], a["id"]))
            return {"items": rows[offset : offset + limit], "total": len(rows)}

    def transaction_list(self, query="", level="ALL", limit=50, offset=0, hours=24):
        with self.lock:
            cutoff = utcnow() - timedelta(hours=hours)
            rows = [
                t
                for t in self.transactions
                if (level == "ALL" or t["risk_level"] == level)
                and t["timestamp"] >= cutoff
                and (
                    not query
                    or query.lower()
                    in f"TXN-{t['id']:06d} {t['sender']} {t['receiver']}".lower()
                )
            ]
            rows.sort(key=lambda t: t["id"], reverse=True)
            return {
                "items": [tx_json(t) for t in rows[offset : offset + limit]],
                "total": len(rows),
            }

    def network(self, limit=90, level="ALL", hours=24, focus=None, members=None):
        with self.lock:
            cutoff = utcnow() - timedelta(hours=hours)
            available = {
                a["id"]
                for a in self.accounts
                if level == "ALL" or self.analyses[a["id"]]["risk_level"] == level
            }
            if members is not None:
                selected = set(members) & available
            elif focus and focus in self.graph.graph:
                selected = (
                    {focus}
                    | set(self.graph.graph.predecessors(focus))
                    | set(self.graph.graph.successors(focus))
                )
                selected &= available
                selected = set(
                    sorted(
                        selected,
                        key=lambda n: (n != focus, -self.analyses[n]["risk_score"]),
                    )[:limit]
                )
            else:
                # Representative view includes detected rings plus high-influence reference accounts.
                hot = {n for r in self.rings for n in r["members"]} & available
                ranked = sorted(
                    available - hot,
                    key=lambda n: (
                        -self.analyses[n]["metrics"]["network_centrality"],
                        n,
                    ),
                )
                selected = set(
                    sorted(hot, key=lambda n: -self.analyses[n]["risk_score"])[:limit]
                )
                selected.update(ranked[: max(0, limit - len(selected))])
            ring_map = {n: r["id"] for r in self.rings for n in r["members"]}
            nodes = [
                {
                    "id": n,
                    "risk_score": self.analyses[n]["risk_score"],
                    "risk_level": self.analyses[n]["risk_level"],
                    "community": self.analyses[n]["metrics"]["community"],
                    "ring_id": ring_map.get(n),
                    "influence": self.analyses[n]["metrics"]["network_centrality"],
                    "transaction_count": self.analyses[n]["metrics"][
                        "transaction_count"
                    ],
                    "label": self.analyses[n]["explanation"]["primary_reason"],
                }
                for n in sorted(selected)
            ]
            aggregated = {}
            total_edges = 0
            for t in self.transactions:
                if t["timestamp"] < cutoff:
                    continue
                if t["sender"] in selected and t["receiver"] in selected:
                    key = f"{t['sender']}>{t['receiver']}"
                    edge = aggregated.setdefault(
                        key,
                        {
                            "id": key,
                            "source": t["sender"],
                            "target": t["receiver"],
                            "amount": 0,
                            "count": 0,
                            "risk_score": 0,
                            "timestamp": iso(t["timestamp"]),
                            "transaction_type": t["transaction_type"],
                        },
                    )
                    edge["amount"] = round(edge["amount"] + t["amount"], 2)
                    edge["count"] += 1
                    edge["risk_score"] = max(edge["risk_score"], t["risk_score"])
                    edge["timestamp"] = max(edge["timestamp"], iso(t["timestamp"]))
                total_edges += 1
            all_edges = sorted(
                aggregated.values(), key=lambda e: (-e["risk_score"], -e["amount"])
            )
            return {
                "nodes": nodes,
                "edges": all_edges[:1500],
                "total_accounts": len(self.accounts),
                "total_transactions": total_edges,
                "visible_edges": len(all_edges[:1500]),
                "aggregated_edges": len(all_edges),
                "edge_limit": 1500,
                "communities": len(self.graph.communities),
                "components": len(self.graph.components),
                "cycle_count": len(self.graph.cycles),
                "ring_count": len(self.rings),
                "version": self.version,
                "note": "Edges aggregate directed payments between each account pair in the selected time window.",
            }

    def flows(self, aid):
        with self.lock:
            if aid not in self.analyses:
                raise KeyError(aid)
            cutoff = utcnow() - timedelta(hours=1)
            recent = [t for t in self.transactions if t["timestamp"] >= cutoff]
            paths = chronological_paths(recent, aid)
            return {
                "account_id": aid,
                "paths": [
                    {
                        "id": f"PATH-{i + 1:03}",
                        "hops": len(path),
                        "duration_seconds": round(
                            (
                                path[-1]["timestamp"] - path[0]["timestamp"]
                            ).total_seconds(),
                            1,
                        ),
                        "volume": round(min(t["amount"] for t in path), 2),
                        "circular": path[-1]["receiver"] == path[0]["sender"],
                        "events": [tx_json(t) for t in path],
                    }
                    for i, path in enumerate(paths)
                ],
                "patterns": list(
                    dict.fromkeys(
                        p
                        for r in self.rings
                        if aid in r["members"]
                        for p in r["patterns"]
                    )
                ),
                "note": "Chronological candidate chains: 2–5 hops, at most 5 minutes between hops, next transfer at least 25% of the previous value. Not proof of fund provenance.",
            }

    def propagation(self, aid):
        import networkx as nx

        with self.lock:
            if aid not in self.analyses:
                raise KeyError(aid)
            distances = nx.single_source_shortest_path_length(
                self.graph.active.to_undirected(), aid, cutoff=3
            )
            nodes = sorted(
                distances, key=lambda n: (distances[n], -self.analyses[n]["risk_score"])
            )[:120]
            graph = self.network(members=nodes, hours=1)
            for node in graph["nodes"]:
                node["distance"] = distances[node["id"]]
                node["exposure"] = self.analyses[node["id"]]["metrics"]["risk_exposure"]
                node["source_contribution"] = round(
                    sum(
                        p["contribution"]
                        for p in self.analyses[node["id"]]["propagation_sources"]
                        if p["source"] == aid
                    ),
                    1,
                )
            return {
                **graph,
                "source": aid,
                "source_risk": self.analyses[aid]["risk_score"],
                "note": "One-hour active graph. Influence decays by 0.66 per hop, weighted by payment amount, frequency and recency. Connections alone are not evidence of guilt.",
            }

    def create_case(
        self, account_ids, title="Suspected mule account network", ring_id=None
    ):
        with self.lock, SessionLocal() as db:
            if not account_ids or any(n not in self.analyses for n in account_ids):
                raise ValueError("Choose existing accounts to investigate.")
            count = len(db.scalars(select(InvestigationCase.id)).all())
            cid = f"CASE-{utcnow().year}-{count + 1:03}"
            highest = max(account_ids, key=lambda n: self.analyses[n]["risk_score"])
            analysis = self.analyses[highest]
            case = InvestigationCase(
                id=cid,
                title=title,
                ring_id=ring_id,
                account_ids=account_ids,
                risk_score=analysis["risk_score"],
                recommended_action=analysis["explanation"]["recommended_action"],
                evidence=analysis["explanation"]["evidence"],
            )
            db.add(case)
            db.commit()
            return self.case_json(case)

    def auto_cases(self):
        with self.lock, SessionLocal() as db:
            known = {c.ring_id for c in db.scalars(select(InvestigationCase)).all()}
            for ring in self.rings[:8]:
                if ring["id"] not in known:
                    self.create_case(
                        ring["members"], "Suspected mule account network", ring["id"]
                    )

    def case_json(self, c):
        return {
            "id": c.id,
            "title": c.title,
            "ring_id": c.ring_id,
            "account_ids": c.account_ids,
            "risk_score": c.risk_score,
            "risk_level": risk_level(c.risk_score),
            "status": c.status,
            "recommended_action": c.recommended_action,
            "notes": c.notes,
            "evidence": c.evidence,
            "created_at": iso(c.created_at),
            "updated_at": iso(c.updated_at),
            "synthetic": True,
        }

    def cases(self):
        with self.lock, SessionLocal() as db:
            return [
                self.case_json(c)
                for c in db.scalars(
                    select(InvestigationCase).order_by(
                        InvestigationCase.created_at.desc()
                    )
                ).all()
            ]

    def investigation(self, cid):
        with self.lock, SessionLocal() as db:
            case = db.get(InvestigationCase, cid)
            if not case:
                raise KeyError(cid)
            data = self.case_json(case)
            members = set(case.account_ids)
            txs = [
                t
                for t in self.transactions
                if t["sender"] in members or t["receiver"] in members
            ]
            data.update(
                {
                    "accounts": [
                        {"id": n, **self.analyses[n]}
                        for n in members
                        if n in self.analyses
                    ],
                    "volume": round(sum(t["amount"] for t in txs), 2),
                    "transaction_count": len(txs),
                    "timeline": [
                        tx_json(t) for t in sorted(txs, key=lambda t: t["timestamp"])
                    ][-200:],
                    "network": self.network(members=members),
                    "patterns": list(
                        dict.fromkeys(
                            p
                            for r in self.rings
                            if members.intersection(r["members"])
                            for p in r["patterns"]
                        )
                    ),
                }
            )
            return data

    def update_case(self, cid, fields):
        with self.lock, SessionLocal() as db:
            case = db.get(InvestigationCase, cid)
            if not case:
                raise KeyError(cid)
            for key, value in fields.items():
                if value is not None:
                    setattr(case, key, value)
            case.updated_at = utcnow()
            db.commit()
            return self.case_json(case)

    def reset(
        self,
        account_count=500,
        transaction_count=5000,
        fraud_percentage=8,
        pattern="demo",
    ):
        with self.lock:
            was_running = self.stream_running
            self.stream_running = False
            with SessionLocal() as db:
                db.execute(delete(InvestigationCase))
                db.execute(delete(Transaction))
                db.execute(delete(Account))
                db.commit()
            self.accounts, self.transactions = [], []
            accounts, txs = self.simulator.seed(
                utcnow(), account_count, transaction_count, fraud_percentage, pattern
            )
            self.insert(accounts, txs)
            self.auto_cases()
            self.attack_progress = None
            self.stream_running = was_running
            return self.dashboard()

    def tick(self):
        with self.lock:
            ids = [a["id"] for a in self.accounts if a["id"].startswith("ACC-S")]
            if len(ids) < 2:
                ids = [a["id"] for a in self.accounts]
            count = max(1, round(self.stream_speed * 3))
            txs = self.simulator.normal(ids, count, utcnow())
            self.insert([], txs)
            if (
                self.stream_fraud_percentage
                and self.simulator.rng.random() < self.stream_fraud_percentage / 100
            ):
                self.inject(
                    (
                        self.stream_pattern
                        if self.stream_pattern != "normal"
                        else "suspicious"
                    ),
                    10,
                )

    def inject(self, pattern, count=12):
        with self.lock:
            accounts, batches = self.simulator.attack(
                [a["id"] for a in self.accounts],
                utcnow(),
                pattern,
                count,
                prefix=f"D{len(self.accounts):04X}",
            )
            txs = [t for _, batch in batches for t in batch]
            self.insert(accounts, txs)
            self.auto_cases()
            return {
                "new_accounts": len(accounts),
                "new_transactions": len(txs),
                "hub": accounts[0]["id"],
                "account_ids": [a["id"] for a in accounts],
                "rings": self.rings,
                "dashboard": self.dashboard(),
            }

    def export_csv(self):
        with self.lock:
            buffer = io.StringIO()
            writer = csv.DictWriter(
                buffer,
                fieldnames=[
                    "transaction_id",
                    "sender",
                    "receiver",
                    "amount",
                    "timestamp",
                    "transaction_type",
                    "risk_score",
                    "risk_level",
                    "synthetic",
                ],
            )
            writer.writeheader()
            for t in self.transactions:
                record = tx_json(t)
                writer.writerow({k: record[k] for k in writer.fieldnames})
            return buffer.getvalue()
