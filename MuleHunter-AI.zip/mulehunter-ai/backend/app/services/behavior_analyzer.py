from collections import defaultdict
from datetime import timedelta
import numpy as np


def build_behavior(accounts: list, transactions: list, now, graph_stats: dict) -> dict:
    incoming, outgoing, all_tx = defaultdict(list), defaultdict(list), defaultdict(list)
    for tx in transactions:
        incoming[tx["receiver"]].append(tx)
        outgoing[tx["sender"]].append(tx)
        all_tx[tx["receiver"]].append(tx)
        all_tx[tx["sender"]].append(tx)
    result = {}
    cutoff = now - timedelta(minutes=20)
    hour_ago = now - timedelta(hours=1)
    for account in accounts:
        aid = account["id"]
        txs = sorted(all_tx[aid], key=lambda t: t["timestamp"])
        inc, out = incoming[aid], outgoing[aid]
        recent = [t for t in txs if cutoff <= t["timestamp"] <= now]
        recent_in = [t for t in inc if cutoff <= t["timestamp"] <= now]
        recent_out = [t for t in out if cutoff <= t["timestamp"] <= now]
        counterparties = {
            t["sender"] if t["receiver"] == aid else t["receiver"] for t in txs
        }
        in_unique = len({t["sender"] for t in recent_in})
        out_unique = len({t["receiver"] for t in recent_out})
        active = [t for t in txs if t["timestamp"] >= hour_ago]
        interval_txs = active if len(active) >= 2 else txs
        intervals = [
            (b["timestamp"] - a["timestamp"]).total_seconds()
            for a, b in zip(interval_txs, interval_txs[1:])
        ]
        incoming_amount = sum(t["amount"] for t in inc)
        outgoing_amount = sum(t["amount"] for t in out)
        graph = graph_stats.get(aid, {})
        result[aid] = {
            "transaction_count": len(txs),
            "recent_count": len(recent),
            "transaction_velocity": round(len(recent) / 20, 2),
            "average_transaction_value": round(
                float(np.mean([t["amount"] for t in txs])) if txs else 0, 2
            ),
            "maximum_transaction_value": max([t["amount"] for t in txs], default=0),
            "incoming_amount": round(incoming_amount, 2),
            "outgoing_amount": round(outgoing_amount, 2),
            "unique_counterparties": len(counterparties),
            "recent_incoming_counterparties": in_unique,
            "recent_outgoing_counterparties": out_unique,
            "recent_incoming_amount": round(sum(t["amount"] for t in recent_in), 2),
            "fan_in_ratio": round(in_unique / max(1, out_unique), 2),
            "fan_out_ratio": round(out_unique / max(1, in_unique), 2),
            "fan_in_score": min(100, in_unique * 12.5),
            "fan_out_score": min(100, out_unique * 12.5),
            "average_transaction_interval": round(
                float(np.mean(intervals)) if intervals else 86400, 1
            ),
            "incoming_outgoing_ratio": round(
                incoming_amount / max(outgoing_amount, 1), 2
            ),
            "network_degree": graph.get("degree", 0),
            "network_centrality": graph.get("betweenness", 0),
            "community": graph.get("community", 0),
            "in_cycle": graph.get("in_cycle", False),
            "circular_transaction_probability": 90 if graph.get("in_cycle") else 0,
            "risk_exposure": 0,
            "suspicious_connections": 0,
        }
    return result


def feature_vector(m: dict) -> list[float]:
    return [
        m["average_transaction_value"],
        m["recent_count"],
        m["unique_counterparties"],
        m["incoming_outgoing_ratio"],
        m["average_transaction_interval"],
        m["network_degree"],
        m["network_centrality"],
        m["fan_in_score"],
        m["fan_out_score"],
        m["risk_exposure"],
    ]
