from app.services.risk_engine import WEIGHTS


def explain(metrics, scores, ml, risk):
    evidence = []

    def add(signal, title, detail, severity="HIGH RISK"):
        evidence.append(
            {
                "signal": signal,
                "title": title,
                "detail": detail,
                "severity": severity,
                "contribution": round(scores[signal] * WEIGHTS[signal], 1),
            }
        )

    if metrics["recent_count"] >= 6:
        add(
            "velocity",
            "Unusual transaction velocity",
            f"{metrics['recent_count']} transfers in the last 20 minutes; {metrics['average_transaction_interval']:.0f}s average spacing in the recent active window.",
            "CRITICAL" if metrics["recent_count"] >= 12 else "HIGH RISK",
        )
    if metrics["recent_incoming_counterparties"] >= 4:
        add(
            "graph",
            "Concentrated fan-in activity",
            f"Received INR {metrics['recent_incoming_amount']:,.0f} from {metrics['recent_incoming_counterparties']} distinct accounts within 20 minutes.",
        )
    if metrics["recent_outgoing_counterparties"] >= 4:
        add(
            "graph",
            "Coordinated fan-out pattern",
            f"Dispersed funds to {metrics['recent_outgoing_counterparties']} distinct accounts within 20 minutes.",
        )
    if metrics["rapid_forward_ratio"] >= 0.4:
        add(
            "temporal",
            "Rapid pass-through of funds",
            f"{metrics['rapid_forward_ratio']:.0%} of received value was matched to outgoing transfers within five minutes using FIFO flow matching.",
            "CRITICAL",
        )
    if metrics["in_cycle"]:
        add(
            "graph",
            "Circular money movement",
            "Participates in a directed cycle of two to four accounts in the active one-hour transaction graph.",
        )
    if metrics["cashout_amount"] >= 50000:
        add(
            "temporal",
            "Sudden cash-out behavior",
            f"INR {metrics['cashout_amount']:,.0f} moved via simulated cash-out transfers in the last hour.",
            "CRITICAL",
        )
    if metrics["suspicious_connections"]:
        add(
            "exposure",
            "Exposure to high-risk accounts",
            f"{metrics['suspicious_connections']} directly connected accounts score 61 or higher; distance-decayed network exposure is {metrics['risk_exposure']:.0f}/100.",
        )
    if ml["anomaly_score"] >= 55:
        add(
            "behavioral",
            "Deviation from synthetic baseline",
            f"Isolation Forest anomaly score: {ml['anomaly_score']:.1f}/100. The reference population is synthetic, not a validated banking dataset.",
            "SUSPICIOUS",
        )
    evidence.sort(key=lambda e: e["contribution"], reverse=True)
    if not evidence:
        add(
            "behavioral",
            "Within reference behavior",
            "No strong behavioral, timing or network signals in this observation window. A low score does not guarantee legitimate activity.",
            "SAFE",
        )
    primary = evidence[0]["title"]
    summary = f"Risk score {risk}/100. {primary}. " + " ".join(
        e["detail"] for e in evidence[:3]
    )
    action = (
        "Escalate for Investigation"
        if risk >= 81
        else (
            "Temporarily Flag"
            if risk >= 61
            else "Request Additional Verification" if risk >= 31 else "Monitor"
        )
    )
    return {
        "primary_reason": primary,
        "summary": summary,
        "evidence": evidence,
        "recommended_action": action,
        "disclaimer": "Synthetic-data prototype. Signals support human review; they are not a finding of fraud. No account is blocked or reported automatically.",
    }
