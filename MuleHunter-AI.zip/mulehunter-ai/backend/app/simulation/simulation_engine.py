"""Fictional Indian payment generator with auditable attack scenarios."""

from datetime import timedelta
import random
import uuid


class SimulationEngine:
    def __init__(self, seed=42):
        self.rng = random.Random(seed)

    def accounts(self, count, prefix=None, now=None):
        prefix = prefix or uuid.uuid4().hex[:6].upper()
        return [
            {
                "id": f"ACC-{prefix}{i:03X}",
                "label": f"Synthetic wallet {i + 1:03}",
                "account_type": "merchant" if i % 9 == 0 else "wallet",
                "device_hash": f"SIMULATED-DEVICE-{prefix}{i:04X}",
                "location_cluster": f"SIMULATED-{['SOUTH', 'NORTH', 'EAST', 'WEST'][i % 4]}",
                "created_at": now - timedelta(days=self.rng.randint(30, 730)),
            }
            for i in range(count)
        ]

    def tx(self, sender, receiver, amount, timestamp, scenario="normal", kind="UPI"):
        return {
            "sender": sender,
            "receiver": receiver,
            "amount": round(max(1, amount), 2),
            "timestamp": timestamp,
            "transaction_type": kind,
            "device_hash": f"SIMULATED-DEVICE-{sender[4:]}",
            "location_cluster": "SIMULATED",
            "scenario": scenario,
        }

    def normal(self, account_ids, count, now, historical=False):
        result = []
        for _ in range(count):
            index = self.rng.randrange(len(account_ids))
            # Mostly local commerce, some cross-community payments.
            pool = account_ids[
                index // 38 * 38 : min(len(account_ids), index // 38 * 38 + 38)
            ]
            if len(pool) < 2 or self.rng.random() < 0.16:
                pool = account_ids
            receiver = self.rng.choice(pool)
            sender = account_ids[index]
            if receiver == sender:
                receiver = account_ids[(index + 1) % len(account_ids)]
            amount = min(45000, max(20, self.rng.lognormvariate(7.05, 0.88)))
            time = (
                now - timedelta(seconds=self.rng.uniform(0, 86400))
                if historical
                else now
            )
            result.append(
                self.tx(
                    sender,
                    receiver,
                    amount,
                    time,
                    kind=self.rng.choices(["UPI", "IMPS", "NEFT"], [0.88, 0.1, 0.02])[
                        0
                    ],
                )
            )
        return result

    def attack(self, existing_ids, now, pattern="demo", count=12, prefix=None):
        accounts = self.accounts(count, prefix=prefix, now=now)
        for account in accounts:
            account["account_type"] = (
                "wallet"  # No ground-truth label enters detection.
            )
            account["created_at"] = now - timedelta(days=1)
        ids = [a["id"] for a in accounts]
        hub, layer1, layer2, cashout = ids[0], ids[1], ids[2], ids[-1]
        donors = ids[3:-1]
        batches = []
        cursor = now - timedelta(seconds=250)
        if pattern in {"demo", "mule", "fraud_ring", "fan_in"}:
            txs = []
            for rep in range(3):
                for j, donor in enumerate(donors):
                    cursor += timedelta(seconds=2)
                    txs.append(
                        self.tx(
                            donor, hub, self.rng.randint(8000, 36000), cursor, pattern
                        )
                    )
            batches.append(("Fan-in detected", txs))
        if pattern in {"demo", "mule", "fraud_ring", "multi_hop", "suspicious"}:
            txs = []
            for rep in range(7):
                amount = self.rng.randint(42000, 69000)
                for sender, receiver in [
                    (hub, layer1),
                    (layer1, layer2),
                    (layer2, cashout),
                ]:
                    cursor += timedelta(seconds=3)
                    txs.append(
                        self.tx(
                            sender,
                            receiver,
                            amount,
                            cursor,
                            pattern,
                            "CASHOUT" if receiver == cashout else "UPI",
                        )
                    )
            batches.append(("Layering & cash-out detected", txs))
        if pattern in {"demo", "fraud_ring", "circular"}:
            txs = []
            circle = [hub, layer1, layer2]
            for _ in range(5):
                for i in range(3):
                    cursor += timedelta(seconds=2)
                    txs.append(
                        self.tx(
                            circle[i],
                            circle[(i + 1) % 3],
                            self.rng.randint(17000, 35000),
                            cursor,
                            pattern,
                        )
                    )
            batches.append(("Circular flow detected", txs))
        if pattern in {"demo", "fraud_ring", "fan_out"}:
            txs = []
            for _ in range(2):
                for recipient in donors:
                    cursor += timedelta(seconds=1)
                    txs.append(
                        self.tx(
                            layer2,
                            recipient,
                            self.rng.randint(6000, 15000),
                            cursor,
                            pattern,
                        )
                    )
            batches.append(("Network exposure calculated", txs))
        if pattern == "normal":
            batches.append(
                (
                    "Normal activity generated",
                    self.normal(ids, 35, now, historical=True),
                )
            )
        # Ensure synthetic event time never moves into the future.
        latest = max(
            (t["timestamp"] for _, batch in batches for t in batch), default=now
        )
        if latest > now:
            shift = latest - now
            for _, batch in batches:
                for tx in batch:
                    tx["timestamp"] -= shift
        return accounts, batches

    def seed(
        self,
        now,
        account_count=500,
        transaction_count=5000,
        fraud_percentage=8,
        pattern="demo",
    ):
        ring_count = (
            min(4, max(1, account_count // 100))
            if fraud_percentage > 0 and pattern != "normal"
            else 0
        )
        core_count = account_count - ring_count * 12
        accounts = self.accounts(core_count, prefix="S", now=now)
        normal_ids = [a["id"] for a in accounts]
        attack_tx = []
        for i in range(ring_count):
            new, batches = self.attack(
                normal_ids, now - timedelta(minutes=i * 2), pattern, 12, prefix=f"R{i}"
            )
            accounts.extend(new)
            attack_tx.extend(t for _, batch in batches for t in batch)
        target_attack = (
            int(transaction_count * fraud_percentage / 100) if ring_count else 0
        )
        # Repeat complete motifs to meet the requested synthetic transfer share.
        # Audit labels remain separate from all detector features.
        original = attack_tx[:]
        while original and len(attack_tx) < target_attack:
            repeat = len(attack_tx) // len(original)
            attack_tx.extend(
                {
                    **t,
                    "timestamp": t["timestamp"] - timedelta(seconds=repeat * 18),
                    "amount": round(t["amount"] * self.rng.uniform(0.85, 1.15), 2),
                }
                for t in original
            )
        attack_tx = attack_tx[:target_attack]
        transactions = self.normal(
            normal_ids, max(0, transaction_count - len(attack_tx)), now, historical=True
        )
        transactions.extend(attack_tx)
        return accounts, sorted(transactions, key=lambda t: t["timestamp"])
