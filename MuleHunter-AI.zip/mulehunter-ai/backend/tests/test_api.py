import pytest


def test_api_snapshots_and_pagination(client):
    health = client.get("/health")
    assert health.status_code == 200
    assert health.json()["synthetic"] is True
    assert "./openapi.json" in client.get("/docs").text
    assert client.get("/openapi.json").json()["servers"][0]["url"] == "."
    assert client.get("/network?focus=unknown").status_code == 404
    dashboard = client.get("/dashboard").json()
    assert dashboard["total_accounts"] == 500
    assert dashboard["total_transactions"] == 5000
    assert dashboard["active_fraud_networks"] >= 3
    assert dashboard["average_detection_time"] > 0
    a = client.get("/accounts?limit=7&offset=7").json()
    assert len(a["items"]) == 7 and a["total"] == 500
    tx = client.get("/transactions?limit=10").json()
    assert len(tx["items"]) == 10
    assert all(t["synthetic"] for t in tx["items"])
    assert client.get("/accounts/not-found").status_code == 404
    assert client.get("/network?limit=0").status_code == 422


def test_account_has_explainable_dna(client):
    aid = client.get("/accounts?limit=1").json()["items"][0]["id"]
    a = client.get("/accounts/" + aid).json()
    assert a["risk_score"] >= 81
    assert len(a["radar"]) == 6
    assert len(a["scores"]) == 5
    assert len(a["explanation"]["evidence"]) >= 3
    assert a["metrics"]["risk_exposure"] > 0
    assert a["transactions"]
    assert "not a" in a["ml"]["model_note"]
    assert (
        client.post("/analyze/account", json={"account_id": "missing"}).status_code
        == 404
    )


def test_network_risk_filter_and_edge_endpoints(client):
    graph = client.get("/network?limit=70&level=CRITICAL").json()
    nodes = {n["id"] for n in graph["nodes"]}
    assert graph["nodes"]
    assert all(n["risk_score"] >= 81 for n in graph["nodes"])
    assert all(e["source"] in nodes and e["target"] in nodes for e in graph["edges"])
    assert len(graph["edges"]) <= 1500


def test_flow_and_propagation(client):
    aid = client.get("/accounts?limit=1").json()["items"][0]["id"]
    flow = client.get("/flows", params={"account_id": aid}).json()
    assert flow["paths"]
    for p in flow["paths"]:
        assert 2 <= p["hops"] <= 5
        assert p["duration_seconds"] > 0
    exp = client.get("/propagation/" + aid).json()
    assert exp["source"] == aid
    assert max(n["distance"] for n in exp["nodes"]) <= 3
    assert all(0 <= n["exposure"] <= 100 for n in exp["nodes"])


def test_transaction_validation_and_preview_is_non_mutating(client):
    ids = [a["id"] for a in client.get("/accounts?limit=2").json()["items"]]
    before = client.get("/dashboard").json()["total_transactions"]
    assert (
        client.post(
            "/analyze/transaction",
            json={"sender": ids[0], "receiver": ids[0], "amount": 20},
        ).status_code
        == 422
    )
    assert (
        client.post(
            "/analyze/transaction",
            json={"sender": ids[0], "receiver": ids[1], "amount": -1},
        ).status_code
        == 422
    )
    assert (
        client.post(
            "/analyze/transaction",
            json={"sender": "missing", "receiver": ids[1], "amount": 100},
        ).status_code
        == 404
    )
    assert (
        client.post(
            "/analyze/transaction",
            json={
                "sender": ids[0],
                "receiver": ids[1],
                "amount": 100,
                "timestamp": "2099-01-01T00:00:00Z",
            },
        ).status_code
        == 422
    )
    r = client.post(
        "/analyze/transaction",
        json={"sender": ids[0], "receiver": ids[1], "amount": 25000, "persist": False},
    )
    assert r.status_code == 200
    assert r.json()["persisted"] is False
    assert client.get("/dashboard").json()["total_transactions"] == before
    r = client.post(
        "/analyze/transaction",
        json={"sender": ids[0], "receiver": ids[1], "amount": 25000},
    )
    assert r.status_code == 200
    assert r.json()["persisted"] is True
    assert r.json()["transaction"]["flags"]
    assert client.get("/dashboard").json()["total_transactions"] == before + 1


def test_case_lifecycle_and_pdf_export(client):
    aid = client.get("/accounts?limit=1").json()["items"][0]["id"]
    r = client.post(
        "/cases", json={"account_ids": [aid], "title": "Synthetic validation case"}
    )
    assert r.status_code == 201
    cid = r.json()["id"]
    patch = client.patch(
        "/cases/" + cid,
        json={
            "status": "in_review",
            "notes": "Review of synthetic velocity and flow evidence.",
        },
    )
    assert patch.status_code == 200
    data = client.get("/investigation/" + cid).json()
    assert data["notes"] == "Review of synthetic velocity and flow evidence."
    assert data["status"] == "in_review"
    assert data["accounts"] and data["timeline"] and data["network"]["nodes"]
    report = client.get("/investigation/" + cid + "/report")
    assert report.status_code == 200
    assert report.content.startswith(b"%PDF-") and len(report.content) > 2000
    assert cid in report.headers["content-disposition"]
    assert client.patch("/cases/" + cid, json={"status": "invalid"}).status_code == 422
    assert client.get("/investigation/missing").status_code == 404
    csv = client.get("/transactions/export")
    assert csv.status_code == 200 and b"transaction_id,sender,receiver" in csv.content


def test_staged_attack_over_websocket(client):
    before = client.get("/dashboard").json()
    with client.websocket_connect("/ws/live-transactions") as ws:
        initial = ws.receive_json()
        assert initial["type"] == "connected"
        assert "dashboard" in initial and "transactions" in initial
        response = client.post("/simulate/demo-attack")
        assert response.status_code == 202
        messages = []
        for _ in range(20):
            message = ws.receive_json()
            messages.append(message)
            if message["type"] == "attack_complete":
                break
        final = messages[-1]
        assert final["type"] == "attack_complete"
        progress = final["progress"]
        assert progress["complete"] is True
        assert progress["risk_score"] >= 81
        assert progress["ring_id"]
        assert progress["explanation"]
        assert len(progress["account_ids"]) == 12
        assert final["dashboard"]["total_accounts"] == before["total_accounts"] + 12
        assert (
            final["dashboard"]["total_transactions"] > before["total_transactions"] + 50
        )
        assert (
            final["dashboard"]["active_fraud_networks"]
            > before["active_fraud_networks"]
        )
        assert any(m.get("progress", {}).get("step") == 3 for m in messages)
    a = client.get("/accounts/" + progress["account_id"]).json()
    assert a["metrics"]["risk_exposure"] > 0
    assert a["rings"]
    cases = client.get("/cases").json()["items"]
    assert any(progress["account_id"] in c["account_ids"] for c in cases)


def test_simulation_controls_validate_before_reset(client):
    count = client.get("/dashboard").json()["total_accounts"]
    r = client.post("/simulate", json={"action": "generate", "number_of_accounts": 2})
    assert r.status_code == 422
    assert client.get("/dashboard").json()["total_accounts"] == count
    r = client.post(
        "/simulate",
        json={
            "action": "generate",
            "number_of_accounts": 100,
            "number_of_transactions": 700,
            "fraud_percentage": 35,
            "fraud_pattern": "fan_out",
        },
    )
    assert r.status_code == 200
    d = r.json()["dashboard"]
    assert d["total_accounts"] == 100 and d["total_transactions"] == 700
    assert (
        client.post("/simulate", json={"action": "stop"}).json()["dashboard"][
            "stream_running"
        ]
        is False
    )
