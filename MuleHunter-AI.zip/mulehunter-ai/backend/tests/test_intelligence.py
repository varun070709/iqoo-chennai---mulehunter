from datetime import datetime, timedelta
import math
import pytest
from app.services.risk_engine import risk_level, combine_scores, WEIGHTS
from app.services.temporal_analyzer import analyze_temporal, chronological_paths
from app.graph.graph_analyzer import GraphAnalyzer
from app.simulation.simulation_engine import SimulationEngine


@pytest.mark.parametrize(
    "score,level",
    [
        (0, "SAFE"),
        (30, "SAFE"),
        (31, "SUSPICIOUS"),
        (60, "SUSPICIOUS"),
        (61, "HIGH RISK"),
        (80, "HIGH RISK"),
        (81, "CRITICAL"),
        (100, "CRITICAL"),
    ],
)
def test_risk_thresholds(score, level):
    assert risk_level(score) == level


def test_weighted_score_is_normalized_and_bounded():
    assert sum(WEIGHTS.values()) == pytest.approx(1)
    assert combine_scores({k: 100 for k in WEIGHTS})[0] == 100
    assert combine_scores({k: 50 for k in WEIGHTS})[0] == 50
    assert combine_scores({k: 1000 for k in WEIGHTS})[0] == 100
    assert combine_scores({k: -10 for k in WEIGHTS})[0] == 0
    score, contributions = combine_scores({"behavioral": 100})
    assert score == 25
    assert contributions["behavioral"] == 25


def make_tx(i, s, r, value, when, kind="UPI"):
    return {
        "id": i,
        "sender": s,
        "receiver": r,
        "amount": value,
        "timestamp": when,
        "transaction_type": kind,
    }


def test_fifo_matching_never_double_counts_incoming_value():
    now = datetime(2026, 9, 5, 12, 0)
    txs = [
        make_tx(1, "A", "B", 100, now - timedelta(seconds=60)),
        make_tx(2, "B", "C", 70, now - timedelta(seconds=30)),
        make_tx(3, "B", "D", 70, now),
    ]
    out = analyze_temporal([{"id": n} for n in "ABCD"], txs, now)
    assert out["B"]["rapid_forward_ratio"] == 1
    assert out["B"]["matched_volume"] == 100
    assert out["B"]["temporal_risk"] <= 100


def test_flow_detection_requires_forward_time_and_value_continuity():
    t = datetime(2026, 9, 5, 12, 0)
    txs = [
        make_tx(1, "A", "B", 10000, t),
        make_tx(2, "B", "C", 9000, t - timedelta(seconds=1)),
    ]
    assert chronological_paths(txs, "A") == []
    txs[1]["timestamp"] = t + timedelta(seconds=30)
    paths = chronological_paths(txs, "A")
    assert len(paths) == 1
    assert len(paths[0]) == 2
    txs[1]["amount"] = 2000
    assert chronological_paths(txs, "A") == []


def test_graph_measures_actual_directed_structure():
    now = datetime(2026, 9, 5, 12, 0)
    txs = [
        make_tx(1, "A", "B", 12000, now),
        make_tx(2, "B", "C", 11000, now),
        make_tx(3, "C", "A", 10000, now),
    ]
    graph = GraphAnalyzer([{"id": n} for n in "ABCD"], txs, now)
    assert len(graph.components) == 2
    assert any(set(c) == {"A", "B", "C"} for c in graph.cycles)
    assert graph.stats["A"]["in_cycle"]
    exposures, provenance = graph.propagate({"A": 95, "B": 15, "C": 15, "D": 5})
    assert exposures["B"] > 0
    assert exposures["D"] == 0
    assert all(0 <= x <= 100 for x in exposures.values())
    assert provenance["B"][0]["source"] == "A"


def test_seed_is_realistic_sized_and_fictional():
    now = datetime(2026, 9, 5, 12, 0)
    accounts, txs = SimulationEngine().seed(now)
    ids = {a["id"] for a in accounts}
    assert len(accounts) == len(ids) == 500
    assert len(txs) == 5000
    assert sum(t["scenario"] != "normal" for t in txs) == 400
    assert all(
        t["sender"] in ids and t["receiver"] in ids and t["sender"] != t["receiver"]
        for t in txs
    )
    assert all(t["device_hash"].startswith("SIMULATED-") for t in txs)
    assert all(t["timestamp"] <= now for t in txs)
    assert all(t["amount"] > 0 for t in txs)


@pytest.mark.parametrize(
    "pattern",
    [
        "normal",
        "suspicious",
        "mule",
        "fraud_ring",
        "fan_in",
        "fan_out",
        "circular",
        "multi_hop",
    ],
)
def test_each_pattern_can_generate_an_exact_sized_dataset(pattern):
    accounts, txs = SimulationEngine().seed(
        datetime(2026, 9, 5, 12, 0), 100, 700, 35, pattern
    )
    assert len(accounts) == 100
    assert len(txs) == 700
    assert sum(t["scenario"] != "normal" for t in txs) == (
        0 if pattern == "normal" else 245
    )


def test_seed_detects_multiple_rings_without_scenario_labels(platform):
    assert len(platform.rings) >= 3
    critical = [a for a in platform.analyses.values() if a["risk_score"] >= 81]
    assert critical
    assert all("scenario" not in t for t in platform.transactions)
    assert all(a["explanation"]["evidence"] for a in platform.analyses.values())
    for a in platform.analyses.values():
        assert 0 <= a["risk_score"] <= 100
        assert 0 <= a["ml"]["fraud_probability"] <= 1
        assert a["ml"]["normality_score"] + a["ml"]["anomaly_score"] == pytest.approx(
            100
        )
        assert math.isfinite(a["metrics"]["network_centrality"])


def test_no_hidden_label_shortcut(platform):
    import copy

    txs = copy.deepcopy(platform.transactions)
    for t in txs:
        t["scenario"] = "definitely_fraud" if t["id"] % 2 else "safe"
    analyses, rings, _ = platform.detector.analyze(
        platform.accounts, txs, platform.last_analysis
    )
    assert {k: v["risk_score"] for k, v in analyses.items()} == {
        k: v["risk_score"] for k, v in platform.analyses.items()
    }
