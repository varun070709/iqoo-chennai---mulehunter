"""Tests use a disposable SQLite database, never the demo's persisted data."""

import os
import tempfile
from pathlib import Path
import pytest

_test_dir = tempfile.TemporaryDirectory(prefix="mulehunter-tests-")
os.environ["DATABASE_URL"] = "sqlite:///" + str(Path(_test_dir.name) / "test.db")


@pytest.fixture(scope="session")
def client():
    from fastapi.testclient import TestClient
    from app.main import app

    with TestClient(app) as client:
        client.post("/simulate", json={"action": "stop"})
        yield client


@pytest.fixture(scope="module")
def platform(client):
    from app.main import get_platform

    p = get_platform()
    p.reset()
    return p
