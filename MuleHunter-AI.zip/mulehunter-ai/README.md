# MuleHunter AI

### Real-Time Financial Fraud Network Intelligence & Mule Account Detection

**Follow the signal. Understand the network.**

A working full-stack, synthetic-data investigation platform—not a static dashboard. It includes a persisted transaction ledger, local machine-learning models, NetworkX graph analysis, live WebSocket updates, controlled attack injection, account-level explanations, money-flow replay, and downloadable investigation reports.

> **Decision-support prototype.** Every account, device and payment is fictional. A score is a signal for human review, not a finding of fraud. The application never blocks an account, contacts a bank, reports a person, or executes a real payment. It has **no authentication** and must not be exposed to the public internet or connected to real banking data.

---

## Start here

The workspace opens directly to the command center so the network is immediately visible. The product landing page is available at `/welcome` or by clicking the MuleHunter AI logo.

| Experience | Development URL |
|---|---|
| Command center | http://localhost:5173 |
| Product landing page | http://localhost:5173/welcome |
| API reference | http://localhost:8000/docs |
| API health | http://localhost:8000/health |

### Prerequisites

- **Python 3.11–3.13** (tested with Python 3.13)
- **Node.js 20+** and npm
- Approximately 1 GB of available RAM for comfortable local use
- Internet access for the initial dependency installation; no API keys or external AI service are required

### Local installation

From the `mulehunter-ai` directory:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt

cd frontend
npm ci
cd ..

python scripts/dev.py
```

Open **http://localhost:5173**. Press **Ctrl+C** to stop both services.

On Windows PowerShell, replace the activation line with:

```powershell
.venv\Scripts\Activate.ps1
```

Optional dependency check:

```bash
python scripts/dev.py --check
```

### Two-terminal alternative

Backend, with the virtual environment activated:

```bash
cd backend
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Frontend, in a second terminal:

```bash
cd frontend
npm run dev
```

### Optimized local build

```bash
python scripts/dev.py --production
```

Or run `npm run build` and `npm run preview` in `frontend/` while the backend is running. The preview uses port **5173** and proxies HTTP and WebSocket requests to the same backend.

### Docker Compose

```bash
docker compose up --build
```

Open **http://localhost:8080**. SQLite data persists in the `mulehunter-data` volume. The frontend is served by Nginx and proxies `/api/`, including WebSockets, to FastAPI.

```bash
docker compose down       # stop, retain the database
docker compose down -v    # stop and permanently delete the demo database
```

Docker configuration is included; the Docker image build was not executed in the provided development workspace. The equivalent Python/Node services and optimized frontend build were exercised directly.

### Configuration

Defaults work without an environment file. To customize:

```bash
cp .env.example .env
```

- `DATABASE_URL`: optional SQLite connection URL; the default is `backend/data/mulehunter.db`.
- `MULEHUNTER_AUTO_STREAM`: `true` by default. Set to `false` for a paused workspace at startup.

The database and tables are created automatically. An empty database is seeded with **500 accounts and 5,000 transactions**, including normal commerce and several coordinated attack motifs. Existing data is retained on restart. Models are deterministically retrained on a synthetic reference population at startup; no untrusted model files are loaded.

---

## The two-minute demonstration

1. Open the **Command center**. Confirm that the transport indicator says **Live connection**.
2. Click **Demo attack**. The simulation runs in accelerated synthetic event time through the same detector used for live payments.
3. Watch the seven progress phases:
   - establish normal payments;
   - create 12 fictional wallets;
   - concentrate incoming payments into a collector;
   - rapidly layer payments through additional wallets and a simulated cash-out;
   - add partial circular movement;
   - disperse value and compute network exposure;
   - detect and score the emerging connected network.
4. Click **Review evidence** in the completed attack card. Inspect the composite risk, measured behavior and individual evidence statements.
5. Open **Fraud DNA** to compare the selected account with the synthetic reference, or **Money flow** to replay time-ordered transfers.
6. Open **Fraud rings → Investigate network** to highlight the cluster. The folder button opens its persisted investigation case.
7. In **Investigations**, record notes, choose a review recommendation, update the local case status and click **Download report**.

The demonstration creates an emerging **network**, not just a single red transaction. The detector does not read the simulation's hidden scenario labels.

If a demonstration has been left idle, recent-window risk can decay. Use **Demo attack** again or **Simulation lab → Reset network to baseline**. Reset is deliberately confirmed because it removes accounts, payments and cases.

---

## Product surfaces

| Page | Working capabilities |
|---|---|
| **Landing** | Animated network illustration, live dataset statistics, intelligence architecture, workflow and functional launch actions |
| **Command center** | Persisted transaction/account metrics, potential exposure, risk distribution, recent activity chart, live transaction feed, priority alerts, stream pause/resume and demo attack |
| **Network explorer** | Pan/zoom, account lookup, node inspection, connected-neighbor highlighting, risk and time filters, detected-ring highlighting, edge amounts/counts, community metrics, minimap and JSON export |
| **Fraud DNA** | Behavioral radar, velocity/value/fan ratios, unique peers, interval, circularity indicator, centrality, exposure, weighted score breakdown, model outputs and deterministic evidence |
| **Money flow** | Actual chronological candidate paths, hop/duration/value statistics, visual replay, scrubber, transaction timeline and case creation |
| **Fraud rings** | Computed suspicious communities, member counts, average account risk, internal volume, reasons, graph inspection and case linkage |
| **Risk propagation** | Three-hop replay, graph-distance layers, weighted exposure, source provenance and JSON export |
| **Simulation lab** | Account/transaction budgets, fraud-pattern share, speed, eight selectable patterns, fresh dataset generation, injection, start/stop, confirmed reset and manual payment analysis/ingestion |
| **Investigations** | Searchable/filterable case register, creation from accounts/networks/flows, captured evidence, current account graph, payment trail, persisted notes/status/recommendations, JSON register and PDF reports |
| **Transaction ledger** | Search, risk filters, pagination, account inspection and complete CSV export |

Global search supports accounts, transactions and cases. `Ctrl+K` / `⌘K` opens search; `Escape` closes investigation drawers and dialogs. Notifications open the associated account. The analyst/settings control displays actual API health and model/graph details.

---

## Architecture

```text
React + TypeScript + Vite
  ├── Tailwind CSS + custom design system + Framer Motion
  ├── React Flow + D3 force layout
  ├── Recharts radar / area / risk distribution
  └── TanStack Query + reconnecting WebSocket client
             │
             │ same-origin /api HTTP + WebSocket proxy
             ▼
FastAPI / Uvicorn — single application worker
  ├── Simulation engine / manually submitted transactions
  ├── SQLite / SQLAlchemy: accounts, transactions, cases
  ├── Behavior analyzer → Isolation Forest + Random Forest
  ├── Temporal analyzer → FIFO matching + chronological chains
  ├── NetworkX → centralities, communities, cycles, components
  ├── Risk engine → weighted score + bounded propagation
  ├── Explainer → structured, deterministic evidence
  └── Case service → persisted records + ReportLab PDF
```

The same analysis pipeline handles seeding, generated datasets, manual ingestion, live batches and injected attacks. Mutating analysis operations are serialized. CPU-bound analysis runs off FastAPI's event loop; HTTP reads consume guarded snapshots. Transaction ingestion is committed atomically to SQLite, then derived analysis is recomputed and persisted. A restart recomputes derived analysis if an earlier process was interrupted between ingestion and analysis.

The WebSocket publishes dashboard snapshots, the latest ingested transfers, and attack progress. The client reconnects with bounded exponential backoff; dashboard HTTP polling is available while disconnected. SQLite uses WAL mode, foreign-key enforcement and a busy timeout.

### Source layout

```text
mulehunter-ai/
├── frontend/
│   ├── src/
│   │   ├── components/      # graph, charts, drawer, tables, shell, UI primitives
│   │   ├── pages/           # every product surface
│   │   └── lib/             # typed API client, live context, data contracts
│   ├── public/fonts/        # locally served fonts; no frontend CDN dependency
│   ├── e2e/                 # Playwright interaction tests
│   ├── vite.config.ts       # same-origin HTTP/WS proxy and vendor splitting
│   ├── nginx.conf
│   ├── Dockerfile
│   └── package-lock.json
├── backend/
│   ├── app/
│   │   ├── api/schemas.py
│   │   ├── models/entities.py
│   │   ├── database/session.py
│   │   ├── ml/anomaly_model.py
│   │   ├── graph/graph_analyzer.py
│   │   ├── simulation/simulation_engine.py
│   │   ├── services/
│   │   │   ├── behavior_analyzer.py
│   │   │   ├── temporal_analyzer.py
│   │   │   ├── risk_engine.py
│   │   │   ├── fraud_detector.py
│   │   │   ├── explainer.py
│   │   │   ├── platform.py
│   │   │   └── report.py
│   │   └── main.py
│   ├── data/                # created on first run; excluded from the source archive
│   ├── tests/
│   └── Dockerfile
├── docs/                    # methodology, API reference and deployment boundaries
├── scripts/dev.py
├── requirements.txt
├── requirements-dev.txt
├── pytest.ini
├── .env.example
├── docker-compose.yml
├── Makefile
└── README.md
```

---

## Risk scoring and explanations

Account risk is an **additive weighted score**, not the product of the component scores:

```python
risk = round(
    behavioral_risk * 0.25
    + velocity_risk * 0.20
    + graph_risk * 0.25
    + temporal_risk * 0.15
    + network_exposure_risk * 0.15
)
```

Every layer is clamped to `[0, 100]` and the resulting score is also bounded.

| Score | Level |
|---|---|
| 0–30 | SAFE |
| 31–60 | SUSPICIOUS |
| 61–80 | HIGH RISK |
| 81–100 | CRITICAL |

The explainability panel reports measured evidence, the primary signal and a human-review recommendation. Different evidence items may reference the same scoring layer; their displayed weighted points must not be added together.

Transaction scores use current endpoint context with a bounded amount contribution and an explicit extreme-value reference rule. They are not immutable historical fraud verdicts: as the surrounding network evolves, stored transaction risk is re-evaluated.

### Models

- **Isolation Forest:** 80 trees, trained on 2,400 generated reference examples.
- **Random Forest:** 72 trees, trained on generated reference and anomalous populations.
- Inputs: amount, recent frequency, unique peers, incoming/outgoing ratio, average spacing, network degree, centrality, fan-in, fan-out and exposure.
- Outputs: `anomaly_score`, complementary `normality_score`, and `fraud_probability`.
- `fraud_probability` is an **uncalibrated synthetic classifier estimate**, not a validated probability for an actual bank customer.
- The detector uses a first-pass score to select propagation sources, then a second model pass includes measured exposure. It does not iterate feedback indefinitely.
- No LLM is used as the core detector or to fabricate explanations. No autoencoder, GNN, Redis or external AI dependency is required.

### Interpretation matters

- **Potential exposure is gross high-risk transaction value**, not verified loss, recovered funds or prevented fraud. Multiple hops can count the same underlying funds more than once.
- **Detection time is the measured full-network analysis/persistence cycle**, averaged over recent cycles. It is not a production per-payment latency claim.
- Radar reference values are illustrative normalized heuristics, not an observed real customer cohort.
- The circularity propensity field is a heuristic indicator, not a calibrated probability.
- A time-ordered path suggests possible movement; mixed funds and account balances are not modeled, so it does not prove fund provenance.
- Network association alone is not a finding of wrongdoing. Exposure contributes only 15% of the final account score.

See [Methodology](docs/METHODOLOGY.md) for windows, thresholds, limits and experimental boundaries.

---

## API

FastAPI exposes the requested routes directly on port 8000. The frontend uses the **same routes prefixed with `/api`** through Vite/Nginx, so browser code never calls a sandbox-only `localhost` address.

| Method | Endpoint |
|---|---|
| GET | `/dashboard` |
| GET | `/transactions` |
| GET | `/transactions/export` |
| GET | `/accounts` |
| GET | `/accounts/{account_id}` |
| GET | `/network` |
| GET | `/fraud-rings` |
| GET | `/flows?account_id=…` |
| GET | `/propagation/{account_id}` |
| GET / POST | `/cases` |
| PATCH | `/cases/{case_id}` |
| GET | `/investigation/{case_id}` |
| GET | `/investigation/{case_id}/report` |
| POST | `/simulate` |
| POST | `/simulate/inject-fraud` |
| POST | `/simulate/demo-attack` |
| POST | `/analyze/transaction` |
| POST | `/analyze/account` |
| GET | `/health` |
| WebSocket | `/ws/live-transactions` |

Example non-persisting payment preview, using accounts from the standard seed:

```bash
curl -X POST http://localhost:8000/analyze/transaction \
  -H 'Content-Type: application/json' \
  -d '{"sender":"ACC-S001","receiver":"ACC-S002","amount":25000,"transaction_type":"UPI","persist":false}'
```

Example network attack:

```bash
curl -X POST http://localhost:8000/simulate/demo-attack
```

Full request contracts and examples: [API reference](docs/API.md).

---

## Tests and verification

### Backend

```bash
python -m pytest
```

**31 passing checks** cover score boundaries, additive normalization, FIFO value conservation, chronological path ordering, graph structure, exact-sized fictional datasets and every generator pattern, absence of scenario-label leakage, API snapshots and validation, non-mutating previews, persisted manual ingestion, case lifecycle, PDF/CSV export and the staged WebSocket attack.

Tests use a **disposable SQLite database**, not your running demo database.

### Frontend build

```bash
cd frontend
npm run build
npm run format:check
```

The TypeScript production build is code-split by route and heavy visualization vendors. Local fonts are bundled in the source.

### Browser interaction tests

With both services running:

```bash
cd frontend
npx playwright install chromium
# Linux, if browser system libraries are missing:
# npx playwright install-deps chromium
npm run test:e2e
```

**9 passing production-build browser tests** cover the real metrics/transport, graph risk filters and node selection, DNA/evidence tabs, global search, focused graphs, zoom controls, flow replay, case creation and note persistence, escalation, PDF downloads, manual analysis, reset confirmation, the complete live demo attack, stream controls and mobile navigation.

**Important:** browser tests deliberately reset the running sandbox and create test transactions/cases. Export anything you want to keep before running them. `E2E_BASE_URL` can target a separate local instance.

Every product page was also checked at desktop and mobile sizes for runtime errors and unintended horizontal page overflow.

---

## Prototype limits and deployment boundaries

- **One backend worker only.** The event hub and analysis snapshot are process-local. Multi-worker/multi-instance deployment requires a shared event bus, job queue and snapshot store.
- Maximum **2,000 accounts / 50,000 stored transactions**. One generated dataset request is capped at 20,000 transfers. This bounds local resource use; it is not a banking-scale ingestion design.
- Graph edges aggregate directed account-pair payments. Up to 1,500 aggregated edges are drawn; the full ledger remains available. The network explorer can request all accounts.
- Betweenness is approximated with sampled pivots. Cycle enumeration is bounded at 150 short directed cycles, with a component-sharing budget. Money-flow search is also deliberately bounded.
- The live rate is a target. Normal payments are analyzed in three-second batches; model/graph work adds processing time. For streaming, the fraud slider is the **chance of injecting a motif per batch**, not a guarantee that the same percentage of live payments will be anomalous.
- Generated datasets use the requested motif transfer share; a low fraud budget can cut a motif short, so not every injected scenario must create a ring or a critical score.
- The UI supports long-running live sessions up to the stated capacity; it does not prune the financial ledger silently. Export and reset when capacity is reached.
- No authentication, authorization, audited access, bank connectivity, real KYC, sanctions screening, regulatory filing or automated enforcement is included.
- Synthetic classifier outputs have not been calibrated or evaluated against real-world fraud outcomes. No accuracy, recall, false-positive rate or financial-prevention claim is made.

For anything beyond an isolated hackathon/local demonstration, see the explicit hardening checklist in [Security and deployment](docs/SECURITY.md).

## Troubleshooting

- **Engine not reachable:** start the backend on port 8000, then refresh. Check `/health` and the terminal logs.
- **Graph seems quiet:** seed patterns use rolling recent windows. Run a new demo attack or restore the baseline.
- **Another analysis is running (409):** wait for the current operation; concurrent mutations are intentionally serialized.
- **Missing account after reset:** reset replaced the dataset. Clear the graph focus or choose a current account.
- **No paths/rings for a chosen pattern:** absence of sufficient combined evidence is a valid result, not a forced positive. Try a complete fraud-ring/demo motif.
- **Port already in use:** stop existing local processes on 5173/8000; the development server uses a strict port to avoid a silently incorrect proxy.
- **Reports are empty of analyst notes:** save notes before downloading. Reports reflect persisted case data.
- **Offline setup:** dependency installation and the optional Swagger UI assets require internet. The application UI, fonts, models, simulations, reports and WebSocket analysis itself run locally without an external AI service.

---

Built as a serious, explainable financial-network investigation prototype for demonstrations, experimentation and human-led review.
