import { lazy, Suspense } from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Empty, Loading } from './components/ui';
const Overview = lazy(() => import('./pages/Overview').then((m) => ({ default: m.Overview })));
const NetworkExplorer = lazy(() =>
  import('./pages/NetworkExplorer').then((m) => ({ default: m.NetworkExplorer })),
);
const TransactionsPage = lazy(() =>
  import('./pages/TransactionsPage').then((m) => ({ default: m.TransactionsPage })),
);
const DnaPage = lazy(() => import('./pages/DnaPage').then((m) => ({ default: m.DnaPage })));
const FraudRings = lazy(() =>
  import('./pages/FraudRings').then((m) => ({ default: m.FraudRings })),
);
const MoneyFlow = lazy(() => import('./pages/MoneyFlow').then((m) => ({ default: m.MoneyFlow })));
const Propagation = lazy(() =>
  import('./pages/Propagation').then((m) => ({ default: m.Propagation })),
);
const SimulationLab = lazy(() =>
  import('./pages/SimulationLab').then((m) => ({ default: m.SimulationLab })),
);
const Investigations = lazy(() =>
  import('./pages/Investigations').then((m) => ({ default: m.Investigations })),
);
const Landing = lazy(() => import('./pages/Landing').then((m) => ({ default: m.Landing })));
export default function App() {
  return (
    <Suspense fallback={<Loading label="Opening intelligence workspace…" />}>
      <Routes>
        <Route path="/welcome" element={<Landing />} />
        <Route element={<Layout />}>
          <Route path="/" element={<Overview />} />
          <Route path="/network" element={<NetworkExplorer />} />
          <Route path="/transactions" element={<TransactionsPage />} />
          <Route path="/dna" element={<DnaPage />} />
          <Route path="/fraud-rings" element={<FraudRings />} />
          <Route path="/money-flow" element={<MoneyFlow />} />
          <Route path="/propagation" element={<Propagation />} />
          <Route path="/simulation" element={<SimulationLab />} />
          <Route path="/investigations" element={<Investigations />} />
          <Route path="/investigations/:caseId" element={<Investigations />} />
          <Route
            path="*"
            element={
              <Empty
                title="This intelligence view was not found"
                description="Return to the command center to continue investigating."
              >
                <Link to="/" className="btn btn-primary">
                  Open command center
                </Link>
              </Empty>
            }
          />
        </Route>
      </Routes>
    </Suspense>
  );
}
