export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`/api${path}`, {
    ...options,
    headers: {
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      ...options.headers,
    },
  });
  if (!response.ok) {
    const error = await response
      .json()
      .catch(() => ({ detail: 'The service could not be reached.' }));
    const detail = Array.isArray(error.detail)
      ? error.detail.map((e: { msg: string }) => e.msg).join(' ')
      : error.detail;
    throw new Error(detail || `Request failed (${response.status}).`);
  }
  return response.json();
}
export const post = <T>(path: string, body: unknown = {}) =>
  api<T>(path, { method: 'POST', body: JSON.stringify(body) });
export async function download(path: string, filename: string) {
  const response = await fetch(`/api${path}`);
  if (!response.ok) throw new Error('Report download failed. Please try again.');
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function saveJson(data: unknown, filename: string) {
  const url = URL.createObjectURL(
    new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }),
  );
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export const count = (n: number) => new Intl.NumberFormat('en-IN').format(n);
export function money(n: number, compact = false) {
  if (compact) {
    if (n >= 1e7) return `₹${(n / 1e7).toFixed(2)}Cr`;
    if (n >= 1e5) return `₹${(n / 1e5).toFixed(2)}L`;
    if (n >= 1e3) return `₹${(n / 1e3).toFixed(1)}K`;
  }
  return `₹${new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 }).format(n)}`;
}
export const time = (t: string) =>
  new Date(t).toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
    timeZone: 'Asia/Kolkata',
  });
export const shortTime = (t: string) =>
  new Date(t).toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
    timeZone: 'Asia/Kolkata',
  });
export const date = (t: string) =>
  new Date(t).toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    timeZone: 'Asia/Kolkata',
  });
export const riskColor = (level: string) =>
  ({ SAFE: '#79ca9d', SUSPICIOUS: '#e2c76d', 'HIGH RISK': '#ec9c61', CRITICAL: '#f27c7c' })[
    level
  ] || '#82958b';
export const riskLevel = (n: number) =>
  n <= 30 ? 'SAFE' : n <= 60 ? 'SUSPICIOUS' : n <= 80 ? 'HIGH RISK' : 'CRITICAL';
