import { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import type { ReactNode } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { api, post } from './api';
import type { Dashboard, Transaction, AttackProgress } from './types';

type Toast = {
  id: number;
  title: string;
  description?: string;
  type: 'success' | 'error' | 'info' | 'alert';
};
type LiveContextType = {
  connected: boolean;
  connecting: boolean;
  transactions: Transaction[];
  dashboard?: Dashboard;
  selectedAccount: string | null;
  selectAccount: (id: string | null) => void;
  toasts: Toast[];
  notify: (title: string, type?: Toast['type'], description?: string) => void;
  dismissToast: (id: number) => void;
  runAttack: () => Promise<void>;
  attackBusy: boolean;
  progress: AttackProgress | null;
  showAttack: boolean;
  setShowAttack: (value: boolean) => void;
  toggleStream: () => Promise<void>;
};
const LiveContext = createContext<LiveContextType | null>(null);
export function LiveProvider({ children }: { children: ReactNode }) {
  const client = useQueryClient();
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(true);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [selectedAccount, selectAccount] = useState<string | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [progress, setProgress] = useState<AttackProgress | null>(null);
  const [showAttack, setShowAttack] = useState(false);
  const [attackBusy, setAttackBusy] = useState(false);
  const lastAttack = useRef('');
  const { data: dashboard } = useQuery({
    queryKey: ['dashboard'],
    queryFn: () => api<Dashboard>('/dashboard'),
    refetchInterval: connected ? false : 10000,
    retry: 2,
  });
  const notify = useCallback(
    (title: string, type: Toast['type'] = 'success', description?: string) => {
      const id = Date.now() + Math.random();
      setToasts((t) => [...t.slice(-3), { id, title, type, description }]);
      setTimeout(
        () => setToasts((t) => t.filter((x) => x.id !== id)),
        type === 'error' ? 8500 : 5500,
      );
    },
    [],
  );
  useEffect(() => {
    if (dashboard?.attack_progress) {
      setProgress(dashboard.attack_progress);
      if (dashboard.attack_running) setShowAttack(true);
    }
    setAttackBusy(dashboard?.attack_running || false);
  }, [dashboard]);
  useEffect(() => {
    let socket: WebSocket | undefined,
      retry: ReturnType<typeof setTimeout>,
      ping: ReturnType<typeof setInterval>;
    let active = true;
    let attempt = 0;
    function connect() {
      if (!active) return;
      socket = new WebSocket(
        `${location.protocol === 'https:' ? 'wss:' : 'ws:'}//${location.host}/api/ws/live-transactions`,
      );
      socket.onopen = () => {
        if (!active) return;
        setConnected(true);
        setConnecting(false);
        attempt = 0;
        ping = setInterval(() => {
          if (socket?.readyState === WebSocket.OPEN) socket.send('ping');
        }, 20000);
      };
      socket.onmessage = (event) => {
        if (!active) return;
        let payload;
        try {
          payload = JSON.parse(event.data);
        } catch {
          return;
        }
        if (payload.dashboard) {
          client.setQueryData(['dashboard'], payload.dashboard);
          for (const key of [
            'network',
            'account',
            'accounts',
            'rings',
            'cases',
            'investigation',
            'flows',
            'propagation',
          ])
            client.invalidateQueries({ queryKey: [key] });
          client.invalidateQueries({ queryKey: ['transactions'] });
        }
        if (payload.transactions) setTransactions(payload.transactions);
        if (payload.progress) {
          setProgress(payload.progress);
          if (payload.type === 'attack') setShowAttack(true);
          if (
            payload.type === 'attack_complete' &&
            payload.progress.account_id !== lastAttack.current
          ) {
            lastAttack.current = payload.progress.account_id;
            setShowAttack(true);
            notify(
              payload.progress.error ? 'Attack interrupted' : 'Critical network detected',
              payload.progress.error ? 'error' : 'alert',
              payload.progress.error ||
                'The connected mule network has been scored. Investigation evidence is ready.',
            );
          }
        }
      };
      socket.onclose = () => {
        clearInterval(ping);
        if (!active) return;
        setConnected(false);
        setConnecting(false);
        retry = setTimeout(connect, Math.min(1000 * 2 ** attempt++, 15000));
      };
      socket.onerror = () => socket?.close();
    }
    connect();
    return () => {
      active = false;
      clearTimeout(retry);
      clearInterval(ping);
      socket?.close();
    };
  }, [client, notify]);
  const runAttack = async () => {
    setAttackBusy(true);
    setShowAttack(true);
    setProgress({ step: 0, total_steps: 7, title: 'Preparing synthetic attack…' });
    try {
      await post('/simulate/demo-attack');
    } catch (e) {
      setAttackBusy(false);
      setShowAttack(false);
      notify((e as Error).message, 'error');
    }
  };
  const toggleStream = async () => {
    try {
      await post('/simulate', {
        action: dashboard?.stream_running ? 'stop' : 'start',
        fraud_percentage: 0,
        transaction_speed: dashboard?.stream_speed || 1,
      });
      client.invalidateQueries({ queryKey: ['dashboard'] });
      notify(dashboard?.stream_running ? 'Live simulation paused' : 'Live simulation resumed');
    } catch (e) {
      notify((e as Error).message, 'error');
    }
  };
  return (
    <LiveContext.Provider
      value={{
        connected,
        connecting,
        transactions,
        dashboard,
        selectedAccount,
        selectAccount,
        toasts,
        notify,
        dismissToast: (id) => setToasts((t) => t.filter((x) => x.id !== id)),
        runAttack,
        attackBusy,
        progress,
        showAttack,
        setShowAttack,
        toggleStream,
      }}
    >
      {children}
    </LiveContext.Provider>
  );
}
export const useLive = () => {
  const ctx = useContext(LiveContext);
  if (!ctx) throw new Error('LiveProvider is missing');
  return ctx;
};
