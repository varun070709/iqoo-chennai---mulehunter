export type RiskLevel = 'SAFE' | 'SUSPICIOUS' | 'HIGH RISK' | 'CRITICAL';
export interface Transaction {
  id: number;
  transaction_id: string;
  sender: string;
  receiver: string;
  amount: number;
  timestamp: string;
  transaction_type: string;
  risk_score: number;
  risk_level: RiskLevel;
  flags: string[];
  synthetic: boolean;
}
export interface Evidence {
  signal: string;
  title: string;
  detail: string;
  severity: RiskLevel;
  contribution: number;
}
export interface Explanation {
  primary_reason: string;
  summary: string;
  evidence: Evidence[];
  recommended_action: string;
  disclaimer: string;
}
export interface Metrics {
  transaction_count: number;
  recent_count: number;
  transaction_velocity: number;
  average_transaction_value: number;
  maximum_transaction_value: number;
  incoming_amount: number;
  outgoing_amount: number;
  unique_counterparties: number;
  recent_incoming_counterparties: number;
  recent_outgoing_counterparties: number;
  fan_in_ratio: number;
  fan_out_ratio: number;
  fan_in_score: number;
  fan_out_score: number;
  average_transaction_interval: number;
  network_degree: number;
  network_centrality: number;
  community: number;
  in_cycle: boolean;
  circular_transaction_probability: number;
  risk_exposure: number;
  suspicious_connections: number;
  rapid_forward_ratio: number;
  cashout_amount: number;
}
export interface Account {
  id: string;
  label: string;
  account_type: string;
  created_at?: string;
  device_hash?: string;
  location_cluster?: string;
  risk_score: number;
  risk_level: RiskLevel;
  metrics: Metrics;
  scores: Record<string, number>;
  contributions: Record<string, number>;
  ml: {
    anomaly_score: number;
    normality_score: number;
    fraud_probability: number;
    model_risk: number;
    model_note: string;
  };
  explanation: Explanation;
  radar: { axis: string; baseline: number; current: number }[];
  transactions?: Transaction[];
  rings?: string[];
  propagation_sources: { source: string; hops: number; contribution: number }[];
}
export interface Alert {
  id: string;
  title: string;
  risk_score: number;
  risk_level: RiskLevel;
  account_id: string;
  member_count: number;
  volume: number;
  patterns: string[];
  description: string;
  timestamp: string;
}
export interface AttackProgress {
  step: number;
  total_steps: number;
  title: string;
  complete?: boolean;
  account_id?: string;
  account_ids?: string[];
  risk_score?: number;
  ring_id?: string;
  explanation?: string;
  error?: string;
}
export interface Dashboard {
  total_transactions: number;
  total_accounts: number;
  suspicious_transactions: number;
  high_risk_accounts: number;
  active_fraud_networks: number;
  average_detection_time: number;
  potential_fraud_amount: number;
  total_volume: number;
  last_hour_transactions: number;
  last_hour_flagged: number;
  risk_distribution: { level: RiskLevel; count: number; transactions: number }[];
  hourly: { time: string; transactions: number; flagged: number; volume: number }[];
  alerts: Alert[];
  stream_running: boolean;
  stream_speed: number;
  attack_running: boolean;
  attack_progress: AttackProgress | null;
  last_analysis_at: string;
  version: number;
  synthetic: boolean;
}
export interface GraphNode {
  id: string;
  risk_score: number;
  risk_level: RiskLevel;
  community: number;
  ring_id?: string;
  influence: number;
  transaction_count: number;
  label: string;
  distance?: number;
  exposure?: number;
  source_contribution?: number;
}
export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  amount: number;
  count: number;
  risk_score: number;
  timestamp: string;
  transaction_type: string;
}
export interface GraphData {
  nodes: GraphNode[];
  edges: GraphEdge[];
  total_accounts: number;
  total_transactions: number;
  visible_edges: number;
  aggregated_edges: number;
  edge_limit: number;
  communities: number;
  components: number;
  cycle_count: number;
  ring_count: number;
  version: number;
  note: string;
  source?: string;
  source_risk?: number;
}
export interface Ring {
  id: string;
  title: string;
  members: string[];
  member_count: number;
  average_risk: number;
  risk_score: number;
  volume: number;
  density: number;
  reasons: string[];
  patterns: string[];
  hub: string;
  detected_at: string;
  edge_count: number;
}
export interface FlowPath {
  id: string;
  hops: number;
  duration_seconds: number;
  volume: number;
  circular: boolean;
  events: Transaction[];
}
export interface FlowData {
  account_id: string;
  paths: FlowPath[];
  patterns: string[];
  note: string;
}
export interface Case {
  id: string;
  title: string;
  ring_id?: string;
  account_ids: string[];
  risk_score: number;
  risk_level: RiskLevel;
  status: 'open' | 'in_review' | 'escalated' | 'closed';
  recommended_action: string;
  notes: string;
  evidence: Evidence[];
  created_at: string;
  updated_at: string;
}
export interface Investigation extends Case {
  accounts: Account[];
  volume: number;
  transaction_count: number;
  timeline: Transaction[];
  network: GraphData;
  patterns: string[];
}
