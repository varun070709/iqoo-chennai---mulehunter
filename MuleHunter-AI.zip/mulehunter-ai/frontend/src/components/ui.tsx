import { useEffect, useRef } from 'react';
import type { ReactNode, ButtonHTMLAttributes } from 'react';
import {
  AlertCircle,
  ArrowUpRight,
  LoaderCircle,
  X,
  Search,
  Radio,
  Check,
  Inbox,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { clsx } from 'clsx';
import { useQuery } from '@tanstack/react-query';
import { api, riskColor } from '../lib/api';
import type { Account, RiskLevel } from '../lib/types';
import { useLive } from '../lib/live';
export function Button({
  children,
  variant = 'secondary',
  className = '',
  loading,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  loading?: boolean;
}) {
  return (
    <button
      className={`btn btn-${variant} ${className}`}
      {...props}
      disabled={loading || props.disabled}
    >
      {loading ? <LoaderCircle size={15} className="spin" /> : null}
      {children}
    </button>
  );
}
export function IconButton({
  label,
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return (
    <button
      {...props}
      type="button"
      className={`icon-button ${props.className || ''}`}
      title={label}
      aria-label={label}
    >
      {children}
    </button>
  );
}
export function Badge({ level, small = false }: { level: RiskLevel | string; small?: boolean }) {
  return (
    <span
      className={clsx('risk-badge', small && 'small')}
      style={{ '--risk': riskColor(level) } as React.CSSProperties}
    >
      <i />
      {level}
    </span>
  );
}
export function Score({ value, large = false }: { value: number; large?: boolean }) {
  return (
    <span
      className={clsx('score', large && 'large')}
      style={{
        color: riskColor(
          value <= 30
            ? 'SAFE'
            : value <= 60
              ? 'SUSPICIOUS'
              : value <= 80
                ? 'HIGH RISK'
                : 'CRITICAL',
        ),
      }}
    >
      {value}
      <small>/100</small>
    </span>
  );
}
export function PageHeader({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow: string;
  title: string;
  description: string;
  children?: ReactNode;
}) {
  return (
    <div className="page-heading">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>
          {title}
          <span className="heading-dot">.</span>
        </h1>
        <p>{description}</p>
      </div>
      <div className="page-actions">{children}</div>
    </div>
  );
}
export function Panel({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <section className={`panel ${className}`}>{children}</section>;
}
export function PanelHeader({
  title,
  subtitle,
  children,
  icon,
}: {
  title: string;
  subtitle?: string;
  children?: ReactNode;
  icon?: ReactNode;
}) {
  return (
    <div className="panel-heading">
      <div>
        <h2>
          {icon}
          {title}
        </h2>
        {subtitle && <p>{subtitle}</p>}
      </div>
      <div className="panel-actions">{children}</div>
    </div>
  );
}
export function LivePill({ label = 'LIVE' }: { label?: string }) {
  return (
    <span className="live-pill">
      <i />
      {label}
    </span>
  );
}
export function Loading({
  label = 'Gathering network intelligence…',
  compact = false,
}: {
  label?: string;
  compact?: boolean;
}) {
  return (
    <div className={`loading-state ${compact ? 'compact' : ''}`}>
      <div className="scanner-loader">
        <Radio size={26} />
      </div>
      <p>{label}</p>
      <span>Connecting behavior, timing & topology</span>
    </div>
  );
}
export function Empty({
  title = 'No signals in this view',
  description = 'Try a different account or broaden your filters.',
  children,
}: {
  title?: string;
  description?: string;
  children?: ReactNode;
}) {
  return (
    <div className="empty-state">
      <Inbox size={30} />
      <h3>{title}</h3>
      <p>{description}</p>
      {children}
    </div>
  );
}
export function ErrorState({ error, retry }: { error: unknown; retry?: () => void }) {
  return (
    <div className="empty-state error-state">
      <AlertCircle size={28} />
      <h3>Intelligence temporarily unavailable</h3>
      <p>{error instanceof Error ? error.message : 'The engine could not be reached.'}</p>
      {retry && <Button onClick={retry}>Try again</Button>}
    </div>
  );
}
export function Modal({
  title,
  children,
  onClose,
  wide = false,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const prior = document.activeElement as HTMLElement;
    const body = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    ref.current?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeRef.current();
      if (e.key === 'Tab') {
        const els = ref.current?.querySelectorAll<HTMLElement>(
          'button:not(:disabled),input,select,textarea,[tabindex="0"],a[href]',
        );
        if (!els?.length) return;
        const first = els[0],
          last = els[els.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', key);
    return () => {
      document.body.style.overflow = body;
      document.removeEventListener('keydown', key);
      prior?.focus();
    };
  }, []);
  return (
    <div
      className="modal-overlay"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 16, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        className={`modal ${wide ? 'wide' : ''}`}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        tabIndex={-1}
        ref={ref}
      >
        <div className="modal-heading">
          <h2>{title}</h2>
          <IconButton label="Close dialog" onClick={onClose}>
            <X size={18} />
          </IconButton>
        </div>
        {children}
      </motion.div>
    </div>
  );
}
export function Toasts() {
  const { toasts, dismissToast } = useLive();
  return (
    <div className="toast-stack" aria-live="polite">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            layout
            key={t.id}
            initial={{ x: 30, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 30, opacity: 0 }}
            className={`toast ${t.type}`}
          >
            <div className="toast-icon">
              {t.type === 'error' || t.type === 'alert' ? (
                <AlertCircle size={18} />
              ) : (
                <Check size={18} />
              )}
            </div>
            <div>
              <strong>{t.title}</strong>
              {t.description && <p>{t.description}</p>}
            </div>
            <IconButton label="Dismiss notification" onClick={() => dismissToast(t.id)}>
              <X size={14} />
            </IconButton>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
export function AccountPicker({
  value,
  onChange,
  label = 'Select account',
}: {
  value: string;
  onChange: (v: string) => void;
  label?: string;
}) {
  const { data } = useQuery({
    queryKey: ['accounts', 'picker'],
    queryFn: () => api<{ items: Account[] }>('/accounts?limit=2000'),
    staleTime: 10000,
  });
  return (
    <div className="account-picker">
      <Search size={15} />
      <select aria-label={label} value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">{label}</option>
        {data?.items.map((a) => (
          <option key={a.id} value={a.id}>
            {a.id} · risk {a.risk_score}
          </option>
        ))}
      </select>
    </div>
  );
}
export function SectionLink({ children, onClick }: { children: ReactNode; onClick: () => void }) {
  return (
    <button className="section-link" onClick={onClick}>
      {children}
      <ArrowUpRight size={14} />
    </button>
  );
}
export function PrototypeNote({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`prototype-note ${compact ? 'compact' : ''}`}>
      <AlertCircle size={14} />
      <span>
        {compact
          ? 'Synthetic data. Real analysis. Human judgment.'
          : 'Decision-support prototype · All accounts and transactions are synthetic. A risk signal is not a finding of fraud.'}
      </span>
    </div>
  );
}
