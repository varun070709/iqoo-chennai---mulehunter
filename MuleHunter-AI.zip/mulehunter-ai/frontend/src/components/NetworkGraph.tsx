import { useMemo, useRef, useState, memo, useEffect } from 'react';
import {
  ReactFlow,
  ReactFlowProvider,
  Background,
  BackgroundVariant,
  Handle,
  Position,
  MiniMap,
  useReactFlow,
  MarkerType,
} from '@xyflow/react';
import type { Node, NodeProps, Edge } from '@xyflow/react';
import { forceSimulation, forceLink, forceManyBody, forceCollide, forceX, forceY } from 'd3-force';
import type { SimulationNodeDatum, SimulationLinkDatum } from 'd3-force';
import { Maximize, Plus, Minus, MousePointer2, X, ArrowUpRight, Move } from 'lucide-react';
import { IconButton, Badge } from './ui';
import { money, riskColor, riskLevel } from '../lib/api';
import type { GraphData, GraphNode, GraphEdge } from '../lib/types';
import '@xyflow/react/dist/style.css';

type AccountNodeData = GraphNode &
  Record<string, unknown> & {
    size: number;
    showLabel: boolean;
    dimmed: boolean;
    emphasized: boolean;
  };
type FlowAccountNode = Node<AccountNodeData, 'account'>;
const AccountNode = memo(function AccountNode({ data, selected }: NodeProps<FlowAccountNode>) {
  const c = riskColor(data.risk_level);
  const danger = data.risk_score > 80;
  const size = data.size;
  return (
    <div
      className={`account-node ${danger ? 'critical-node' : ''} ${selected || data.emphasized ? 'is-emphasized' : ''}`}
      style={
        {
          '--node-color': c,
          width: size,
          height: size,
          opacity: data.dimmed ? 0.2 : 1,
        } as React.CSSProperties
      }
      title={`${data.id} · ${data.risk_score}/100 · ${data.label}`}
    >
      <Handle type="target" position={Position.Left} className="node-handle" />
      <Handle type="source" position={Position.Right} className="node-handle" />
      {danger && <span className="node-pulse" />}
      <span className="node-halo" />
      <svg width={size} height={size} viewBox="0 0 40 40" fill="none">
        <circle
          cx="20"
          cy="20"
          r="17.5"
          fill={danger ? '#38201f' : '#16291f'}
          stroke={c}
          strokeWidth={selected ? 2.5 : 1.2}
        />
        <circle cx="20" cy="17" r="4.1" fill={c} opacity=".9" />
        <path d="M12.5 28c.4-5 2.7-7.1 7.5-7.1s7.1 2.1 7.5 7.1" fill={c} opacity=".85" />
        {danger && <circle cx="32" cy="8" r="4" fill={c} stroke="#101613" strokeWidth="2" />}
      </svg>
      {(data.showLabel || selected || data.emphasized) && (
        <div className="node-caption">
          <span>{data.id}</span>
          {(danger || selected) && (
            <small>
              {data.risk_score} <span>RISK</span>
            </small>
          )}
        </div>
      )}
    </div>
  );
});
type ClusterNodeData = Record<string, unknown> & {
  title: string;
  count: number;
  width: number;
  height: number;
};
type FlowClusterNode = Node<ClusterNodeData, 'cluster'>;
const ClusterNode = memo(function ClusterNode({ data }: NodeProps<FlowClusterNode>) {
  return (
    <div className="cluster-boundary" style={{ width: data.width, height: data.height }}>
      <div>
        <span />
        {data.title}
        <b>{data.count} ACCOUNTS</b>
      </div>
    </div>
  );
});
const nodeTypes = { account: AccountNode, cluster: ClusterNode };
type LayoutNode = SimulationNodeDatum & {
  id: string;
  group: string;
  gx: number;
  gy: number;
  size: number;
};
function GraphTools() {
  const { zoomIn, zoomOut, fitView } = useReactFlow();
  return (
    <div className="graph-zoom">
      <IconButton label="Zoom in" onClick={() => zoomIn({ duration: 250 })}>
        <Plus size={16} />
      </IconButton>
      <IconButton label="Zoom out" onClick={() => zoomOut({ duration: 250 })}>
        <Minus size={16} />
      </IconButton>
      <span />
      <IconButton
        label="Fit network to view"
        onClick={() => fitView({ padding: 0.13, duration: 500 })}
      >
        <Maximize size={15} />
      </IconButton>
    </div>
  );
}
interface Props {
  data: GraphData;
  onSelect?: (id: string) => void;
  large?: boolean;
  highlight?: string[];
  propagationStep?: number;
  focusId?: string;
  className?: string;
  onExpand?: () => void;
  showLegend?: boolean;
}
function NetworkInner({
  data,
  onSelect,
  large = false,
  highlight,
  propagationStep,
  focusId,
  className = '',
  onExpand,
  showLegend = true,
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [compact, setCompact] = useState(false);
  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) =>
      setCompact(entries[0].contentRect.width < 550),
    );
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);
  const [selected, setSelected] = useState<string | null>(null);
  const [selectedEdge, setSelectedEdge] = useState<GraphEdge | null>(null);
  const positionCache = useRef(new Map<string, { x: number; y: number }>());
  const signature = data.nodes.map((n) => n.id + ':' + n.community + ':' + n.ring_id).join('|');
  const positions = useMemo(() => {
    const groups = [...new Set(data.nodes.map((n) => n.ring_id || `c${n.community}`))];
    const layoutNodes: LayoutNode[] = data.nodes.map((n, i) => {
      const group = n.ring_id || `c${n.community}`;
      const index = groups.indexOf(group);
      const angle = (index / groups.length) * Math.PI * 2 - 0.8;
      const ring = !!n.ring_id;
      const radius = groups.length <= 2 ? 180 : ring ? 330 : 520;
      const ringGroups = groups.filter((g) => !g.startsWith('c'));
      const ri = ringGroups.indexOf(group);
      const anchors = [
        [450, 240],
        [920, 580],
        [950, 220],
        [390, 590],
      ];
      const gx = ring ? anchors[ri % 4][0] : 650 + Math.cos(angle) * radius,
        gy = ring ? anchors[ri % 4][1] : 450 + Math.sin(angle) * radius * 0.6;
      const old = positionCache.current.get(n.id);
      return {
        id: n.id,
        group,
        gx,
        gy,
        x: old?.x ?? gx + Math.cos(i * 2.399) * 90,
        y: old?.y ?? gy + Math.sin(i * 2.399) * 90,
        size: 24 + Math.min(18, Math.sqrt(n.influence) * 110) + (n.risk_score > 80 ? 10 : 0),
      };
    });
    const links: SimulationLinkDatum<LayoutNode>[] = data.edges.map((e) => ({
      source: e.source,
      target: e.target,
    }));
    if (layoutNodes.length) {
      const sim = forceSimulation<LayoutNode>(layoutNodes)
        .force(
          'link',
          forceLink<LayoutNode, SimulationLinkDatum<LayoutNode>>(links)
            .id((d) => d.id)
            .distance(85)
            .strength(0.1),
        )
        .force('charge', forceManyBody().strength(-240))
        .force(
          'collide',
          forceCollide<LayoutNode>()
            .radius((d) => d.size / 2 + 25)
            .iterations(3),
        )
        .force('x', forceX<LayoutNode>((d) => d.gx).strength(0.08))
        .force('y', forceY<LayoutNode>((d) => d.gy).strength(0.09))
        .stop();
      for (let i = 0; i < 160; i++) sim.tick();
      sim.stop();
    }
    const minX = Math.min(...layoutNodes.map((n) => n.x || 0)),
      maxX = Math.max(...layoutNodes.map((n) => n.x || 0));
    const minY = Math.min(...layoutNodes.map((n) => n.y || 0)),
      maxY = Math.max(...layoutNodes.map((n) => n.y || 0));
    const w = compact ? 620 : data.nodes.length <= 20 ? 760 : large ? 1160 : 1220,
      h = compact ? 590 : data.nodes.length <= 20 ? 320 : large ? 600 : 420;
    const map = new Map(
      layoutNodes.map((n) => [
        n.id,
        {
          x: 40 + (((n.x || 0) - minX) / Math.max(1, maxX - minX)) * w,
          y: 40 + (((n.y || 0) - minY) / Math.max(1, maxY - minY)) * h,
          size: n.size * 1.12,
        },
      ]),
    );
    layoutNodes.forEach((n) => positionCache.current.set(n.id, { x: n.x || 0, y: n.y || 0 }));
    return map;
    // Only recompute the force layout when the topology changes, not every risk update.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [signature, compact, large]);
  const connected = useMemo(() => {
    const s = focusId || selected;
    if (highlight?.length) return new Set(highlight);
    if (!s) return null;
    const nodes = new Set([s]);
    data.edges.forEach((e) => {
      if (e.source === s) nodes.add(e.target);
      if (e.target === s) nodes.add(e.source);
    });
    return nodes;
  }, [selected, focusId, highlight, data.edges]);
  const hubs = new Set(
    [...new Set(data.nodes.map((n) => n.ring_id).filter(Boolean))].map(
      (r) =>
        data.nodes.filter((n) => n.ring_id === r).sort((a, b) => b.risk_score - a.risk_score)[0]
          ?.id,
    ),
  );
  const accountNodes: FlowAccountNode[] = useMemo(
    () =>
      data.nodes.map((n, index) => {
        const p = positions.get(n.id) || { x: 0, y: 0, size: 28 };
        return {
          id: n.id,
          type: 'account',
          zIndex: 10,
          position: { x: p.x, y: p.y },
          selected: selected === n.id,
          data: {
            ...n,
            size: hubs.has(n.id) ? p.size * 1.24 : p.size,
            showLabel: hubs.has(n.id) || index % 22 === 0 || n.id === focusId,
            dimmed:
              (!!connected && !connected.has(n.id)) ||
              (propagationStep !== undefined && (n.distance || 0) > propagationStep),
            emphasized:
              n.id === focusId || (propagationStep !== undefined && n.distance === propagationStep),
          },
        };
      }),
    [data.nodes, positions, connected, selected, focusId, propagationStep],
  );
  const clusterNodes: FlowClusterNode[] = useMemo(() => {
    if (focusId || propagationStep !== undefined) return [];
    return [...new Set(data.nodes.map((n) => n.ring_id).filter(Boolean))].flatMap((ring, index) => {
      const members = data.nodes.filter((n) => n.ring_id === ring);
      if (members.length < 3) return [];
      const ps = members.map((n) => positions.get(n.id)).filter(Boolean) as {
        x: number;
        y: number;
        size: number;
      }[];
      const x = Math.min(...ps.map((p) => p.x)) - 24,
        y = Math.min(...ps.map((p) => p.y)) - 36;
      const width = Math.max(...ps.map((p) => p.x + p.size)) + 24 - x,
        height = Math.max(...ps.map((p) => p.y + p.size)) + 40 - y;
      return [
        {
          id: `cluster-${ring}`,
          type: 'cluster' as const,
          position: { x, y },
          data: { title: `NETWORK 0${index + 1}`, count: members.length, width, height },
          zIndex: -1,
          selectable: false,
          draggable: false,
          focusable: false,
          style: { pointerEvents: 'none' as const, width, height },
        },
      ];
    });
  }, [data.nodes, positions, focusId, propagationStep]);
  const nodes: (FlowAccountNode | FlowClusterNode)[] = [...clusterNodes, ...accountNodes];
  const edges: Edge[] = useMemo(
    () =>
      data.edges.map((e) => {
        const hot = e.risk_score >= 61;
        const highlighted = connected?.has(e.source) && connected?.has(e.target);
        const dimmed = connected && !highlighted;
        const color =
          e.risk_score >= 81
            ? '#c97865'
            : e.risk_score >= 61
              ? '#b99460'
              : e.risk_score > 30
                ? '#a99559'
                : '#557e5e';
        return {
          id: e.id,
          source: e.source,
          target: e.target,
          type: 'default',
          animated: hot && e.count > 4,
          style: {
            stroke: color,
            strokeWidth: hot ? 1.6 : 1.05,
            opacity: dimmed ? 0.08 : highlighted ? 0.95 : hot ? 0.78 : 0.6,
          },
          markerEnd: { type: MarkerType.ArrowClosed, color, width: 11, height: 11 },
          interactionWidth: 18,
          zIndex: 0,
          label: selectedEdge?.id === e.id ? money(e.amount) : undefined,
          labelStyle: { fill: '#e9f1e8', fontSize: 12 },
          labelBgStyle: { fill: '#253c2e' },
          labelBgPadding: [8, 4] as [number, number],
        };
      }),
    [data.edges, connected, selectedEdge],
  );
  return (
    <div ref={containerRef} className={`network-canvas ${large ? 'large' : ''} ${className}`}>
      <ReactFlow
        key={compact ? 'compact' : 'wide'}
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        fitView
        fitViewOptions={{ padding: large ? 0.13 : 0.1 }}
        minZoom={0.15}
        maxZoom={2.8}
        nodesDraggable={false}
        nodesConnectable={false}
        elementsSelectable={true}
        panOnScroll={false}
        zoomOnScroll={true}
        preventScrolling={false}
        onNodeClick={(_, node) => {
          if (node.type === 'cluster') return;
          setSelected(node.id);
          setSelectedEdge(null);
          onSelect?.(node.id);
        }}
        onPaneClick={() => {
          setSelected(null);
          setSelectedEdge(null);
        }}
        onEdgeClick={(_, edge) => {
          setSelectedEdge(data.edges.find((e) => e.id === edge.id) || null);
        }}
        proOptions={{ hideAttribution: true }}
        colorMode="dark"
      >
        <Background color="#2a3830" variant={BackgroundVariant.Dots} gap={24} size={1} />
        {large && (
          <MiniMap
            nodeColor={(n) =>
              n.type === 'cluster'
                ? 'transparent'
                : riskColor((n.data as AccountNodeData).risk_level)
            }
            maskColor="rgba(8,13,10,.75)"
            style={{ background: '#111b15', width: 150, height: 95 }}
            pannable
            zoomable
          />
        )}
        <GraphTools />
      </ReactFlow>
      <div className="graph-overline">
        <span className="live-square" />
        REAL-TIME TOPOLOGY<span className="graph-overline-divider">/</span>
        <span>{data.nodes.length} ACCOUNTS</span>
      </div>
      {onExpand && (
        <IconButton label="Open full network explorer" className="graph-expand" onClick={onExpand}>
          <ArrowUpRight size={17} />
        </IconButton>
      )}
      {showLegend && (
        <div className="graph-legend">
          {['SAFE', 'SUSPICIOUS', 'HIGH RISK', 'CRITICAL'].map((l) => (
            <span key={l}>
              <i style={{ background: riskColor(l) }} />
              {l === 'HIGH RISK' ? 'High risk' : l[0] + l.slice(1).toLowerCase()}
            </span>
          ))}
        </div>
      )}
      {!selectedEdge && (
        <div className="graph-hint">
          <MousePointer2 size={12} />
          {large
            ? 'Scroll to zoom · Drag to pan · Select to investigate'
            : 'Select a node to investigate'}
        </div>
      )}
      {selectedEdge && (
        <div className="edge-inspector">
          <div>
            <span className="eyebrow">DIRECTED TRANSACTION EDGE</span>
            <IconButton label="Close edge details" onClick={() => setSelectedEdge(null)}>
              <X size={14} />
            </IconButton>
          </div>
          <strong>
            {selectedEdge.source} <ArrowUpRight size={14} /> {selectedEdge.target}
          </strong>
          <p>
            {money(selectedEdge.amount)} <span>across {selectedEdge.count} payments</span>
          </p>
          <Badge level={riskLevel(selectedEdge.risk_score)} small />
        </div>
      )}
    </div>
  );
}
export function NetworkGraph(props: Props) {
  return (
    <ReactFlowProvider>
      <NetworkInner {...props} />
    </ReactFlowProvider>
  );
}
