import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import type { Dashboard, Account } from '../lib/types';
import { count, riskColor, shortTime } from '../lib/api';
export const chartTooltipStyle = {
  background: '#18221c',
  border: '1px solid #334138',
  borderRadius: 8,
  fontSize: 11,
  color: '#e6eee5',
};
export function VelocityChart({
  data,
  height = 172,
}: {
  data: Dashboard['hourly'];
  height?: number;
}) {
  return (
    <div style={{ width: '100%', height }}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          data={data.map((d) => ({ ...d, label: shortTime(d.time) }))}
          margin={{ top: 15, right: 12, left: -27, bottom: 0 }}
        >
          <defs>
            <linearGradient id="velocityGreen" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#9cd271" stopOpacity={0.25} />
              <stop offset="100%" stopColor="#9cd271" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="velocityRed" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#df8770" stopOpacity={0.15} />
              <stop offset="100%" stopColor="#df8770" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid vertical={false} stroke="#253128" strokeDasharray="3 5" />
          <XAxis
            dataKey="label"
            axisLine={false}
            tickLine={false}
            tick={{ fill: '#6d8074', fontSize: 9, fontFamily: 'IBM Plex Mono' }}
            minTickGap={28}
          />
          <YAxis
            axisLine={false}
            tickLine={false}
            tick={{ fill: '#6d8074', fontSize: 9, fontFamily: 'IBM Plex Mono' }}
          />
          <Tooltip contentStyle={chartTooltipStyle} labelStyle={{ color: '#9daea3' }} />
          <Area
            type="monotone"
            name="Transactions"
            dataKey="transactions"
            stroke="#b2db83"
            strokeWidth={1.7}
            fill="url(#velocityGreen)"
            isAnimationActive={false}
          />
          <Area
            type="monotone"
            name="Flagged"
            dataKey="flagged"
            stroke="#e38e78"
            strokeWidth={1.5}
            fill="url(#velocityRed)"
            isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
export function DnaChart({ account, height = 245 }: { account: Account; height?: number }) {
  return (
    <div style={{ width: '100%', height }}>
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={account.radar} outerRadius="68%">
          <PolarGrid stroke="#344638" />
          <PolarAngleAxis
            dataKey="axis"
            tick={{ fill: '#9baa9e', fontSize: 10, fontFamily: 'DM Sans' }}
          />
          <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
          <Radar
            name="Synthetic baseline"
            dataKey="baseline"
            stroke="#658475"
            fill="#658475"
            fillOpacity={0.15}
            strokeDasharray="4 4"
          />
          <Radar
            name="Current account"
            dataKey="current"
            stroke="#bae989"
            fill="#a9d879"
            fillOpacity={0.14}
            strokeWidth={2}
          />
          <Tooltip contentStyle={chartTooltipStyle} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
export function RiskDistribution({ data }: { data: Dashboard['risk_distribution'] }) {
  const total = data.reduce((s, d) => s + d.count, 0);
  return (
    <div className="risk-distribution">
      <div className="risk-donut">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              innerRadius={44}
              outerRadius={53}
              dataKey="count"
              paddingAngle={3}
              stroke="none"
              startAngle={90}
              endAngle={-270}
            >
              {data.map((d) => (
                <Cell key={d.level} fill={riskColor(d.level)} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={chartTooltipStyle}
              formatter={(value: number) => [value, 'Accounts']}
            />
          </PieChart>
        </ResponsiveContainer>
        <div>
          <strong>{count(total)}</strong>
          <span>ACCOUNTS</span>
        </div>
      </div>
      <div className="distribution-legend">
        {data.map((d) => (
          <div key={d.level}>
            <span>
              <i style={{ background: riskColor(d.level) }} />
              {d.level === 'HIGH RISK' ? 'High risk' : d.level[0] + d.level.slice(1).toLowerCase()}
            </span>
            <b>{d.count}</b>
          </div>
        ))}
      </div>
    </div>
  );
}
