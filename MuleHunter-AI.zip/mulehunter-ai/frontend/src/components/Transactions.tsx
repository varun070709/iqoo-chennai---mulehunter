import { ArrowUpRight, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import type { Transaction } from '../lib/types';
import { money, time, riskColor } from '../lib/api';
import { Badge, Empty } from './ui';
import { useLive } from '../lib/live';
export function TransactionTable({
  transactions,
  compact = false,
}: {
  transactions: Transaction[];
  compact?: boolean;
}) {
  const { selectAccount } = useLive();
  if (!transactions.length)
    return (
      <Empty
        title="Waiting for incoming transactions"
        description="Start the live stream or generate a simulation to see activity here."
      />
    );
  return (
    <div className="table-scroll">
      <table className={`transaction-table ${compact ? 'compact' : ''}`}>
        <thead>
          <tr>
            <th>TRANSACTION ID</th>
            <th>ACCOUNT</th>
            {!compact && <th>COUNTERPARTY</th>}
            <th>AMOUNT</th>
            <th>RISK</th>
            <th>STATUS</th>
            {!compact && <th>EVENT TIME · IST</th>}
            <th aria-label="Investigate" />
          </tr>
        </thead>
        <tbody>
          <AnimatePresence initial={false}>
            {transactions.map((t) => (
              <motion.tr
                key={t.id}
                initial={{
                  opacity: 0,
                  backgroundColor: t.risk_score >= 61 ? '#3b2922' : '#203523',
                }}
                animate={{ opacity: 1, backgroundColor: 'rgba(0,0,0,0)' }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5 }}
              >
                <td>
                  <span className="txn-id">
                    <i style={{ background: riskColor(t.risk_level) }} />
                    {t.transaction_id}
                  </span>
                  {!compact && <small className="cell-subtext">{t.transaction_type} payment</small>}
                </td>
                <td>
                  <button className="account-link" onClick={() => selectAccount(t.sender)}>
                    {t.sender}
                  </button>
                </td>
                {!compact && (
                  <td>
                    <button
                      className="account-link muted"
                      onClick={() => selectAccount(t.receiver)}
                    >
                      <ArrowUpRight size={12} />
                      {t.receiver}
                    </button>
                  </td>
                )}
                <td className="amount-cell">{money(t.amount)}</td>
                <td>
                  <div className="table-score">
                    <span style={{ color: riskColor(t.risk_level) }}>{t.risk_score}</span>
                    <i>
                      <b
                        style={{ width: `${t.risk_score}%`, background: riskColor(t.risk_level) }}
                      />
                    </i>
                  </div>
                </td>
                <td>
                  <Badge level={t.risk_level} small />
                </td>
                {!compact && <td className="mono muted time-cell">{time(t.timestamp)}</td>}
                <td>
                  <button
                    className="table-arrow"
                    aria-label={`Investigate ${t.transaction_id}`}
                    onClick={() => selectAccount(t.risk_score >= 61 ? t.receiver : t.sender)}
                  >
                    <ChevronRight size={15} />
                  </button>
                </td>
              </motion.tr>
            ))}
          </AnimatePresence>
        </tbody>
      </table>
    </div>
  );
}
