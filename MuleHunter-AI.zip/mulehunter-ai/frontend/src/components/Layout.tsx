import { useState, useEffect } from 'react';
import { Outlet, NavLink, Link, useNavigate, useLocation } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutGrid,
  Network,
  Waypoints,
  ScanFace,
  Fingerprint,
  FlaskConical,
  FolderSearch,
  ShieldCheck,
  ShieldAlert,
  Search,
  Bell,
  ChevronDown,
  ArrowUpRight,
  ArrowRight,
  Command,
  Activity,
  Menu,
  X,
  Radio,
  Check,
  LoaderCircle,
  GitBranch,
  Settings2,
  Info,
  BookOpen,
  ExternalLink,
  FileText,
  MonitorCog,
} from 'lucide-react';
import { useLive } from '../lib/live';
import { api, date, money, riskColor } from '../lib/api';
import type { Account, Case, Transaction } from '../lib/types';
import {
  Modal,
  IconButton,
  Button,
  Badge,
  Loading,
  Empty,
  PrototypeNote,
  LivePill,
  Toasts,
  ErrorState,
} from './ui';
import { AccountDrawer } from './AccountDrawer';
export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`brand ${compact ? 'compact' : ''}`}>
      <div className="brand-mark">
        <svg width="25" height="25" viewBox="0 0 32 32" fill="none">
          <path
            d="M5 25V7l11 10L27 7v18M5 7l11 18L27 7"
            stroke="currentColor"
            strokeWidth="2.8"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      <div>
        <strong>
          MuleHunter<span> AI</span>
        </strong>
        <small>FOLLOW THE SIGNAL.</small>
      </div>
    </div>
  );
}
const navItems = [
  {
    section: 'WORKSPACE',
    items: [
      { path: '/', label: 'Command center', icon: LayoutGrid },
      { path: '/network', label: 'Network explorer', icon: Network },
      { path: '/money-flow', label: 'Money flow', icon: Waypoints },
      { path: '/fraud-rings', label: 'Fraud rings', icon: ScanFace },
    ],
  },
  {
    section: 'INTELLIGENCE',
    items: [
      { path: '/dna', label: 'Fraud DNA', icon: Fingerprint },
      { path: '/propagation', label: 'Risk propagation', icon: GitBranch },
    ],
  },
  {
    section: 'OPERATIONS',
    items: [
      { path: '/simulation', label: 'Simulation lab', icon: FlaskConical },
      { path: '/investigations', label: 'Investigations', icon: FolderSearch },
    ],
  },
];
function GlobalSearch({ onClose }: { onClose: () => void }) {
  const [q, setQ] = useState('');
  const [tab, setTab] = useState('Accounts');
  const [debounced, setDebounced] = useState('');
  const { selectAccount } = useLive();
  const nav = useNavigate();
  useEffect(() => {
    const t = setTimeout(() => setDebounced(q), 200);
    return () => clearTimeout(t);
  }, [q]);
  const {
    data: accounts,
    isLoading,
    error,
  } = useQuery({
    queryKey: ['search-accounts', debounced],
    queryFn: () =>
      api<{ items: Account[] }>(`/accounts?limit=12&query=${encodeURIComponent(debounced)}`),
  });
  const { data: transactions } = useQuery({
    queryKey: ['search-transactions', debounced],
    queryFn: () =>
      api<{ items: Transaction[] }>(
        `/transactions?limit=12&query=${encodeURIComponent(debounced)}`,
      ),
    enabled: tab === 'Transactions',
  });
  const { data: cases } = useQuery({
    queryKey: ['cases'],
    queryFn: () => api<{ items: Case[] }>('/cases'),
    enabled: tab === 'Cases',
  });
  return (
    <Modal title="Search intelligence" onClose={onClose}>
      <div className="search-modal-input">
        <Search size={20} />
        <input
          autoFocus
          placeholder="An account, transaction or case ID…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <kbd>ESC</kbd>
      </div>
      <div className="drawer-tabs search-tabs">
        {['Accounts', 'Transactions', 'Cases'].map((t) => (
          <button key={t} onClick={() => setTab(t)} className={tab === t ? 'active' : ''}>
            {t}
          </button>
        ))}
      </div>
      <div className="search-results">
        {isLoading ? (
          <Loading compact />
        ) : error ? (
          <ErrorState error={error} />
        ) : tab === 'Accounts' ? (
          <>
            <div className="section-eyebrow">{q ? 'MATCHING ACCOUNTS' : 'PRIORITY ACCOUNTS'}</div>
            {accounts?.items.length ? (
              accounts.items.map((a) => (
                <button
                  className="search-result"
                  key={a.id}
                  onClick={() => {
                    onClose();
                    selectAccount(a.id);
                  }}
                >
                  <div className="search-result-icon">
                    <Fingerprint size={18} />
                  </div>
                  <div>
                    <strong>{a.id}</strong>
                    <p>{a.explanation.primary_reason}</p>
                  </div>
                  <Badge level={a.risk_level} small />
                  <ArrowUpRight size={14} />
                </button>
              ))
            ) : (
              <Empty
                title="No matching accounts"
                description="Try part of an account ID, such as ACC-R."
              />
            )}
          </>
        ) : tab === 'Transactions' ? (
          transactions?.items.length ? (
            transactions.items.map((t) => (
              <button
                className="search-result"
                key={t.id}
                onClick={() => {
                  onClose();
                  selectAccount(t.receiver);
                }}
              >
                <Activity size={19} />
                <div>
                  <strong>{t.transaction_id}</strong>
                  <p>
                    {t.sender} → {t.receiver}
                  </p>
                </div>
                <span className="mono">{money(t.amount)}</span>
                <Badge level={t.risk_level} small />
              </button>
            ))
          ) : (
            <Empty title="No matching transactions" />
          )
        ) : cases?.items.filter((c) =>
            (c.id + ' ' + c.title).toLowerCase().includes(q.toLowerCase()),
          ).length ? (
          cases.items
            .filter((c) => (c.id + ' ' + c.title).toLowerCase().includes(q.toLowerCase()))
            .map((c) => (
              <button
                className="search-result"
                key={c.id}
                onClick={() => {
                  onClose();
                  nav(`/investigations/${c.id}`);
                }}
              >
                <FolderSearch size={20} />
                <div>
                  <strong>{c.id}</strong>
                  <p>{c.title}</p>
                </div>
                <Badge level={c.risk_level} small />
              </button>
            ))
        ) : (
          <Empty title="No matching investigations" />
        )}
      </div>
      <div className="search-footer">
        <ShieldCheck size={12} />
        Search only covers this fictional, local dataset.
      </div>
    </Modal>
  );
}
function Diagnostics({ onClose }: { onClose: () => void }) {
  const { data, error, isLoading } = useQuery({
    queryKey: ['health'],
    queryFn: () => api<Record<string, unknown>>('/health'),
  });
  return (
    <Modal title="System diagnostics" onClose={onClose}>
      <div className="modal-body">
        {isLoading ? (
          <Loading compact />
        ) : error ? (
          <ErrorState error={error} />
        ) : (
          <>
            <div className="diagnostics-banner">
              <Radio size={23} />
              <div>
                <h3>All intelligence layers online</h3>
                <p>Local development · Single-instance processing</p>
              </div>
            </div>
            <div className="profile-rows">
              {[
                ['API status', data?.status],
                ['Database', data?.database],
                ['Graph engine', data?.graph],
                ['ML pipeline', data?.model],
                ['Live connections', data?.active_connections],
                ['Network accounts', data?.accounts],
                ['Analysis version', data?.version],
              ].map(([k, v]) => (
                <div key={String(k)}>
                  <span>{String(k)}</span>
                  <strong>{String(v)}</strong>
                </div>
              ))}
            </div>
            <div className="notice">
              <Info size={17} />
              <p>
                Public demo mode. No authentication or real bank integrations. Do not connect
                personal data or expose this local API as a production service.
              </p>
            </div>
            <Button onClick={() => window.open('/api/docs', '_blank', 'noopener,noreferrer')}>
              <BookOpen size={15} />
              Explore API documentation
              <ExternalLink size={13} />
            </Button>
          </>
        )}
      </div>
    </Modal>
  );
}
function AttackProgressCard() {
  const { progress, showAttack, setShowAttack, selectAccount } = useLive();
  if (!showAttack || !progress) return null;
  const complete = progress.complete;
  return (
    <motion.div
      className={`attack-progress-card ${complete ? 'complete' : ''}`}
      initial={{ y: 30, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
    >
      <div className="attack-progress-top">
        <span>
          {complete ? <ShieldAlert size={17} /> : <Radio size={17} className="pulse" />}
          {complete ? 'NETWORK INTERCEPTED' : 'DEMO ATTACK IN PROGRESS'}
        </span>
        <IconButton label="Hide attack progress" onClick={() => setShowAttack(false)}>
          <X size={15} />
        </IconButton>
      </div>
      <h3>{progress.title}</h3>
      <p>
        {progress.error ||
          (complete
            ? `12 synthetic wallets · ${progress.risk_score}/100 peak account risk`
            : 'Accelerated synthetic time · same live detection pipeline')}
      </p>
      <div className="attack-steps">
        {Array.from({ length: 7 }, (_, i) => (
          <i key={i} className={i < progress.step ? 'done' : ''} />
        ))}
      </div>
      <div className="attack-progress-bottom">
        <span>
          {progress.error
            ? 'PARTIAL SIMULATION'
            : `${String(progress.step).padStart(2, '0')} / 07 PHASES`}
        </span>
        {complete && progress.account_id ? (
          <button
            onClick={() => {
              selectAccount(progress.account_id!);
              setShowAttack(false);
            }}
          >
            Review evidence <ArrowRight size={13} />
          </button>
        ) : (
          <span>Analyzing connections…</span>
        )}
      </div>
    </motion.div>
  );
}
export function Layout() {
  const { dashboard, connected, connecting, selectAccount } = useLive();
  const [search, setSearch] = useState(false);
  const [diagnostics, setDiagnostics] = useState(false);
  const [notifications, setNotifications] = useState(false);
  const [seen, setSeen] = useState<string[]>([]);
  const [mobileNav, setMobileNav] = useState(false);
  const location = useLocation();
  const nav = useNavigate();
  const title =
    navItems
      .flatMap((s) => s.items)
      .find((i) =>
        i.path === '/' ? location.pathname === '/' : location.pathname.startsWith(i.path),
      )?.label || 'Workspace';
  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearch((s) => !s);
      }
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, []);
  useEffect(() => {
    setMobileNav(false);
    window.scrollTo(0, 0);
  }, [location.pathname]);
  const alerts = dashboard?.alerts || [];
  const unread = alerts.filter((a) => !seen.includes(a.id)).length;
  return (
    <div className="app-shell">
      {mobileNav && <div className="sidebar-backdrop" onClick={() => setMobileNav(false)} />}
      <aside className={`sidebar ${mobileNav ? 'mobile-open' : ''}`}>
        <Link to="/welcome" className="brand-link" aria-label="MuleHunter AI platform overview">
          <Logo />
        </Link>
        <div className="workspace-select">
          <div>
            <span className="workspace-avatar">
              <ShieldCheck size={16} />
            </span>
            <div>
              <strong>Intelligence workspace</strong>
              <small>Sandbox environment</small>
            </div>
          </div>
          <span className="tiny-indicator" />
        </div>
        <nav>
          {navItems.map((s) => (
            <div className="nav-group" key={s.section}>
              <div className="nav-section-label">{s.section}</div>
              {s.items.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.path === '/'}
                  className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                >
                  <item.icon size={17} strokeWidth={1.7} />
                  <span>{item.label}</span>
                  {item.path === '/fraud-rings' && !!dashboard?.active_fraud_networks && (
                    <b className="nav-count">{dashboard.active_fraud_networks}</b>
                  )}
                  {item.path === '/simulation' && <span className="nav-new">LAB</span>}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <button className="system-status" onClick={() => setDiagnostics(true)}>
            <div>
              <span className={`status-dot ${connected ? '' : 'offline'}`} />
              <strong>
                {connected
                  ? 'Systems operational'
                  : connecting
                    ? 'Connecting to engine'
                    : 'Reconnecting to engine'}
              </strong>
              <ArrowUpRight size={12} />
            </div>
            <span>
              5 intelligence layers ·{' '}
              {dashboard?.average_detection_time
                ? Math.round(dashboard.average_detection_time) + ' ms'
                : 'initializing'}
            </span>
          </button>
          <div className="sidebar-prototype">
            <ShieldCheck size={14} />
            <div>
              <strong>Built for safer payments.</strong>
              <span>Synthetic-data prototype</span>
            </div>
          </div>
          <button className="analyst-profile" onClick={() => setDiagnostics(true)}>
            <span className="avatar">AN</span>
            <div>
              <strong>Demo analyst</strong>
              <span>Investigation workspace</span>
            </div>
            <Settings2 size={15} />
          </button>
        </div>
      </aside>
      <div className="main-shell">
        <header className="topbar">
          <div className="topbar-breadcrumb">
            <IconButton
              label="Open navigation"
              className="mobile-menu"
              onClick={() => setMobileNav(true)}
            >
              <Menu size={20} />
            </IconButton>
            <span>Workspace</span>
            <span className="breadcrumb-slash">/</span>
            <strong>{title}</strong>
          </div>
          <div className="topbar-right">
            <button className="global-search" onClick={() => setSearch(true)}>
              <Search size={15} />
              <span>Search intelligence…</span>
              <kbd>
                <Command size={10} /> K
              </kbd>
            </button>
            <span className="topbar-separator" />
            <div className={`connection-indicator ${connected ? '' : 'disconnected'}`}>
              <i />
              {connected ? 'Live connection' : connecting ? 'Connecting' : 'Offline · retrying'}
            </div>
            <div className="notification-wrap">
              <IconButton
                label="View alerts"
                className={notifications ? 'active' : ''}
                onClick={() => setNotifications((s) => !s)}
              >
                <Bell size={18} />
                {unread > 0 && <i className="notification-dot" />}
              </IconButton>
              {notifications && (
                <div className="notification-popover">
                  <div className="popover-heading">
                    <h3>
                      Network alerts <span>{unread}</span>
                    </h3>
                    <button onClick={() => setSeen(alerts.map((a) => a.id))}>Mark all read</button>
                  </div>
                  {alerts.length ? (
                    alerts.slice(0, 5).map((a) => (
                      <button
                        key={a.id}
                        className={`notification-item ${seen.includes(a.id) ? 'read' : ''}`}
                        onClick={() => {
                          setSeen((s) => [...s, a.id]);
                          setNotifications(false);
                          selectAccount(a.account_id);
                        }}
                      >
                        <ShieldAlert size={18} />
                        <div>
                          <strong>{a.title}</strong>
                          <p>
                            {a.member_count} connected accounts · score {a.risk_score}
                          </p>
                        </div>
                        <ArrowUpRight size={13} />
                      </button>
                    ))
                  ) : (
                    <Empty
                      title="No active alerts"
                      description="New connected-risk signals will appear here."
                    />
                  )}
                  <div className="popover-footer">Synthetic signals · human review required</div>
                </div>
              )}
            </div>
            <button
              className="top-avatar"
              title="System diagnostics"
              aria-label="Open analyst workspace diagnostics"
              onClick={() => setDiagnostics(true)}
            >
              AN
            </button>
          </div>
        </header>
        <main className="main-content">
          <Outlet />
        </main>
        <footer className="app-footer">
          <PrototypeNote compact />
          <span>
            MULEHUNTER ENGINE <i />
            v1.0
          </span>
        </footer>
      </div>
      {search && <GlobalSearch onClose={() => setSearch(false)} />}
      {diagnostics && <Diagnostics onClose={() => setDiagnostics(false)} />}
      <AttackProgressCard />
      <AccountDrawer />
      <Toasts />
    </div>
  );
}
