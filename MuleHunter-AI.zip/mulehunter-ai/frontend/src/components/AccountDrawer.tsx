import { useState, useEffect, useRef } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  ArrowUpRight,
  ScanLine,
  ShieldAlert,
  Fingerprint,
  RefreshCw,
  ArrowDownLeft,
  Network,
  FilePlus2,
  ChevronRight,
  Info,
  BrainCircuit,
} from 'lucide-react';
import { api, post, money, count, riskColor } from '../lib/api';
import type { Account, Case } from '../lib/types';
import { useLive } from '../lib/live';
import { IconButton, Button, Badge, Loading, ErrorState, Score } from './ui';
import { DnaChart } from './charts';
export function ScoreBreakdown({ account }: { account: Account }) {
  const labels: Record<string, string> = {
    behavioral: 'Behavioral anomaly',
    velocity: 'Transaction velocity',
    graph: 'Graph intelligence',
    temporal: 'Temporal flow',
    exposure: 'Network exposure',
  };
  const weights: Record<string, number> = {
    behavioral: 25,
    velocity: 20,
    graph: 25,
    temporal: 15,
    exposure: 15,
  };
  return (
    <div className="score-breakdown">
      {Object.entries(account.scores).map(([k, v]) => (
        <div className="breakdown-row" key={k}>
          <div>
            <span>{labels[k]}</span>
            <small>{weights[k]}% weight</small>
            <b>{Math.round(v)}</b>
          </div>
          <i>
            <span
              style={{
                width: `${v}%`,
                background: riskColor(
                  v <= 30 ? 'SAFE' : v <= 60 ? 'SUSPICIOUS' : v <= 80 ? 'HIGH RISK' : 'CRITICAL',
                ),
              }}
            />
          </i>
        </div>
      ))}
      <p className="micro-note">Weighted sum of five independent layers · 0–100 scale</p>
    </div>
  );
}
export function EvidenceList({ account }: { account: Account }) {
  return (
    <div className="evidence-list">
      {account.explanation.evidence.map((e, i) => (
        <div className="evidence-item" key={`${e.title}-${i}`}>
          <span className="evidence-number">{String(i + 1).padStart(2, '0')}</span>
          <div>
            <h4>{e.title}</h4>
            <p>{e.detail}</p>
            <span className="evidence-tag">
              {e.signal} signal · {e.contribution.toFixed(1)} weighted pts*
            </span>
          </div>
        </div>
      ))}
      <p className="micro-note">
        *Evidence can share a layer. Points are not additive across evidence items.
      </p>
    </div>
  );
}
export function AccountDrawer() {
  const { selectedAccount, selectAccount, notify } = useLive();
  const drawerRef = useRef<HTMLElement>(null);
  const [tab, setTab] = useState('overview');
  const [busy, setBusy] = useState(false);
  const client = useQueryClient();
  const nav = useNavigate();
  const {
    data: account,
    isLoading,
    error,
    refetch,
  } = useQuery({
    queryKey: ['account', selectedAccount],
    queryFn: () => api<Account>(`/accounts/${selectedAccount}`),
    enabled: !!selectedAccount,
  });
  useEffect(() => {
    setTab('overview');
    if (!selectedAccount) return;
    const prior = document.activeElement as HTMLElement;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const timer = setTimeout(() => drawerRef.current?.focus(), 20);
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') selectAccount(null);
      if (e.key === 'Tab') {
        const items = drawerRef.current?.querySelectorAll<HTMLElement>(
          'button:not(:disabled),a[href],input,select,textarea,[tabindex="0"]',
        );
        if (!items?.length) return;
        const first = items[0],
          last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', key);
    return () => {
      clearTimeout(timer);
      document.removeEventListener('keydown', key);
      document.body.style.overflow = oldOverflow;
      if (prior?.isConnected) prior.focus();
    };
  }, [selectedAccount, selectAccount]);
  async function create() {
    if (!account) return;
    setBusy(true);
    try {
      const c = await post<Case>('/cases', {
        account_ids: [account.id],
        title: `Account review · ${account.id}`,
      });
      client.invalidateQueries({ queryKey: ['cases'] });
      selectAccount(null);
      nav(`/investigations/${c.id}`);
      notify('Investigation case created', 'success', c.id);
    } catch (e) {
      notify((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  }
  async function analyze() {
    if (!account) return;
    setBusy(true);
    try {
      await post('/analyze/account', { account_id: account.id });
      await refetch();
      notify('All intelligence layers recomputed');
    } catch (e) {
      notify((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  }
  return (
    <AnimatePresence>
      {selectedAccount && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="drawer-backdrop"
            onClick={() => selectAccount(null)}
          />
          <motion.aside
            ref={drawerRef}
            tabIndex={-1}
            className="account-drawer"
            initial={{ x: 480 }}
            animate={{ x: 0 }}
            exit={{ x: 480 }}
            transition={{ type: 'spring', damping: 32, stiffness: 320 }}
            role="dialog"
            aria-modal="true"
            aria-label={`Account intelligence ${selectedAccount}`}
          >
            <div className="drawer-header">
              <div className="eyebrow">
                <ScanLine size={14} /> ACCOUNT INTELLIGENCE
              </div>
              <IconButton label="Close account details" onClick={() => selectAccount(null)}>
                <X size={20} />
              </IconButton>
            </div>
            {isLoading ? (
              <Loading />
            ) : error ? (
              <ErrorState error={error} retry={refetch} />
            ) : (
              account && (
                <>
                  <div className="account-summary">
                    <div className="account-avatar">
                      <Fingerprint size={27} />
                    </div>
                    <div>
                      <h2>{account.id}</h2>
                      <p>
                        {account.label} · Synthetic {account.account_type}
                      </p>
                    </div>
                    <IconButton
                      label="Open full Fraud DNA profile"
                      onClick={() => {
                        nav(`/dna?account=${account.id}`);
                        selectAccount(null);
                      }}
                    >
                      <ArrowUpRight size={17} />
                    </IconButton>
                  </div>
                  <div className="account-risk-summary">
                    <div>
                      <span className="eyebrow">COMPOSITE RISK SCORE</span>
                      <Score value={account.risk_score} large />
                    </div>
                    <div>
                      <Badge level={account.risk_level} />
                      <span className="risk-signal-caption">5-layer analysis</span>
                    </div>
                  </div>
                  <div className="drawer-tabs">
                    {['overview', 'fraud DNA', 'AI evidence'].map((t) => (
                      <button
                        key={t}
                        className={tab === t ? 'active' : ''}
                        onClick={() => setTab(t)}
                      >
                        {t === 'overview'
                          ? 'Overview'
                          : t === 'fraud DNA'
                            ? 'Fraud DNA'
                            : 'AI evidence'}
                      </button>
                    ))}
                  </div>
                  <div className="drawer-content">
                    {tab === 'overview' ? (
                      <>
                        <div className="primary-finding">
                          <ShieldAlert size={19} />
                          <div>
                            <span>PRIMARY SIGNAL</span>
                            <h3>{account.explanation.primary_reason}</h3>
                            <p>{account.explanation.evidence[0]?.detail}</p>
                          </div>
                        </div>
                        <div className="account-metrics-grid">
                          <div>
                            <span>Total transactions</span>
                            <strong>{count(account.metrics.transaction_count)}</strong>
                          </div>
                          <div>
                            <span>Counterparties</span>
                            <strong>{account.metrics.unique_counterparties}</strong>
                          </div>
                          <div>
                            <span>
                              <ArrowDownLeft size={12} /> Incoming value
                            </span>
                            <strong>{money(account.metrics.incoming_amount, true)}</strong>
                          </div>
                          <div>
                            <span>
                              <ArrowUpRight size={12} /> Outgoing value
                            </span>
                            <strong>{money(account.metrics.outgoing_amount, true)}</strong>
                          </div>
                          <div>
                            <span>Network centrality</span>
                            <strong>{account.metrics.network_centrality.toFixed(4)}</strong>
                          </div>
                          <div>
                            <span>Risk connections</span>
                            <strong className="text-orange">
                              {account.metrics.suspicious_connections}
                            </strong>
                          </div>
                        </div>
                        <div className="section-eyebrow">HOW THE SCORE WAS BUILT</div>
                        <ScoreBreakdown account={account} />
                      </>
                    ) : tab === 'fraud DNA' ? (
                      <>
                        <div className="chart-legend">
                          <span>
                            <i className="green-dot" />
                            Current behavior
                          </span>
                          <span>
                            <i className="gray-dot" />
                            Synthetic baseline
                          </span>
                        </div>
                        <DnaChart account={account} />
                        <div className="profile-rows">
                          {[
                            ['Velocity', `${account.metrics.transaction_velocity} txn/min`],
                            ['Average value', money(account.metrics.average_transaction_value)],
                            ['Maximum value', money(account.metrics.maximum_transaction_value)],
                            [
                              'Fan-in / fan-out',
                              `${account.metrics.fan_in_ratio}× / ${account.metrics.fan_out_ratio}×`,
                            ],
                            [
                              'Average interval',
                              `${account.metrics.average_transaction_interval}s`,
                            ],
                            [
                              'Circular flow',
                              account.metrics.in_cycle
                                ? 'Directed cycle detected'
                                : 'No short cycle observed',
                            ],
                            ['Risk exposure', `${account.metrics.risk_exposure}/100`],
                          ].map(([k, v]) => (
                            <div key={k}>
                              <span>{k}</span>
                              <strong>{v}</strong>
                            </div>
                          ))}
                        </div>
                        <p className="micro-note">
                          Radar axes are normalized heuristics. Reference shape is illustrative, not
                          a real customer cohort.
                        </p>
                      </>
                    ) : (
                      <>
                        <div className="intelligence-label">
                          <BrainCircuit size={16} /> Explainable, not a black box
                        </div>
                        <EvidenceList account={account} />
                        <div className="model-output">
                          <h4>Machine learning output</h4>
                          <div>
                            <span>Isolation Forest anomaly</span>
                            <b>{account.ml.anomaly_score}/100</b>
                          </div>
                          <div>
                            <span>Normality score</span>
                            <b>{account.ml.normality_score}/100</b>
                          </div>
                          <div>
                            <span>Synthetic RF estimate</span>
                            <b>{(account.ml.fraud_probability * 100).toFixed(1)}%</b>
                          </div>
                          <p>{account.ml.model_note}</p>
                        </div>
                      </>
                    )}
                    <div className="recommended-action">
                      <div className="eyebrow">RECOMMENDED NEXT STEP</div>
                      <h4>{account.explanation.recommended_action}</h4>
                      <p>For investigator review. No account action is taken automatically.</p>
                    </div>
                    <div className="drawer-note">
                      <Info size={14} />
                      <p>{account.explanation.disclaimer}</p>
                    </div>
                  </div>
                  <div className="drawer-footer">
                    <Button onClick={analyze} loading={busy}>
                      <RefreshCw size={15} />
                      Re-analyze
                    </Button>
                    <Button variant="primary" onClick={create} loading={busy}>
                      <FilePlus2 size={15} />
                      Create case
                    </Button>
                  </div>
                </>
              )
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
