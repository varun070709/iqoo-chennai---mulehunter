import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import {
  FlaskConical,
  Zap,
  Play,
  Square,
  RotateCcw,
  ArrowRight,
  ShieldCheck,
  ArrowDownToLine,
  ArrowUpFromLine,
  Orbit,
  Waypoints,
  Network,
  Activity,
  Users,
  SlidersHorizontal,
  Check,
  Info,
  ArrowUpRight,
  Radio,
  Send,
  Terminal,
  LoaderCircle,
} from 'lucide-react';
import { api, post, count, money } from '../lib/api';
import type { Account, Transaction } from '../lib/types';
import { useLive } from '../lib/live';
import { PageHeader, Panel, PanelHeader, Button, Modal, Badge, Score } from '../components/ui';
const patterns = [
  {
    id: 'normal',
    label: 'Normal payments',
    icon: ShieldCheck,
    desc: 'Everyday synthetic UPI, IMPS and NEFT activity.',
  },
  {
    id: 'suspicious',
    label: 'Suspicious transfers',
    icon: Activity,
    desc: 'High-value, rapid transfers across a short chain.',
  },
  {
    id: 'mule',
    label: 'Mule account',
    icon: Users,
    desc: 'Incoming collections rapidly passed through layered wallets.',
  },
  {
    id: 'fraud_ring',
    label: 'Fraud ring',
    icon: Network,
    desc: 'Coordinated fan-in, layering, circular transfers and dispersal.',
  },
  {
    id: 'fan_in',
    label: 'Fan-in attack',
    icon: ArrowDownToLine,
    desc: 'Many source wallets send repeated payments to a central collector.',
  },
  {
    id: 'fan_out',
    label: 'Fan-out attack',
    icon: ArrowUpFromLine,
    desc: 'One wallet rapidly disperses money to many distinct recipients.',
  },
  {
    id: 'circular',
    label: 'Circular laundering',
    icon: Orbit,
    desc: 'Funds repeatedly move around a short directed cycle.',
  },
  {
    id: 'multi_hop',
    label: 'Rapid multi-hop',
    icon: Waypoints,
    desc: 'Time-ordered payments cross three intermediate wallet hops.',
  },
];
export function SimulationLab() {
  const { dashboard, notify, runAttack, attackBusy } = useLive();
  const client = useQueryClient();
  const nav = useNavigate();
  const [config, setConfig] = useState({
    number_of_accounts: 500,
    number_of_transactions: 5000,
    fraud_percentage: 8,
    transaction_speed: 1,
    fraud_pattern: 'fraud_ring',
  });
  const [busy, setBusy] = useState('');
  const [confirm, setConfirm] = useState<'generate' | 'reset' | null>(null);
  const [lastRun, setLastRun] = useState<{ title: string; detail: string } | null>(null);
  const [manual, setManual] = useState({
    sender: '',
    receiver: '',
    amount: 25000,
    transaction_type: 'UPI',
  });
  const [result, setResult] = useState<{
    transaction: Transaction;
    sender_analysis: Account;
    receiver_analysis: Account;
  } | null>(null);
  const { data: accounts } = useQuery({
    queryKey: ['accounts', 'picker'],
    queryFn: () => api<{ items: Account[] }>('/accounts?limit=2000'),
  });
  const selected = patterns.find((p) => p.id === config.fraud_pattern)!;
  async function action(kind: 'generate' | 'reset' | 'start' | 'stop' | 'inject') {
    setConfirm(null);
    setBusy(kind);
    try {
      if (kind === 'inject') {
        const r = await post<{ new_accounts: number; new_transactions: number; hub: string }>(
          '/simulate/inject-fraud',
          { pattern: config.fraud_pattern, number_of_accounts: 12 },
        );
        setLastRun({
          title: 'Pattern injected',
          detail: `${r.new_accounts} wallets and ${r.new_transactions} transfers added. Hub: ${r.hub}.`,
        });
        notify(
          'Synthetic pattern injected',
          'success',
          `${r.new_transactions} transfers analyzed through the live pipeline.`,
        );
      } else {
        const body =
          kind === 'reset'
            ? {
                action: 'reset',
                number_of_accounts: 500,
                number_of_transactions: 5000,
                fraud_percentage: 8,
                fraud_pattern: 'demo',
              }
            : { ...config, action: kind };
        await post('/simulate', body);
        setLastRun({
          title:
            kind === 'generate'
              ? 'Dataset generated'
              : kind === 'reset'
                ? 'Baseline restored'
                : kind === 'start'
                  ? 'Live stream started'
                  : 'Simulation stopped',
          detail:
            kind === 'generate'
              ? `${count(config.number_of_accounts)} accounts · ${count(config.number_of_transactions)} transactions · ${selected.label}`
              : kind === 'reset'
                ? '500 fictional accounts and 5,000 synthetic transfers restored.'
                : kind === 'start'
                  ? `${config.transaction_speed} tx/sec target · ${config.fraud_percentage}% injection chance per batch`
                  : 'No new live transactions will be generated.',
        });
        notify(
          kind === 'generate'
            ? 'New simulation is ready'
            : kind === 'reset'
              ? 'Sandbox restored'
              : kind === 'start'
                ? 'Live stream started'
                : 'Simulation paused',
        );
      }
      client.invalidateQueries();
    } catch (e) {
      notify((e as Error).message, 'error');
    } finally {
      setBusy('');
    }
  }
  async function analyze(e: React.FormEvent) {
    e.preventDefault();
    setBusy('manual');
    try {
      const r = await post<typeof result>('/analyze/transaction', { ...manual, persist: true });
      setResult(r);
      notify('Transaction analyzed and stored');
      client.invalidateQueries();
    } catch (e) {
      notify((e as Error).message, 'error');
    } finally {
      setBusy('');
    }
  }
  return (
    <>
      <PageHeader
        eyebrow="CONTROLLED ADVERSARIAL TESTING"
        title="Build the threat. Test the defense"
        description="A safe environment to explore how connected fraud patterns emerge."
      >
        <span className="sandbox-badge">
          <ShieldCheck size={14} />
          ISOLATED SANDBOX
        </span>
        <Button variant="primary" onClick={runAttack} loading={attackBusy} disabled={!!busy}>
          <Zap size={15} />
          {attackBusy ? 'Attack in progress' : 'Run demo attack'}
        </Button>
      </PageHeader>
      <div className="lab-hero-strip">
        <div className="lab-hero-icon">
          <FlaskConical size={26} />
        </div>
        <div>
          <h3>Real analysis. Zero real-world risk.</h3>
          <p>
            Every wallet is fictional. Every signal is computed. No banking systems are connected.
          </p>
        </div>
        <span className="mono">SIMULATION ENGINE / v1.0</span>
      </div>
      <div className="lab-grid">
        <Panel className="lab-config">
          <PanelHeader
            title="Configure your simulation"
            subtitle="Choose the scale and behavior of your synthetic network."
            icon={<SlidersHorizontal size={18} />}
          >
            <span className="subtle-tag">01 / CONFIGURE</span>
          </PanelHeader>
          <div className="lab-form">
            <div className="form-two-cols">
              <label>
                Number of accounts
                <input
                  type="number"
                  min={20}
                  max={2000}
                  value={config.number_of_accounts}
                  onChange={(e) =>
                    setConfig({ ...config, number_of_accounts: Number(e.target.value) })
                  }
                />
                <small>20–2,000 fictional wallets</small>
              </label>
              <label>
                Number of transactions
                <input
                  type="number"
                  min={20}
                  max={20000}
                  value={config.number_of_transactions}
                  onChange={(e) =>
                    setConfig({ ...config, number_of_transactions: Number(e.target.value) })
                  }
                />
                <small>20–20,000 synthetic payments</small>
              </label>
            </div>
            <div className="form-two-cols range-fields">
              <label>
                <span>
                  Fraud-pattern share <b>{config.fraud_percentage}%</b>
                </span>
                <input
                  aria-label="Fraud percentage"
                  type="range"
                  min="0"
                  max="50"
                  step="1"
                  disabled={config.fraud_pattern === 'normal'}
                  value={config.fraud_percentage}
                  onChange={(e) =>
                    setConfig({ ...config, fraud_percentage: Number(e.target.value) })
                  }
                />
                <small>Generation: transfer share · stream: batch injection chance</small>
              </label>
              <label>
                <span>
                  Transaction speed <b>{config.transaction_speed} tx/s</b>
                </span>
                <input
                  aria-label="Transaction speed"
                  type="range"
                  min=".2"
                  max="10"
                  step=".2"
                  value={config.transaction_speed}
                  onChange={(e) =>
                    setConfig({ ...config, transaction_speed: Number(e.target.value) })
                  }
                />
                <small>Target rate; analysis runs in three-second batches</small>
              </label>
            </div>
            <div className="section-label-row">
              <span className="section-eyebrow">FRAUD PATTERN</span>
              <span>Select an attack behavior</span>
            </div>
            <div className="pattern-selector">
              {patterns.map((p) => (
                <button
                  key={p.id}
                  className={config.fraud_pattern === p.id ? 'selected' : ''}
                  onClick={() =>
                    setConfig({
                      ...config,
                      fraud_pattern: p.id,
                      fraud_percentage: p.id === 'normal' ? 0 : config.fraud_percentage || 8,
                    })
                  }
                >
                  <p.icon size={19} />
                  <span>{p.label}</span>
                  {config.fraud_pattern === p.id && <Check size={13} />}
                </button>
              ))}
            </div>
            <div className="pattern-description">
              <selected.icon size={17} />
              <p>{selected.desc}</p>
            </div>
            <div className="lab-main-actions">
              <Button
                variant="primary"
                onClick={() => setConfirm('generate')}
                loading={busy === 'generate'}
                disabled={!!busy || attackBusy}
              >
                <FlaskConical size={15} />
                Generate simulation
              </Button>
              <Button
                onClick={() => action('inject')}
                loading={busy === 'inject'}
                disabled={!!busy || attackBusy}
              >
                <Zap size={15} />
                Inject pattern
              </Button>
            </div>
          </div>
        </Panel>
        <div className="lab-right">
          <Panel className="lab-telemetry">
            <PanelHeader title="Live run telemetry">
              <span className={`telemetry-status ${dashboard?.stream_running ? 'running' : ''}`}>
                <i />
                {dashboard?.stream_running ? 'RUNNING' : 'PAUSED'}
              </span>
            </PanelHeader>
            <div className="lab-monitor-visual">
              <div className="monitor-orbit orbit-one" />
              <div className="monitor-orbit orbit-two" />
              <div className="monitor-center">
                <Network size={28} />
              </div>
              <span className="monitor-node n1" />
              <span className="monitor-node n2" />
              <span className="monitor-node n3" />
              <span className="monitor-node n4" />
              <span className="monitor-scan" />
              <div className="monitor-caption">
                {dashboard?.stream_running ? 'LISTENING TO THE NETWORK' : 'SIMULATION STANDBY'}
              </div>
            </div>
            <div className="telemetry-stats">
              <div>
                <span>Active accounts</span>
                <strong>{count(dashboard?.total_accounts || 0)}</strong>
              </div>
              <div>
                <span>Analyzed transfers</span>
                <strong>{count(dashboard?.total_transactions || 0)}</strong>
              </div>
              <div>
                <span>High-risk accounts</span>
                <strong className="text-red">{dashboard?.high_risk_accounts || 0}</strong>
              </div>
              <div>
                <span>Detected networks</span>
                <strong className="text-orange">{dashboard?.active_fraud_networks || 0}</strong>
              </div>
              <div>
                <span>Average analysis cycle</span>
                <strong>{dashboard?.average_detection_time?.toFixed(0) || '—'} ms</strong>
              </div>
            </div>
            <div className="lab-stream-actions">
              <Button
                onClick={() => action('start')}
                loading={busy === 'start'}
                disabled={!!busy || attackBusy}
              >
                <Play size={14} />
                Start live stream
              </Button>
              <Button
                onClick={() => action('stop')}
                loading={busy === 'stop'}
                disabled={!!busy || (!dashboard?.stream_running && !attackBusy)}
              >
                <Square size={13} />
                Stop simulation
              </Button>
            </div>
          </Panel>
          <Panel className="lab-run-log">
            <div className="section-eyebrow">
              <Terminal size={14} /> LAST OPERATION
            </div>
            {lastRun ? (
              <>
                <h3>{lastRun.title}</h3>
                <p>{lastRun.detail}</p>
              </>
            ) : (
              <>
                <h3>Ready for your next scenario</h3>
                <p>
                  Configure a pattern, inject it into the live network, and inspect its evidence.
                </p>
              </>
            )}
            <button className="section-link" onClick={() => nav('/network')}>
              Open network explorer
              <ArrowUpRight size={14} />
            </button>
          </Panel>
          <button
            className="reset-network"
            onClick={() => setConfirm('reset')}
            disabled={!!busy || attackBusy}
          >
            <RotateCcw size={14} />
            Reset network to baseline<span>500 accounts / 5,000 txns</span>
          </button>
        </div>
      </div>
      <Panel className="manual-transaction">
        <PanelHeader
          title="Analyze a single transaction"
          subtitle="Submit a fictional payment to the same behavioral, graph and temporal pipeline."
          icon={<Send size={17} />}
        >
          <span className="subtle-tag">POST /analyze/transaction</span>
        </PanelHeader>
        <form onSubmit={analyze} className="manual-form">
          <label>
            Sender
            <select
              required
              aria-label="Manual transaction sender"
              value={manual.sender}
              onChange={(e) => setManual({ ...manual, sender: e.target.value })}
            >
              <option value="">Choose source account</option>
              {accounts?.items.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.id} · {a.risk_score}
                </option>
              ))}
            </select>
          </label>
          <ArrowRight size={16} />
          <label>
            Receiver
            <select
              required
              aria-label="Manual transaction receiver"
              value={manual.receiver}
              onChange={(e) => setManual({ ...manual, receiver: e.target.value })}
            >
              <option value="">Choose destination account</option>
              {accounts?.items.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.id} · {a.risk_score}
                </option>
              ))}
            </select>
          </label>
          <label>
            Amount (INR)
            <input
              type="number"
              min="1"
              max="10000000"
              required
              step=".01"
              value={manual.amount}
              onChange={(e) => setManual({ ...manual, amount: Number(e.target.value) })}
            />
          </label>
          <label>
            Payment rail
            <select
              value={manual.transaction_type}
              onChange={(e) => setManual({ ...manual, transaction_type: e.target.value })}
            >
              {['UPI', 'IMPS', 'NEFT', 'CASHOUT'].map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </label>
          <Button
            type="submit"
            variant="primary"
            loading={busy === 'manual'}
            disabled={!!busy || attackBusy}
          >
            Analyze & ingest
            <ArrowUpRight size={14} />
          </Button>
        </form>
        {result && (
          <div className="manual-result">
            <div>
              <ShieldCheck size={20} />
              <div>
                <strong>{result.transaction.transaction_id} analyzed</strong>
                <p>
                  {money(result.transaction.amount)} · {result.transaction.sender} →{' '}
                  {result.transaction.receiver}
                </p>
              </div>
              <Score value={result.transaction.risk_score} />
              <Badge level={result.transaction.risk_level} />
            </div>
            <p>
              {
                (result.sender_analysis.risk_score > result.receiver_analysis.risk_score
                  ? result.sender_analysis
                  : result.receiver_analysis
                ).explanation.summary
              }
            </p>
          </div>
        )}
      </Panel>
      {confirm && (
        <Modal
          title={
            confirm === 'reset' ? 'Restore the baseline network?' : 'Generate a fresh simulation?'
          }
          onClose={() => setConfirm(null)}
        >
          <div className="modal-body">
            <div className="notice warning">
              <Info size={20} />
              <p>
                This replaces all sandbox accounts and transactions, and deletes existing
                investigation cases. Download any reports you want to retain before continuing.
              </p>
            </div>
            <p>
              {confirm === 'reset'
                ? 'The default 500-account, 5,000-transaction network will be restored.'
                : `A new network with ${count(config.number_of_accounts)} accounts and ${count(config.number_of_transactions)} transactions will be generated using the ${selected.label.toLowerCase()} pattern.`}
            </p>
            <div className="modal-actions">
              <Button onClick={() => setConfirm(null)}>Keep current network</Button>
              <Button variant="primary" onClick={() => action(confirm)}>
                <RotateCcw size={14} />
                {confirm === 'reset' ? 'Reset sandbox' : 'Generate new network'}
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </>
  );
}
