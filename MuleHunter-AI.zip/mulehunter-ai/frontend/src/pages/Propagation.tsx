import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import {
  GitBranch,
  Play,
  Pause,
  RotateCcw,
  Download,
  ArrowRight,
  Info,
  Network,
} from 'lucide-react';
import { api, saveJson } from '../lib/api';
import type { Account, GraphData } from '../lib/types';
import { useLive } from '../lib/live';
import {
  PageHeader,
  Panel,
  PanelHeader,
  Button,
  AccountPicker,
  Loading,
  ErrorState,
  Badge,
  Score,
  Empty,
} from '../components/ui';
import { NetworkGraph } from '../components/NetworkGraph';
export function Propagation() {
  const [params, setParams] = useSearchParams();
  const { selectAccount } = useLive();
  const [step, setStep] = useState(3);
  const [playing, setPlaying] = useState(false);
  const { data: accounts } = useQuery({
    queryKey: ['accounts', 'top'],
    queryFn: () => api<{ items: Account[] }>('/accounts?limit=20'),
  });
  const aid = params.get('account') || accounts?.items[0]?.id || '';
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['propagation', aid],
    queryFn: () => api<GraphData>(`/propagation/${aid}`),
    enabled: !!aid,
  });
  useEffect(() => {
    setStep(3);
    setPlaying(false);
  }, [aid]);
  useEffect(() => {
    if (!playing) return;
    const t = setInterval(
      () =>
        setStep((s) => {
          if (s >= 3) {
            setPlaying(false);
            return s;
          }
          return s + 1;
        }),
      1300,
    );
    return () => clearInterval(t);
  }, [playing]);
  return (
    <>
      <PageHeader
        eyebrow="NETWORK EXPOSURE ENGINE"
        title="Risk has a ripple effect"
        description="Understand how exposure travels—and where its influence fades."
      >
        <Button
          disabled={!data}
          onClick={() => data && saveJson(data, 'mulehunter-risk-propagation.json')}
        >
          <Download size={14} />
          Export exposure
        </Button>
        <Button
          variant="primary"
          disabled={!data}
          onClick={() => {
            if (playing) setPlaying(false);
            else {
              setStep(0);
              setPlaying(true);
            }
          }}
        >
          {playing ? <Pause size={15} /> : <Play size={15} />}
          {playing ? 'Pause propagation' : 'Replay propagation'}
        </Button>
      </PageHeader>
      <div className="account-context-bar">
        <AccountPicker
          value={aid}
          onChange={(account) => setParams({ account })}
          label="Select the source account"
        />
        <span>Exposure source</span>
        {data && <Score value={data.source_risk || 0} />}
      </div>
      {isLoading || !aid ? (
        <Loading label="Calculating three-hop risk exposure…" />
      ) : error ? (
        <ErrorState error={error} retry={refetch} />
      ) : data ? (
        <>
          <div className="propagation-steps">
            {[
              { label: 'Source account', desc: 'Independent behavioral risk' },
              { label: 'Direct connections', desc: 'First-degree exposure' },
              { label: 'Second-degree', desc: 'Reduced network influence' },
              { label: 'Third-degree', desc: 'Low, distance-decayed exposure' },
            ].map((s, i) => (
              <button
                className={`${i === step ? 'selected' : ''} ${i <= step ? 'reached' : ''}`}
                key={s.label}
                onClick={() => {
                  setStep(i);
                  setPlaying(false);
                }}
              >
                <span className="propagation-index">0{i}</span>
                <div>
                  <strong>{s.label}</strong>
                  <p>{s.desc}</p>
                </div>
                <b>{data.nodes.filter((n) => n.distance === i).length}</b>
                {i < 3 && <ArrowRight className="propagation-arrow" size={15} />}
              </button>
            ))}
          </div>
          <Panel>
            <PanelHeader
              title="Three degrees of exposure"
              subtitle="Only recent, meaningful transfers carry the signal."
              icon={<GitBranch size={18} />}
            >
              <span className="subtle-tag">HOP {step} OF 3</span>
            </PanelHeader>
            <NetworkGraph
              data={data}
              large
              onSelect={selectAccount}
              propagationStep={step}
              focusId={aid}
            />
            <div className="network-footer">
              <span>
                Decay factor <strong>0.66× / hop</strong>
              </span>
              <span>Payment frequency + amount + time proximity + source risk</span>
            </div>
          </Panel>
          <div className="propagation-bottom">
            <Panel>
              <PanelHeader
                title="Connected account exposure"
                subtitle="Current aggregate exposure versus contribution from the selected source."
              />
              <div className="table-scroll">
                <table className="simple-table">
                  <thead>
                    <tr>
                      <th>ACCOUNT</th>
                      <th>DISTANCE</th>
                      <th>RISK</th>
                      <th>TOTAL EXPOSURE</th>
                      <th>FROM SOURCE*</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.nodes
                      .filter((n) => n.id !== aid)
                      .sort((a, b) => (b.source_contribution || 0) - (a.source_contribution || 0))
                      .slice(0, 10)
                      .map((n) => (
                        <tr key={n.id}>
                          <td>
                            <button className="account-link" onClick={() => selectAccount(n.id)}>
                              {n.id}
                            </button>
                          </td>
                          <td>
                            {n.distance} hop{n.distance === 1 ? '' : 's'}
                          </td>
                          <td>
                            <Score value={n.risk_score} />
                          </td>
                          <td>{n.exposure?.toFixed(1)}/100</td>
                          <td className="text-lime">+{n.source_contribution?.toFixed(1)} pts</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
                {data.nodes.length === 1 && (
                  <Empty
                    title="No active connected accounts"
                    description="Recent transfers above INR 2,000 are needed to carry exposure."
                  />
                )}
              </div>
            </Panel>
            <div className="method-note vertical">
              <Network size={26} />
              <h3>
                Proximity is context.
                <br />
                Not culpability.
              </h3>
              <p>{data.note}</p>
              <p>
                Only independently high-risk sources propagate exposure. The final score assigns
                exposure a 15% weight, so association alone cannot produce a critical verdict.
              </p>
              <span className="micro-note">
                *Source contributions show the top eight stored provenance entries per account.
                Scores are bounded and not exact additive attribution across all possible paths.
              </span>
            </div>
          </div>
        </>
      ) : null}
    </>
  );
}
