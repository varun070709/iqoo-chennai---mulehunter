import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Search, Download, ChevronLeft, ChevronRight, Pause, Play } from 'lucide-react';
import { api, download, count } from '../lib/api';
import type { Transaction } from '../lib/types';
import { useLive } from '../lib/live';
import {
  PageHeader,
  Button,
  Panel,
  PanelHeader,
  LivePill,
  Loading,
  ErrorState,
} from '../components/ui';
import { TransactionTable } from '../components/Transactions';
export function TransactionsPage() {
  const [q, setQ] = useState('');
  const [level, setLevel] = useState('ALL');
  const [offset, setOffset] = useState(0);
  const { dashboard, toggleStream, notify } = useLive();
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['transactions', 'list', q, level, offset],
    queryFn: () =>
      api<{ items: Transaction[]; total: number }>(
        `/transactions?query=${encodeURIComponent(q)}&level=${encodeURIComponent(level)}&offset=${offset}&limit=25`,
      ),
  });
  const exportAll = async () => {
    try {
      await download('/transactions/export', 'mulehunter-transactions.csv');
      notify('Transaction export downloaded');
    } catch (e) {
      notify((e as Error).message, 'error');
    }
  };
  return (
    <>
      <PageHeader
        eyebrow="PAYMENT TELEMETRY"
        title="Every payment. In context"
        description="A live, searchable ledger of synthetic activity and connected risk."
      >
        <Button onClick={toggleStream}>
          {dashboard?.stream_running ? <Pause size={14} /> : <Play size={14} />}{' '}
          {dashboard?.stream_running ? 'Pause stream' : 'Resume stream'}
        </Button>
        <Button variant="primary" onClick={exportAll}>
          <Download size={15} />
          Export all CSV
        </Button>
      </PageHeader>
      <Panel>
        <PanelHeader
          title="Transaction ledger"
          subtitle="Last 24 hours · newest ingested first · event times in IST"
        >
          <LivePill />
        </PanelHeader>
        <div className="explorer-toolbar">
          <div className="inline-search">
            <Search size={16} />
            <input
              placeholder="Search transaction or account ID…"
              aria-label="Search transactions"
              value={q}
              onChange={(e) => {
                setQ(e.target.value);
                setOffset(0);
              }}
            />
          </div>
          <select
            aria-label="Transaction risk level"
            value={level}
            onChange={(e) => {
              setLevel(e.target.value);
              setOffset(0);
            }}
          >
            <option value="ALL">All risk levels</option>
            {['SAFE', 'SUSPICIOUS', 'HIGH RISK', 'CRITICAL'].map((l) => (
              <option key={l}>{l}</option>
            ))}
          </select>
        </div>
        {isLoading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} retry={refetch} />
        ) : (
          <TransactionTable transactions={data?.items || []} />
        )}
        <div className="pagination">
          <span>{count(data?.total || 0)} matching transactions</span>
          <div>
            <Button disabled={offset === 0} onClick={() => setOffset(Math.max(0, offset - 25))}>
              <ChevronLeft size={15} />
              Previous
            </Button>
            <span>{Math.floor(offset / 25) + 1}</span>
            <Button
              disabled={offset + 25 >= (data?.total || 0)}
              onClick={() => setOffset(offset + 25)}
            >
              Next
              <ChevronRight size={15} />
            </Button>
          </div>
        </div>
      </Panel>
    </>
  );
}
