import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowLeftRight,
  ArrowUpRight,
  ShieldAlert,
  ScanFace,
  IndianRupee,
  Zap,
  Pause,
  Play,
  Network,
  Clock3,
  ChevronRight,
  Activity,
  CalendarDays,
  ArrowUp,
  Radio,
  ShieldCheck,
} from 'lucide-react';
import { api, count, money, date, riskColor } from '../lib/api';
import type { Dashboard, GraphData, Transaction } from '../lib/types';
import { useLive } from '../lib/live';
import {
  PageHeader,
  Panel,
  PanelHeader,
  Button,
  LivePill,
  Badge,
  SectionLink,
  Loading,
  ErrorState,
  Empty,
} from '../components/ui';
import { NetworkGraph } from '../components/NetworkGraph';
import { VelocityChart, RiskDistribution } from '../components/charts';
import { TransactionTable } from '../components/Transactions';
function Sparkline({ values, color }: { values: number[]; color: string }) {
  const max = Math.max(...values, 1);
  const points = values
    .map((v, i) => `${(i / (values.length - 1)) * 76},${31 - (v / max) * 25}`)
    .join(' ');
  return (
    <svg className="metric-sparkline" viewBox="0 0 80 35" aria-hidden="true">
      <polyline
        points={points}
        fill="none"
        stroke={color}
        strokeWidth="1.5"
        strokeLinejoin="round"
      />
      <circle cx="76" cy={31 - (values[values.length - 1] / max) * 25} r="2.2" fill={color} />
    </svg>
  );
}
export function Overview() {
  const { dashboard, transactions, connected, runAttack, attackBusy, toggleStream, selectAccount } =
    useLive();
  const nav = useNavigate();
  const [hours, setHours] = useState(24);
  const [risk, setRisk] = useState('ALL');
  const { isLoading, error, refetch } = useQuery({
    queryKey: ['dashboard'],
    queryFn: () => api<Dashboard>('/dashboard'),
  });
  const {
    data: network,
    isLoading: networkLoading,
    error: networkError,
    refetch: refetchNetwork,
  } = useQuery({
    queryKey: ['network', 'overview', hours, risk],
    queryFn: () =>
      api<GraphData>(`/network?limit=90&hours=${hours}&level=${encodeURIComponent(risk)}`),
  });
  const { data: initialTransactions } = useQuery({
    queryKey: ['transactions', 'overview'],
    queryFn: () => api<{ items: Transaction[] }>('/transactions?limit=6'),
  });
  if (!dashboard)
    return isLoading ? (
      <Loading label="Starting your intelligence workspace…" />
    ) : (
      <ErrorState error={error} retry={refetch} />
    );
  const d = dashboard;
  const metrics = [
    {
      title: 'Transactions analyzed',
      value: count(d.total_transactions),
      icon: ArrowLeftRight,
      color: '#adce98',
      detail: (
        <>
          <ArrowUp size={11} />
          <strong>{count(d.last_hour_transactions)}</strong> in the last hour
        </>
      ),
      chart: d.hourly.map((h) => h.transactions),
    },
    {
      title: 'Flagged transactions',
      value: count(d.suspicious_transactions),
      icon: ShieldAlert,
      color: '#dfbd70',
      detail: (
        <>
          <span className="mini-dot yellow" />
          <strong>
            {((d.suspicious_transactions / Math.max(1, d.total_transactions)) * 100).toFixed(1)}%
          </strong>{' '}
          of total activity
        </>
      ),
      chart: d.hourly.map((h) => h.flagged),
    },
    {
      title: 'High-risk accounts',
      value: count(d.high_risk_accounts),
      icon: ScanFace,
      color: '#e29182',
      detail: (
        <>
          <span className="mini-dot red" />
          Across <strong>{d.active_fraud_networks} fraud networks</strong>
        </>
      ),
      chart: undefined,
    },
    {
      title: 'Potential exposure',
      value: money(d.potential_fraud_amount, true),
      icon: IndianRupee,
      color: '#badf8b',
      detail: (
        <>
          Gross high-risk transaction value<sup>†</sup>
        </>
      ),
      chart: undefined,
    },
  ];
  return (
    <>
      <PageHeader
        eyebrow="LIVE FINANCIAL INTELLIGENCE"
        title="Fraud command center"
        description="See the connections. Stay ahead of the threat."
      >
        <span className="date-label">
          <CalendarDays size={14} />
          {date(d.last_analysis_at)}
        </span>
        <Button onClick={toggleStream}>
          {d.stream_running ? <Pause size={14} /> : <Play size={14} />}
          {d.stream_running ? 'Pause stream' : 'Resume stream'}
        </Button>
        <Button variant="primary" onClick={runAttack} loading={attackBusy}>
          <Zap size={15} />
          {attackBusy ? 'Attack in progress' : 'Demo attack'}
        </Button>
      </PageHeader>
      <div className="overview-status">
        <span>
          <i className={d.stream_running && connected ? 'pulsing' : ''} />
          {d.stream_running ? 'Monitoring synthetic payment activity' : 'Live stream paused'}
        </span>
        <span>
          UPI / IMPS / NEFT<span className="status-divider">·</span>INDIA SANDBOX
        </span>
      </div>
      <div className="metrics-grid">
        {metrics.map((m, i) => (
          <motion.div
            key={m.title}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className={`metric-card metric-${i}`}
          >
            <div className="metric-top">
              <span>{m.title}</span>
              <m.icon size={17} strokeWidth={1.5} />
            </div>
            <div className="metric-value">
              {m.value}
              {m.chart ? (
                <Sparkline values={m.chart} color={m.color} />
              ) : i === 2 ? (
                <div className="metric-signal">
                  <i />
                  <i />
                  <i />
                  <i />
                  <i />
                </div>
              ) : (
                <span className="metric-currency-label">INR</span>
              )}
            </div>
            <div className="metric-detail" style={{ '--metric': m.color } as React.CSSProperties}>
              {m.detail}
            </div>
          </motion.div>
        ))}
      </div>
      <div className="network-overview-row">
        <Panel className="main-network-panel">
          <PanelHeader
            title="Transaction network"
            subtitle="Isolated signals become connected intelligence."
            icon={<Network size={18} />}
          >
            <LivePill label={d.stream_running && connected ? 'LIVE' : 'PAUSED'} />
            <select
              className="compact-select"
              aria-label="Network time window"
              value={hours}
              onChange={(e) => setHours(Number(e.target.value))}
            >
              <option value={24}>Last 24 hours</option>
              <option value={6}>Last 6 hours</option>
              <option value={1}>Last hour</option>
            </select>
          </PanelHeader>
          <div className="network-filter-row">
            <div className="segmented-control">
              {[
                ['ALL', 'All activity'],
                ['CRITICAL', 'Critical'],
                ['HIGH RISK', 'High risk'],
                ['SUSPICIOUS', 'Suspicious'],
              ].map(([v, l]) => (
                <button className={risk === v ? 'active' : ''} key={v} onClick={() => setRisk(v)}>
                  {l}
                  {v === 'CRITICAL' && <i className="red-dot" />}
                </button>
              ))}
            </div>
            <span className="micro-label">
              <span className="green-square" /> GRAPH ENGINE ONLINE
            </span>
          </div>
          {networkLoading ? (
            <Loading />
          ) : networkError ? (
            <ErrorState error={networkError} retry={refetchNetwork} />
          ) : network?.nodes.length ? (
            <NetworkGraph
              data={network}
              onSelect={selectAccount}
              onExpand={() => nav('/network')}
            />
          ) : (
            <div className="no-graph">
              <Empty
                title="No accounts at this risk level"
                description="Change the risk filter to explore the rest of the network."
              />
            </div>
          )}
          <div className="network-footer">
            <span>
              <i className="status-dot" />
              <strong>{count(d.total_accounts)}</strong> accounts
              <span className="footer-separator">/</span>
              <strong>{count(d.total_transactions)}</strong> transactions
            </span>
            <button onClick={() => nav('/fraud-rings')}>
              <span className="mini-dot red" />
              {d.active_fraud_networks} active networks
              <ArrowUpRight size={12} />
            </button>
          </div>
        </Panel>
        <div className="intelligence-column">
          <Panel className="risk-panel">
            <PanelHeader title="Network risk profile">
              <span className="subtle-tag">ACCOUNTS</span>
            </PanelHeader>
            <RiskDistribution data={d.risk_distribution} />
            <div className="risk-panel-footer">
              <ShieldCheck size={13} />
              <span>
                {(
                  ((d.risk_distribution[0]?.count || 0) / Math.max(1, d.total_accounts)) *
                  100
                ).toFixed(1)}
                % within reference behavior
              </span>
            </div>
          </Panel>
          <Panel className="alerts-panel">
            <PanelHeader title="Priority alerts">
              <span className="count-badge">{d.alerts.length}</span>
            </PanelHeader>
            {d.alerts.length ? (
              d.alerts.slice(0, 2).map((a, i) => (
                <button
                  key={a.id}
                  className={`priority-alert ${i === 0 ? 'featured' : ''}`}
                  onClick={() => selectAccount(a.account_id)}
                >
                  <div className="priority-alert-top">
                    <span>
                      <ShieldAlert size={13} />
                      {i === 0 ? 'CRITICAL SIGNAL' : 'NETWORK SIGNAL'}
                    </span>
                    <ArrowUpRight size={14} />
                  </div>
                  <h3>
                    {i === 0
                      ? 'Coordinated mule activity'
                      : a.patterns.includes('Circular flow')
                        ? 'Circular fund movement'
                        : a.title}
                  </h3>
                  <p>
                    {a.member_count} linked accounts <span>·</span> {money(a.volume, true)} volume
                  </p>
                  <div className="priority-alert-bottom">
                    <span className="mono">{a.id}</span>
                    <span style={{ color: riskColor(a.risk_level) }}>
                      RISK {a.risk_score}
                      <i />
                    </span>
                  </div>
                </button>
              ))
            ) : (
              <Empty
                title="No active network alerts"
                description="The engine is monitoring for connected signals."
              />
            )}
            <button className="all-alerts-link" onClick={() => nav('/fraud-rings')}>
              Explore detected networks
              <ArrowRightIcon />
            </button>
          </Panel>
        </div>
      </div>
      <div className="overview-bottom-row">
        <Panel className="velocity-panel">
          <PanelHeader
            title="Transaction velocity"
            subtitle="Payment activity over the last 12 hours"
          >
            <span className="chart-time-label">IST</span>
          </PanelHeader>
          <div className="chart-legend">
            <span>
              <i className="green-dot" />
              All transactions
            </span>
            <span>
              <i className="orange-dot" />
              Flagged
            </span>
          </div>
          <VelocityChart data={d.hourly} />
          <div className="detection-latency">
            <span className="latency-icon">
              <Activity size={17} />
            </span>
            <div>
              <strong>
                {Math.round(d.average_detection_time)}
                <small>ms</small>
              </strong>
              <span>Average detection cycle</span>
            </div>
            <span className="latency-note">
              Full network
              <br />5 intelligence layers
            </span>
          </div>
        </Panel>
        <Panel className="live-feed-panel">
          <PanelHeader
            title="Live transaction feed"
            subtitle="Latest ingested payments, scored in context"
          >
            <LivePill label="STREAM" />
            <SectionLink onClick={() => nav('/transactions')}>View all</SectionLink>
          </PanelHeader>
          <TransactionTable
            transactions={(transactions.length
              ? transactions
              : initialTransactions?.items || []
            ).slice(0, 6)}
            compact
          />
          <div className="feed-footer">
            <Radio size={12} />
            <span>
              {connected
                ? 'Connected to real-time analysis'
                : 'Reconnecting · HTTP fallback active'}
            </span>
            <span>All values in INR</span>
          </div>
        </Panel>
      </div>
      <div className="exposure-footnote">
        † Potential exposure is gross high-risk transaction volume, not verified fraud or prevented
        loss. The same funds may be counted at multiple hops.
      </div>
    </>
  );
}
function ArrowRightIcon() {
  return <ChevronRight size={14} />;
}
