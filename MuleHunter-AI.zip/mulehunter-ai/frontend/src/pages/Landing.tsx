import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowUpRight,
  ArrowRight,
  Play,
  ShieldCheck,
  Network,
  Activity,
  BrainCircuit,
  Clock3,
  GitBranch,
  ScanLine,
  Fingerprint,
  Layers,
  Check,
  ChevronRight,
} from 'lucide-react';
import { Logo } from '../components/Layout';
import { Button, PrototypeNote } from '../components/ui';
import { useLive } from '../lib/live';
import { count } from '../lib/api';
function HeroNetwork() {
  const points = Array.from({ length: 42 }, (_, i) => {
    const angle = i * 2.39996;
    const r = Math.sqrt(i + 1) * 34;
    return { x: 300 + Math.cos(angle) * r, y: 265 + Math.sin(angle) * r * 0.88 };
  });
  const edges = points
    .flatMap((p, i) => points.slice(i + 1).map((q, j) => ({ p, q, i, j: i + j + 1 })))
    .filter((e) => Math.hypot(e.p.x - e.q.x, e.p.y - e.q.y) < 105);
  return (
    <svg className="hero-network-svg" viewBox="0 0 600 530">
      <defs>
        <radialGradient id="heroGlow">
          <stop offset="0" stopColor="#8cab52" stopOpacity=".18" />
          <stop offset="1" stopColor="#8cab52" stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx="300" cy="265" r="260" fill="url(#heroGlow)" />
      <g stroke="#527445" fill="none" opacity=".2">
        <ellipse cx="300" cy="265" rx="252" ry="196" />
        <ellipse cx="300" cy="265" rx="205" ry="245" transform="rotate(45 300 265)" />
        <ellipse cx="300" cy="265" rx="110" ry="243" transform="rotate(-28 300 265)" />
        <ellipse cx="300" cy="265" rx="245" ry="90" />
      </g>
      {edges.map((e) => (
        <path
          key={`${e.i}-${e.j}`}
          id={`hero-edge-${e.i}-${e.j}`}
          d={`M${e.p.x},${e.p.y} L${e.q.x},${e.q.y}`}
          stroke={e.i < 6 ? '#9d7560' : '#597c4d'}
          strokeWidth=".8"
          opacity=".4"
        />
      ))}
      {edges
        .filter((_, i) => i % 7 === 0)
        .map((e, i) => (
          <circle key={`anim-${e.i}-${e.j}`} r="2" fill={e.i < 6 ? '#ec987c' : '#c0e995'}>
            <animateMotion dur={`${2 + (i % 4)}s`} repeatCount="indefinite" begin={`${i * 0.2}s`}>
              <mpath href={`#hero-edge-${e.i}-${e.j}`} />
            </animateMotion>
          </circle>
        ))}
      {points.map((p, i) => (
        <g key={i}>
          <circle
            cx={p.x}
            cy={p.y}
            r={i < 6 ? 12 : 7}
            fill={i < 6 ? '#33251d' : '#1c2d1e'}
            stroke={i < 6 ? '#d5986c' : '#a2c983'}
            strokeWidth="1"
          />
          {i < 6 && <circle cx={p.x} cy={p.y} r="19" fill="none" stroke="#a47750" opacity=".2" />}
          <circle cx={p.x} cy={p.y} r="2.5" fill={i < 6 ? '#e8ac82' : '#bbdd8e'} />
        </g>
      ))}
      <rect x="203" y="225" width="194" height="78" rx="12" fill="#172419" stroke="#6d8255" />
      <text
        x="300"
        y="252"
        fill="#b9d992"
        fontFamily="IBM Plex Mono"
        fontSize="9"
        textAnchor="middle"
        letterSpacing="2"
      >
        CONNECTED INTELLIGENCE
      </text>
      <text
        x="300"
        y="278"
        fill="#edf4e8"
        fontFamily="DM Sans"
        fontSize="18"
        fontWeight="600"
        textAnchor="middle"
      >
        MuleHunter AI
      </text>
    </svg>
  );
}
export function Landing() {
  const nav = useNavigate();
  const { dashboard, runAttack, attackBusy } = useLive();
  const features = [
    {
      title: 'Network intelligence',
      desc: 'See the coordinated network behind an isolated payment. Communities, centrality and directed cycles reveal the bigger picture.',
      icon: Network,
      route: '/network',
      tag: 'CONNECT THE DOTS',
    },
    {
      title: 'Behavioral Fraud DNA',
      desc: 'Compare velocity, value, fan-in and fan-out against a synthetic reference. Understand the signal behind every score.',
      icon: Fingerprint,
      route: '/dna',
      tag: 'DECODE THE BEHAVIOR',
    },
    {
      title: 'Trace the money trail',
      desc: 'Replay chronological money movement across accounts. Spot rapid layering, circular flow and potential cash-out paths.',
      icon: GitBranch,
      route: '/money-flow',
      tag: 'FOLLOW THE FLOW',
    },
  ];
  return (
    <div className="landing">
      <header className="landing-header">
        <Link to="/welcome">
          <Logo />
        </Link>
        <nav>
          <a href="#intelligence">Intelligence</a>
          <a href="#architecture">Architecture</a>
          <a href="#workflow">How it works</a>
        </nav>
        <Link to="/" className="btn btn-primary">
          Open workspace
          <ArrowUpRight size={15} />
        </Link>
      </header>
      <section className="landing-hero">
        <div className="hero-content">
          <div className="hero-eyebrow">
            <span />
            NEXT-GENERATION FINANCIAL INTELLIGENCE
          </div>
          <h1>
            MuleHunter <span>AI</span>
            <i>.</i>
          </h1>
          <h2>
            Detecting Fraud Networks
            <br />
            Before They Become
            <br />
            <span>Financial Crimes.</span>
          </h2>
          <p>
            Fraud is connected. Your intelligence should be, too.
            <br />
            Discover the patterns, follow the money, and turn signals into explainable
            investigations.
          </p>
          <div className="hero-actions">
            <Button variant="primary" onClick={() => nav('/')}>
              Start monitoring
              <ArrowRight size={17} />
            </Button>
            <Button
              onClick={async () => {
                await runAttack();
                nav('/');
              }}
              loading={attackBusy}
            >
              <Play size={15} />
              View live demo
            </Button>
          </div>
          <div className="hero-reassurance">
            <ShieldCheck size={15} />
            Synthetic data. Real analysis. Human judgment.
          </div>
        </div>
        <div className="hero-visual">
          <HeroNetwork />
          <div className="hero-visual-caption">
            <span className="status-dot" />
            <span>REAL-TIME NETWORK ANALYSIS</span>
            <b>ONLINE</b>
          </div>
          <div className="hero-floating-signal">
            <ScanLine size={19} />
            <div>
              <strong>See more than a transaction.</strong>
              <span>Behavior + timing + topology</span>
            </div>
            <Check size={15} />
          </div>
        </div>
      </section>
      <div className="landing-stat-strip">
        {[
          { v: count(dashboard?.total_accounts || 0), l: 'FICTIONAL ACCOUNTS' },
          { v: count(dashboard?.total_transactions || 0), l: 'PAYMENTS ANALYZED' },
          {
            v: String(dashboard?.active_fraud_networks || 0).padStart(2, '0'),
            l: 'EMERGING NETWORKS',
          },
          { v: '05', l: 'INTELLIGENCE LAYERS' },
        ].map((s) => (
          <div key={s.l}>
            <strong>{s.v}</strong>
            <span>{s.l}</span>
          </div>
        ))}
      </div>
      <section id="intelligence" className="landing-section">
        <div className="landing-section-heading">
          <div className="eyebrow">BEYOND THE RED FLAG</div>
          <h2>
            Don’t just detect an anomaly.
            <br />
            <span>Understand the network.</span>
          </h2>
          <p>
            Purpose-built tools that give every risk score a reason, every connection a context, and
            every investigator a clearer next step.
          </p>
        </div>
        <div className="landing-features">
          {features.map((f, i) => (
            <Link to={f.route} key={f.title}>
              <div className="feature-top">
                <span>0{i + 1}</span>
                <ArrowUpRight size={18} />
              </div>
              <f.icon size={35} strokeWidth={1.1} />
              <div className="eyebrow">{f.tag}</div>
              <h3>{f.title}</h3>
              <p>{f.desc}</p>
            </Link>
          ))}
        </div>
      </section>
      <section id="architecture" className="landing-architecture">
        <div>
          <span className="eyebrow">EXPLAINABLE BY DESIGN</span>
          <h2>
            Five perspectives.
            <br />
            One connected picture.
          </h2>
          <p>
            No black-box verdicts. A modular engine combines synthetic-trained machine learning,
            deterministic rules and network analysis into a transparent 0–100 risk score.
          </p>
          <Link to="/dna" className="section-link">
            Explore the intelligence layers
            <ArrowUpRight size={16} />
          </Link>
        </div>
        <div className="architecture-layers">
          {[
            {
              i: BrainCircuit,
              t: 'Behavioral anomaly',
              s: 'Isolation Forest + Random Forest',
              w: 25,
            },
            { i: Activity, t: 'Transaction velocity', s: 'Time-local frequency & spacing', w: 20 },
            { i: Network, t: 'Graph intelligence', s: 'Communities, fan patterns & cycles', w: 25 },
            { i: Clock3, t: 'Temporal money flow', s: 'Value-conserving FIFO matching', w: 15 },
            { i: Layers, t: 'Network exposure', s: 'Three-hop, weighted risk propagation', w: 15 },
          ].map((l, i) => (
            <div key={l.t}>
              <span className="architecture-index">0{i + 1}</span>
              <l.i size={19} />
              <div>
                <strong>{l.t}</strong>
                <span>{l.s}</span>
              </div>
              <b>{l.w}%</b>
            </div>
          ))}
        </div>
      </section>
      <section id="workflow" className="landing-section">
        <div className="landing-section-heading">
          <span className="eyebrow">FROM FIRST SIGNAL TO INVESTIGATION</span>
          <h2>A clearer path to safer payments.</h2>
        </div>
        <div className="landing-workflow">
          {[
            {
              t: 'Simulate',
              d: 'Generate realistic fictional payment activity and controlled attack patterns.',
              p: '/simulation',
            },
            {
              t: 'Connect',
              d: 'Analyze behavior, timing and network structure as new payments arrive.',
              p: '/',
            },
            {
              t: 'Investigate',
              d: 'Trace money flow, decode account DNA and review connected evidence.',
              p: '/network',
            },
            {
              t: 'Document',
              d: 'Create a case, record human judgment and export a detailed investigation report.',
              p: '/investigations',
            },
          ].map((s, i) => (
            <Link to={s.p} key={s.t}>
              <span>
                0{i + 1}
                <ArrowRight size={20} />
              </span>
              <h3>{s.t}</h3>
              <p>{s.d}</p>
            </Link>
          ))}
        </div>
      </section>
      <section className="landing-final-cta">
        <div>
          <span className="eyebrow">THE NEXT SIGNAL IS ALREADY CONNECTED</span>
          <h2>See what a single transaction can’t tell you.</h2>
        </div>
        <Button variant="primary" onClick={() => nav('/')}>
          Enter the command center
          <ArrowUpRight size={16} />
        </Button>
      </section>
      <footer className="landing-footer">
        <Logo />
        <PrototypeNote />
        <span>
          Fictional data. Decision support.
          <br />
          Never an automated fraud verdict.
        </span>
      </footer>
    </div>
  );
}
