import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import {
  Play,
  Pause,
  RotateCcw,
  ArrowRight,
  ArrowUpRight,
  Timer,
  GitBranch,
  IndianRupee,
  Network,
  FilePlus2,
  Check,
  Activity,
  Info,
  Wallet,
  ArrowDownToLine,
} from 'lucide-react';
import { api, post, money, time, riskColor, riskLevel } from '../lib/api';
import type { Account, FlowData, Case } from '../lib/types';
import { useLive } from '../lib/live';
import {
  PageHeader,
  Panel,
  PanelHeader,
  Button,
  AccountPicker,
  Loading,
  ErrorState,
  Empty,
  Badge,
} from '../components/ui';
import { TransactionTable } from '../components/Transactions';
export function MoneyFlow() {
  const [params, setParams] = useSearchParams();
  const nav = useNavigate();
  const { selectAccount, notify } = useLive();
  const [pathIndex, setPathIndex] = useState(0);
  const [step, setStep] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [busy, setBusy] = useState(false);
  const { data: accounts } = useQuery({
    queryKey: ['accounts', 'top'],
    queryFn: () => api<{ items: Account[] }>('/accounts?limit=20'),
  });
  const aid = params.get('account') || accounts?.items[0]?.id || '';
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['flows', aid],
    queryFn: () => api<FlowData>(`/flows?account_id=${aid}`),
    enabled: !!aid,
  });
  const path = data?.paths[pathIndex] || data?.paths[0];
  const nodes = path ? [path.events[0].sender, ...path.events.map((e) => e.receiver)] : [];
  useEffect(() => {
    setPathIndex(0);
    setStep(0);
    setPlaying(false);
  }, [aid]);
  useEffect(() => {
    if (!playing || !path) return;
    const t = setInterval(
      () =>
        setStep((s) => {
          if (s >= path.events.length) {
            setPlaying(false);
            return s;
          }
          return s + 1;
        }),
      950,
    );
    return () => clearInterval(t);
  }, [playing, path?.id, path?.events.length]);
  function play() {
    if (path && step >= path.events.length) setStep(0);
    setPlaying(!playing);
  }
  async function create() {
    if (!path) return;
    setBusy(true);
    try {
      const c = await post<Case>('/cases', {
        account_ids: [...new Set(nodes)],
        title: 'Rapid multi-hop money flow review',
      });
      nav(`/investigations/${c.id}`);
      notify('Money-flow investigation created');
    } catch (e) {
      notify((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageHeader
        eyebrow="TEMPORAL MONEY-FLOW INTELLIGENCE"
        title="Follow the money"
        description="Replay how funds move, fragment, circle back and leave the network."
      >
        <Button onClick={() => nav(`/network?account=${aid}`)} disabled={!aid}>
          <Network size={14} />
          View network
        </Button>
        <Button variant="primary" onClick={create} loading={busy} disabled={!path}>
          <FilePlus2 size={15} />
          Create case
        </Button>
      </PageHeader>
      <div className="account-context-bar">
        <AccountPicker
          value={aid}
          onChange={(account) => setParams({ account })}
          label="Select an origin account"
        />
        <span>Trace outgoing transfers from this account</span>
        {!!data?.paths.length && (
          <select
            aria-label="Select detected money flow"
            value={pathIndex}
            onChange={(e) => {
              setPathIndex(Number(e.target.value));
              setStep(0);
              setPlaying(false);
            }}
          >
            {data.paths.map((p, i) => (
              <option key={p.id} value={i}>
                {p.id} · {p.hops} hops · {p.duration_seconds}s
              </option>
            ))}
          </select>
        )}
      </div>
      {isLoading || !aid ? (
        <Loading label="Tracing chronological transfer paths…" />
      ) : error ? (
        <ErrorState error={error} retry={refetch} />
      ) : !path ? (
        <Panel>
          <Empty
            title="No rapid multi-hop chains from this account"
            description="Choose a high-risk account or run a demo attack. The detector requires time-ordered transfers with meaningful value continuity."
          >
            <Button onClick={() => nav('/simulation')}>
              Open simulation lab
              <ArrowUpRight size={14} />
            </Button>
          </Empty>
        </Panel>
      ) : (
        <>
          <div className="flow-summary">
            <div>
              <GitBranch size={19} />
              <span>Detected chain</span>
              <strong>{path.hops} hops</strong>
            </div>
            <div>
              <Timer size={19} />
              <span>Total time elapsed</span>
              <strong>{path.duration_seconds}s</strong>
            </div>
            <div>
              <IndianRupee size={19} />
              <span>Minimum hop value</span>
              <strong>{money(path.volume)}</strong>
            </div>
            <div>
              <Activity size={19} />
              <span>Temporal pattern</span>
              <strong>{path.circular ? 'Circular flow' : 'Rapid layering'}</strong>
            </div>
          </div>
          <Panel className="money-flow-panel">
            <PanelHeader
              title="A transaction is only the beginning"
              subtitle={`${path.id} · Chronological candidate chain · Synthetic event time`}
            >
              <Badge level="HIGH RISK" />
              <span className="subtle-tag">
                {step} / {path.hops} HOPS
              </span>
            </PanelHeader>
            <div className="flow-diagram">
              <div className="flow-diagram-inner">
                {nodes.map((id, i) => {
                  const event = path.events[Math.max(0, i - 1)];
                  const active = i <= step;
                  return (
                    <div className="flow-segment" key={`${id}-${i}`}>
                      <button
                        className={`flow-account ${active ? 'active' : ''} ${i === step ? 'current' : ''}`}
                        onClick={() => selectAccount(id)}
                      >
                        <span className="flow-role">
                          {i === 0
                            ? 'ORIGIN WALLET'
                            : i === nodes.length - 1
                              ? event.transaction_type === 'CASHOUT'
                                ? 'CASH-OUT'
                                : 'DESTINATION'
                              : `LAYER ${String(i).padStart(2, '0')}`}
                        </span>
                        <span className="flow-account-symbol">
                          {i === nodes.length - 1 && event.transaction_type === 'CASHOUT' ? (
                            <ArrowDownToLine size={24} />
                          ) : (
                            <Wallet size={24} />
                          )}
                        </span>
                        <strong>{id}</strong>
                        <small>
                          {i === 0 ? time(path.events[0].timestamp) : time(event.timestamp)} IST
                        </small>
                      </button>
                      {i < nodes.length - 1 && (
                        <div className={`flow-connector ${i < step ? 'active' : ''}`}>
                          <span>{money(path.events[i].amount, true)}</span>
                          <div>
                            <i />
                            <ArrowRight size={15} />
                          </div>
                          <small>{path.events[i].transaction_type}</small>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="replay-controls">
              <Button variant="primary" onClick={play}>
                {playing ? <Pause size={14} /> : <Play size={14} />}
                {playing ? 'Pause replay' : 'Replay money flow'}
              </Button>
              <button
                className="reset-replay"
                onClick={() => {
                  setStep(0);
                  setPlaying(false);
                }}
                aria-label="Reset replay"
              >
                <RotateCcw size={16} />
              </button>
              <div className="replay-slider">
                <input
                  type="range"
                  aria-label="Money flow timeline"
                  min="0"
                  max={path.events.length}
                  value={step}
                  onChange={(e) => {
                    setPlaying(false);
                    setStep(Number(e.target.value));
                  }}
                />
                <div>
                  <span>ORIGIN</span>
                  <span>
                    {step === 0
                      ? 'Awaiting first hop'
                      : time(path.events[Math.min(step - 1, path.events.length - 1)].timestamp) +
                        ' IST'}
                  </span>
                  <span>FINAL HOP</span>
                </div>
              </div>
            </div>
          </Panel>
          <div className="flow-bottom-grid">
            <Panel>
              <PanelHeader
                title="Transfer timeline"
                subtitle="Each hop is backed by a stored transaction."
              />
              <div className="flow-timeline">
                {path.events.map((e, i) => (
                  <button
                    key={`${e.id}-${i}`}
                    className={`timeline-event ${i < step ? 'active' : ''}`}
                    onClick={() => {
                      setStep(i + 1);
                      setPlaying(false);
                    }}
                  >
                    <span className="timeline-event-index">
                      {i < step ? <Check size={14} /> : i + 1}
                    </span>
                    <div>
                      <span className="mono">
                        {e.sender} <ArrowRight size={12} /> {e.receiver}
                      </span>
                      <p>
                        {e.transaction_id} · {time(e.timestamp)} IST · {e.transaction_type}
                      </p>
                    </div>
                    <strong>{money(e.amount)}</strong>
                    <Badge level={e.risk_level} small />
                  </button>
                ))}
              </div>
            </Panel>
            <Panel>
              <PanelHeader
                title="What the flow reveals"
                subtitle="Patterns observed around the selected account"
              />
              <div className="flow-pattern-content">
                <div className="pattern-tags">
                  {data?.patterns.map((p) => (
                    <span key={p}>{p}</span>
                  ))}
                </div>
                <div className="notice">
                  <Info size={17} />
                  <p>{data?.note}</p>
                </div>
                <div className="flow-model-note">
                  <h3>Funds can mix. Timing is not proof.</h3>
                  <p>
                    This replay follows plausible payment chains. It does not assert that the same
                    rupee traveled through every hop. FIFO matching separately estimates rapidly
                    forwarded value without double-counting matched incoming amounts.
                  </p>
                </div>
              </div>
            </Panel>
          </div>
        </>
      )}
    </>
  );
}
