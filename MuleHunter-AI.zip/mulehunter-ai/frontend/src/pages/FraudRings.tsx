import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import {
  ScanFace,
  Network,
  ArrowUpRight,
  Users,
  Zap,
  FolderPlus,
  Search,
  Check,
  ChevronDown,
} from 'lucide-react';
import { api, post, money, riskLevel, riskColor, count } from '../lib/api';
import type { Ring, GraphData, Case } from '../lib/types';
import { useLive } from '../lib/live';
import {
  PageHeader,
  Panel,
  Button,
  Badge,
  Loading,
  ErrorState,
  Empty,
  Score,
} from '../components/ui';
function RingMiniGraph({ ring, network }: { ring: Ring; network?: GraphData }) {
  const coords = new Map(
    ring.members.map((n, i) => [
      n,
      {
        x:
          i === 0 ? 170 : 170 + Math.cos(((i - 1) / (ring.members.length - 1)) * Math.PI * 2) * 112,
        y: i === 0 ? 93 : 93 + Math.sin(((i - 1) / (ring.members.length - 1)) * Math.PI * 2) * 65,
      },
    ]),
  );
  const edges = network?.edges.filter((e) => coords.has(e.source) && coords.has(e.target)) || [];
  return (
    <svg className="ring-mini-graph" viewBox="0 0 340 185">
      <defs>
        <radialGradient id={`glow-${ring.id}`}>
          <stop offset="0" stopColor="#b26351" stopOpacity=".12" />
          <stop offset="1" stopColor="#b26351" stopOpacity="0" />
        </radialGradient>
      </defs>
      <ellipse cx="170" cy="94" rx="148" ry="88" fill={`url(#glow-${ring.id})`} />
      {edges.map((e) => (
        <line
          key={e.id}
          x1={coords.get(e.source)!.x}
          y1={coords.get(e.source)!.y}
          x2={coords.get(e.target)!.x}
          y2={coords.get(e.target)!.y}
          stroke="#774b42"
          opacity=".45"
          strokeWidth=".8"
        />
      ))}
      {ring.members.map((id, i) => {
        const p = coords.get(id)!;
        const score = network?.nodes.find((n) => n.id === id)?.risk_score || 0;
        const c = riskColor(riskLevel(score));
        return (
          <g key={id}>
            <circle
              cx={p.x}
              cy={p.y}
              r={i === 0 ? 16 : 9}
              fill="#251e1b"
              stroke={c}
              strokeWidth={i === 0 ? 1.5 : 1}
            />
            <circle cx={p.x} cy={p.y} r={i === 0 ? 5 : 2.5} fill={c} />
            {i === 0 && (
              <>
                <circle cx={p.x} cy={p.y} r={24} fill="none" stroke={c} opacity=".2" />
                <text
                  x={p.x}
                  y={p.y + 37}
                  textAnchor="middle"
                  fill="#bf9a8e"
                  fontFamily="IBM Plex Mono"
                  fontSize="8"
                >
                  {id}
                </text>
              </>
            )}
          </g>
        );
      })}
    </svg>
  );
}
export function FraudRings() {
  const { runAttack, attackBusy, notify } = useLive();
  const nav = useNavigate();
  const [sort, setSort] = useState('risk');
  const [query, setQuery] = useState('');
  const [busy, setBusy] = useState('');
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['rings'],
    queryFn: () => api<{ items: Ring[]; total: number }>('/fraud-rings'),
  });
  const { data: network } = useQuery({
    queryKey: ['network', 'rings'],
    queryFn: () => api<GraphData>('/network?limit=150'),
  });
  const { data: cases } = useQuery({
    queryKey: ['cases'],
    queryFn: () => api<{ items: Case[] }>('/cases'),
  });
  const rings = [...(data?.items || [])]
    .filter((r) =>
      (r.id + ' ' + r.title + ' ' + r.patterns.join(' '))
        .toLowerCase()
        .includes(query.toLowerCase()),
    )
    .sort((a, b) =>
      sort === 'volume'
        ? b.volume - a.volume
        : sort === 'members'
          ? b.member_count - a.member_count
          : b.risk_score - a.risk_score,
    );
  async function investigate(ring: Ring) {
    const existing = cases?.items.find((c) => c.ring_id === ring.id);
    if (existing) {
      nav(`/investigations/${existing.id}`);
      return;
    }
    setBusy(ring.id);
    try {
      const c = await post<Case>('/cases', {
        title: 'Suspected mule account network',
        account_ids: ring.members,
        ring_id: ring.id,
      });
      nav(`/investigations/${c.id}`);
      notify('Network investigation created');
    } catch (e) {
      notify((e as Error).message, 'error');
    } finally {
      setBusy('');
    }
  }
  return (
    <>
      <PageHeader
        eyebrow="COORDINATED THREAT DETECTION"
        title="Fraud rarely acts alone"
        description="Surface communities that share suspicious timing, fund movement and risk."
      >
        <Button variant="primary" onClick={runAttack} loading={attackBusy}>
          <Zap size={15} />
          Demo attack
        </Button>
      </PageHeader>
      <div className="rings-summary">
        <div>
          <span className="rings-summary-icon">
            <ScanFace size={27} />
          </span>
          <div>
            <strong>{data?.total || 0} emerging networks</strong>
            <p>Potential rings detected from the active one-hour graph</p>
          </div>
        </div>
        <div>
          <span>CONNECTED ACCOUNTS</span>
          <strong>{new Set(data?.items.flatMap((r) => r.members)).size}</strong>
        </div>
        <div>
          <span>INTERNAL VOLUME</span>
          <strong>
            {money(
              (data?.items || []).reduce((s, r) => s + r.volume, 0),
              true,
            )}
          </strong>
        </div>
      </div>
      <div className="list-toolbar">
        <div className="inline-search">
          <Search size={15} />
          <input
            placeholder="Search ring ID or pattern…"
            aria-label="Search fraud rings"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <label>
          Sort by{' '}
          <select value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="risk">Highest risk</option>
            <option value="volume">Transaction volume</option>
            <option value="members">Member count</option>
          </select>
        </label>
      </div>
      {isLoading ? (
        <Loading label="Finding connected threat communities…" />
      ) : error ? (
        <ErrorState error={error} retry={refetch} />
      ) : !rings.length ? (
        <Panel>
          <Empty
            title="No suspicious communities in this view"
            description="Broaden your search or inject a synthetic attack to exercise network detection."
          >
            <Button onClick={runAttack} loading={attackBusy}>
              Run demo attack
            </Button>
          </Empty>
        </Panel>
      ) : (
        <div className="rings-grid">
          {rings.map((r, i) => (
            <Panel className="ring-card" key={r.id}>
              <div className="ring-card-header">
                <span className="mono">{r.id}</span>
                <Badge level={riskLevel(r.risk_score)} small />
              </div>
              <RingMiniGraph ring={r} network={network} />
              <div className="ring-card-body">
                <h2>{r.title}</h2>
                <div className="ring-metrics">
                  <div>
                    <span>Members</span>
                    <strong>{r.member_count}</strong>
                  </div>
                  <div>
                    <span>Avg. risk</span>
                    <strong>
                      {r.average_risk}
                      <small>/100</small>
                    </strong>
                  </div>
                  <div>
                    <span>Volume</span>
                    <strong>{money(r.volume, true)}</strong>
                  </div>
                </div>
                <div className="pattern-tags">
                  {r.patterns.slice(0, 4).map((p) => (
                    <span key={p}>{p}</span>
                  ))}
                </div>
                <details className="ring-reasons" open={i === 0}>
                  <summary>
                    Why this network was flagged
                    <ChevronDown size={14} />
                  </summary>
                  {r.reasons.map((reason) => (
                    <p key={reason}>
                      <Check size={12} />
                      {reason}
                    </p>
                  ))}
                </details>
                <div className="ring-card-actions">
                  <Button onClick={() => nav(`/network?ring=${r.id}`)}>
                    <Network size={14} />
                    Investigate network
                  </Button>
                  <Button
                    variant="ghost"
                    loading={busy === r.id}
                    onClick={() => investigate(r)}
                    title="Open investigation case"
                  >
                    <FolderPlus size={16} />
                  </Button>
                </div>
              </div>
            </Panel>
          ))}
        </div>
      )}
      <div className="method-note">
        <ScanFace size={19} />
        <div>
          <h3>How a network becomes a signal</h3>
          <p>
            A cluster must have at least three related accounts, meaningful internal volume, and
            multiple graph or behavioral signals. Density, rapid pass-through, circularity and
            independently high-risk members combine into a cluster score. These are potential
            networks for review, not confirmed criminal associations.
          </p>
        </div>
      </div>
    </>
  );
}
