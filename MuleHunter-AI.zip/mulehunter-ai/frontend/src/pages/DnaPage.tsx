import { useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import {
  Fingerprint,
  RefreshCw,
  FilePlus2,
  Activity,
  Timer,
  ArrowDownToLine,
  ArrowUpFromLine,
  Users,
  Network,
  ScanLine,
  BrainCircuit,
  Info,
  ArrowUpRight,
} from 'lucide-react';
import { api, post, money, count } from '../lib/api';
import type { Account, Case } from '../lib/types';
import { useLive } from '../lib/live';
import {
  PageHeader,
  Panel,
  PanelHeader,
  Button,
  AccountPicker,
  Loading,
  ErrorState,
  Score,
  Badge,
  Empty,
} from '../components/ui';
import { DnaChart } from '../components/charts';
import { ScoreBreakdown, EvidenceList } from '../components/AccountDrawer';
export function DnaPage() {
  const [params, setParams] = useSearchParams();
  const nav = useNavigate();
  const { notify } = useLive();
  const [busy, setBusy] = useState(false);
  const { data: accounts } = useQuery({
    queryKey: ['accounts', 'top'],
    queryFn: () => api<{ items: Account[] }>('/accounts?limit=20'),
  });
  const id = params.get('account') || accounts?.items[0]?.id || '';
  const {
    data: a,
    isLoading,
    error,
    refetch,
  } = useQuery({
    queryKey: ['account', id],
    queryFn: () => api<Account>(`/accounts/${id}`),
    enabled: !!id,
  });
  async function refresh() {
    setBusy(true);
    try {
      await post('/analyze/account', { account_id: id });
      await refetch();
      notify('Behavioral profile refreshed');
    } catch (e) {
      notify((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  }
  async function create() {
    setBusy(true);
    try {
      const c = await post<Case>('/cases', {
        account_ids: [id],
        title: `Behavioral investigation · ${id}`,
      });
      nav(`/investigations/${c.id}`);
      notify('Investigation created');
    } catch (e) {
      notify((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageHeader
        eyebrow="BEHAVIORAL INTELLIGENCE"
        title="Every account has a signature"
        description="Understand what changed, why it matters, and where to look next."
      >
        <Button onClick={refresh} loading={busy} disabled={!a}>
          <RefreshCw size={14} />
          Re-analyze
        </Button>
        <Button variant="primary" onClick={create} disabled={!a} loading={busy}>
          <FilePlus2 size={15} />
          Create investigation
        </Button>
      </PageHeader>
      <div className="account-context-bar">
        <AccountPicker value={id} onChange={(account) => setParams({ account })} />
        {a && (
          <>
            <span>{a.label}</span>
            <Badge level={a.risk_level} />
            <button onClick={() => nav(`/network?account=${id}`)}>
              Locate in network
              <ArrowUpRight size={14} />
            </button>
          </>
        )}
      </div>
      {isLoading || !id ? (
        <Loading label="Decoding the account’s behavioral signature…" />
      ) : error ? (
        <ErrorState error={error} retry={refetch} />
      ) : a ? (
        <>
          <div className="dna-top-grid">
            <Panel className="dna-radar-panel">
              <PanelHeader
                title="Fraud DNA profile"
                subtitle="Current behavior vs. synthetic reference"
                icon={<Fingerprint size={19} />}
              >
                <Score value={a.risk_score} />
              </PanelHeader>
              <DnaChart account={a} height={305} />
              <div className="chart-legend centered">
                <span>
                  <i className="green-dot" />
                  Current account behavior
                </span>
                <span>
                  <i className="gray-dot" />
                  Reference baseline
                </span>
              </div>
              <p className="micro-note padded">
                Radar axes are normalized heuristics; the reference shape is illustrative, not an
                observed real-world customer cohort.
              </p>
            </Panel>
            <Panel className="dna-score-panel">
              <PanelHeader
                title="Five layers. One explainable score."
                subtitle="Each signal contributes a bounded, weighted amount."
              />
              <div className="dna-composite">
                <div>
                  <span className="eyebrow">COMPOSITE RISK</span>
                  <Score value={a.risk_score} large />
                </div>
                <Badge level={a.risk_level} />
              </div>
              <ScoreBreakdown account={a} />
            </Panel>
          </div>
          <div className="dna-metric-grid">
            {[
              {
                label: 'Transaction velocity',
                value: `${a.metrics.transaction_velocity}`,
                unit: 'txn / minute',
                icon: Activity,
                note: `${a.metrics.recent_count} in the last 20 minutes`,
              },
              {
                label: 'Average / maximum value',
                value: money(a.metrics.average_transaction_value, true),
                unit: 'avg',
                icon: ArrowUpFromLine,
                note: `${money(a.metrics.maximum_transaction_value, true)} maximum transfer`,
              },
              {
                label: 'Fan-in / fan-out ratio',
                value: `${a.metrics.fan_in_ratio}× / ${a.metrics.fan_out_ratio}×`,
                unit: '',
                icon: ArrowDownToLine,
                note: 'Recent incoming / outgoing unique peers',
              },
              {
                label: 'Unique counterparties',
                value: count(a.metrics.unique_counterparties),
                unit: 'accounts',
                icon: Users,
                note: `${a.metrics.suspicious_connections} high-risk connections`,
              },
              {
                label: 'Average interval',
                value: a.metrics.average_transaction_interval.toFixed(0),
                unit: 'seconds',
                icon: Timer,
                note: 'Recent active transaction spacing',
              },
              {
                label: 'Circular transaction signal',
                value: a.metrics.in_cycle ? 'Detected' : 'Not detected',
                unit: '',
                icon: ScanLine,
                note: `Heuristic propensity ${a.metrics.circular_transaction_probability}/100; not a calibrated probability`,
              },
              {
                label: 'Network centrality',
                value: a.metrics.network_centrality.toFixed(4),
                unit: '',
                icon: Network,
                note: 'Approximate betweenness centrality',
              },
              {
                label: 'Network risk exposure',
                value: a.metrics.risk_exposure.toFixed(0),
                unit: '/ 100',
                icon: ShieldIcon,
                note: 'Distance, value, frequency & recency',
              },
            ].map((m) => (
              <Panel className="dna-metric" key={m.label}>
                <span>
                  <m.icon size={15} />
                  {m.label}
                </span>
                <strong>
                  {m.value}
                  <small>{m.unit}</small>
                </strong>
                <p>{m.note}</p>
              </Panel>
            ))}
          </div>
          <div className="dna-bottom-grid">
            <Panel>
              <PanelHeader
                title="The evidence behind the signal"
                subtitle="Deterministic explanations derived from measured behavior."
                icon={<BrainCircuit size={18} />}
              >
                <span className="subtle-tag">EXPLAINABLE AI</span>
              </PanelHeader>
              <div className="padded">
                <EvidenceList account={a} />
              </div>
            </Panel>
            <Panel>
              <PanelHeader
                title="Model intelligence"
                subtitle="An experimental second opinion, not a verdict."
              />
              <div className="model-card-content">
                <div className="model-stat">
                  <span>Isolation Forest anomaly score</span>
                  <strong>
                    {a.ml.anomaly_score}
                    <small>/100</small>
                  </strong>
                  <i>
                    <b style={{ width: `${a.ml.anomaly_score}%` }} />
                  </i>
                </div>
                <div className="model-stat">
                  <span>Normality score</span>
                  <strong>
                    {a.ml.normality_score}
                    <small>/100</small>
                  </strong>
                </div>
                <div className="model-stat">
                  <span>Random Forest synthetic estimate</span>
                  <strong>
                    {(a.ml.fraud_probability * 100).toFixed(1)}
                    <small>%</small>
                  </strong>
                </div>
                <div className="notice">
                  <Info size={16} />
                  <p>{a.ml.model_note} No real-world model accuracy is claimed.</p>
                </div>
                <div className="recommended-action">
                  <div className="eyebrow">HUMAN REVIEW RECOMMENDATION</div>
                  <h4>{a.explanation.recommended_action}</h4>
                  <p>No enforcement or account blocking is performed.</p>
                </div>
              </div>
            </Panel>
          </div>
        </>
      ) : (
        <Empty title="No account profile available" />
      )}
    </>
  );
}
function ShieldIcon(props: { size: number }) {
  return <ScanLine {...props} />;
}
