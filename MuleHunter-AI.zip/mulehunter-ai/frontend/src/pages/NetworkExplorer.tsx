import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useSearchParams, useNavigate } from 'react-router-dom';
import {
  Search,
  Network,
  Filter,
  Download,
  ScanLine,
  Layers,
  GitBranch,
  X,
  ArrowUpRight,
} from 'lucide-react';
import { api, count, saveJson, money } from '../lib/api';
import type { GraphData, Ring } from '../lib/types';
import { useLive } from '../lib/live';
import {
  PageHeader,
  Panel,
  Button,
  Loading,
  ErrorState,
  Badge,
  Empty,
  LivePill,
} from '../components/ui';
import { NetworkGraph } from '../components/NetworkGraph';
export function NetworkExplorer() {
  const [params, setParams] = useSearchParams();
  const focus = params.get('account') || '';
  const ringId = params.get('ring');
  const [risk, setRisk] = useState('ALL');
  const [hours, setHours] = useState(24);
  const [limit, setLimit] = useState(120);
  const [query, setQuery] = useState(focus);
  const { selectAccount, notify, dashboard } = useLive();
  const nav = useNavigate();
  const { data: rings } = useQuery({
    queryKey: ['rings'],
    queryFn: () => api<{ items: Ring[] }>('/fraud-rings'),
  });
  const selectedRing = rings?.items.find((r) => r.id === ringId);
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['network', 'explorer', limit, risk, hours, focus],
    queryFn: () =>
      api<GraphData>(
        `/network?limit=${limit}&level=${encodeURIComponent(risk)}&hours=${hours}${focus ? `&focus=${encodeURIComponent(focus)}` : ''}`,
      ),
  });
  function search(e: React.FormEvent) {
    e.preventDefault();
    if (query.trim()) {
      setParams({ account: query.trim().toUpperCase() });
    } else setParams({});
  }
  return (
    <>
      <PageHeader
        eyebrow="GRAPH INTELLIGENCE"
        title="Follow the connections"
        description="Investigate the network, not just the transaction."
      >
        <Button
          onClick={() => data && saveJson(data, 'mulehunter-network-snapshot.json')}
          disabled={!data}
        >
          <Download size={14} />
          Export graph
        </Button>
        <Button variant="primary" onClick={() => nav('/money-flow')}>
          <GitBranch size={15} />
          Trace money flow
        </Button>
      </PageHeader>
      <div className="explorer-metrics">
        <div>
          <Network size={16} />
          <strong>{count(dashboard?.total_accounts || 0)}</strong>
          <span>Total accounts</span>
        </div>
        <div>
          <Layers size={16} />
          <strong>{data?.communities ?? '—'}</strong>
          <span>Detected communities</span>
        </div>
        <div>
          <ScanLine size={16} />
          <strong>{data?.ring_count ?? '—'}</strong>
          <span>Suspicious networks</span>
        </div>
        <div>
          <GitBranch size={16} />
          <strong>{data?.cycle_count ?? '—'}</strong>
          <span>Short directed cycles*</span>
        </div>
      </div>
      <Panel className="explorer-panel">
        <div className="explorer-toolbar">
          <form className="inline-search" onSubmit={search}>
            <Search size={16} />
            <input
              aria-label="Search account in network"
              placeholder="Search account ID…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            {query && (
              <button
                type="button"
                aria-label="Clear account search"
                onClick={() => {
                  setQuery('');
                  setParams({});
                }}
              >
                <X size={13} />
              </button>
            )}
            <button type="submit">Locate</button>
          </form>
          <div className="explorer-filters">
            <Filter size={14} />
            <select
              aria-label="Filter network risk"
              value={risk}
              onChange={(e) => setRisk(e.target.value)}
            >
              <option value="ALL">All risk levels</option>
              {['SAFE', 'SUSPICIOUS', 'HIGH RISK', 'CRITICAL'].map((l) => (
                <option key={l}>{l}</option>
              ))}
            </select>
            <select
              aria-label="Filter transaction time"
              value={hours}
              onChange={(e) => setHours(Number(e.target.value))}
            >
              <option value={1}>Last hour</option>
              <option value={6}>Last 6 hours</option>
              <option value={24}>Last 24 hours</option>
            </select>
            <select
              aria-label="Network node limit"
              value={limit}
              onChange={(e) => setLimit(Number(e.target.value))}
            >
              <option value={120}>120-node view</option>
              <option value={500}>500-node view</option>
              <option value={2000}>Entire network</option>
            </select>
            <LivePill />
          </div>
        </div>
        {selectedRing && (
          <div className="selected-network-banner">
            <ScanLine size={16} />
            <strong>{selectedRing.title}</strong>
            <span>
              {selectedRing.member_count} members · {money(selectedRing.volume, true)}
            </span>
            <Badge level={selectedRing.risk_score > 80 ? 'CRITICAL' : 'HIGH RISK'} small />
            <button onClick={() => setParams({})}>
              Clear selection
              <X size={12} />
            </button>
          </div>
        )}
        {focus && (
          <div className="selected-network-banner">
            <Search size={14} />
            <strong>Account focus: {focus}</strong>
            <span>Account and directly connected counterparties</span>
          </div>
        )}
        {isLoading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} retry={refetch} />
        ) : data?.nodes.length ? (
          <NetworkGraph
            data={data}
            onSelect={selectAccount}
            large
            highlight={selectedRing?.members}
            focusId={focus || undefined}
          />
        ) : (
          <Empty
            title="No accounts match these filters"
            description="Try a different risk level or clear the account focus."
          />
        )}
        <div className="network-footer">
          <span>
            <strong>{data?.nodes.length ?? 0}</strong> displayed accounts ·{' '}
            <strong>{data?.visible_edges ?? 0}</strong> aggregated edges
          </span>
          <span>Zoom · Pan · Select nodes & edges</span>
        </div>
      </Panel>
      <div className="explorer-info-grid">
        <div>
          <h3>
            <Layers size={15} />
            Community-aware intelligence
          </h3>
          <p>
            NetworkX Louvain communities organize related payment behavior. Highlighted networks
            meet a combination of density, timing, cycle and independent account-risk thresholds.
          </p>
        </div>
        <div>
          <h3>
            <ScanLine size={15} />A signal, not a verdict
          </h3>
          <p>
            Node size reflects network influence; color reflects risk. Each edge aggregates a
            directed account pair. *Cycle enumeration is bounded at 150 cycles of up to four
            accounts; displayed edges are capped at 1,500.
          </p>
        </div>
      </div>
      {!!rings?.items.length && (
        <div className="network-cluster-strip">
          <span className="section-eyebrow">INVESTIGATE A CLUSTER</span>
          {rings.items.map((r) => (
            <button
              key={r.id}
              className={r.id === ringId ? 'active' : ''}
              onClick={() => setParams({ ring: r.id })}
            >
              <i />
              {r.id}
              <span>{r.member_count} accounts</span>
              <ArrowUpRight size={12} />
            </button>
          ))}
        </div>
      )}
    </>
  );
}
