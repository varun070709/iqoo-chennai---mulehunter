import { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useParams, useNavigate } from 'react-router-dom';
import {
  FolderSearch,
  FilePlus2,
  Download,
  ArrowUpRight,
  ArrowLeft,
  Search,
  FileText,
  Users,
  IndianRupee,
  Activity,
  Check,
  Save,
  ShieldAlert,
  Clock3,
  MessageSquare,
  Info,
  X,
  ChevronRight,
  Network,
} from 'lucide-react';
import { api, post, download, saveJson, count, money, date, time } from '../lib/api';
import type { Case, Investigation, Account } from '../lib/types';
import { useLive } from '../lib/live';
import {
  PageHeader,
  Panel,
  PanelHeader,
  Button,
  Badge,
  Score,
  Loading,
  ErrorState,
  Empty,
  Modal,
  AccountPicker,
} from '../components/ui';
import { NetworkGraph } from '../components/NetworkGraph';
import { TransactionTable } from '../components/Transactions';
function Status({ status }: { status: string }) {
  return (
    <span className={`case-status ${status}`}>
      <i />
      {status.replace('_', ' ')}
    </span>
  );
}
function CreateCaseModal({ onClose }: { onClose: () => void }) {
  const [title, setTitle] = useState('Suspected mule account network');
  const [ids, setIds] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const { notify } = useLive();
  const nav = useNavigate();
  const client = useQueryClient();
  async function create(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const c = await post<Case>('/cases', { title, account_ids: ids });
      client.invalidateQueries({ queryKey: ['cases'] });
      onClose();
      nav(`/investigations/${c.id}`);
      notify('Investigation case created');
    } catch (e) {
      notify((e as Error).message, 'error');
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal title="Open an investigation" onClose={onClose}>
      <form onSubmit={create} className="modal-body new-case-form">
        <label>
          Case title
          <input
            required
            minLength={3}
            maxLength={160}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </label>
        <label>Accounts in scope</label>
        <AccountPicker
          value=""
          onChange={(id) => {
            if (id && !ids.includes(id)) setIds((s) => [...s, id]);
          }}
          label="Add an account to this case"
        />
        <div className="selected-account-chips">
          {ids.map((id) => (
            <span key={id}>
              {id}
              <button
                type="button"
                onClick={() => setIds((s) => s.filter((n) => n !== id))}
                aria-label={`Remove ${id}`}
              >
                <X size={12} />
              </button>
            </span>
          ))}
        </div>
        <p className="micro-note">
          The highest-risk account’s structured evidence is captured when this case is created. No
          financial action is taken.
        </p>
        <div className="modal-actions">
          <Button type="button" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" variant="primary" disabled={!ids.length} loading={busy}>
            <FilePlus2 size={15} />
            Create case
          </Button>
        </div>
      </form>
    </Modal>
  );
}
export function Investigations() {
  const { caseId } = useParams();
  const nav = useNavigate();
  const { notify, selectAccount } = useLive();
  const client = useQueryClient();
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('all');
  const [create, setCreate] = useState(false);
  const [tab, setTab] = useState('Overview');
  const [notes, setNotes] = useState('');
  const [action, setAction] = useState('Monitor');
  const [busy, setBusy] = useState('');
  const {
    data: cases,
    isLoading: casesLoading,
    error: casesError,
    refetch: refetchCases,
  } = useQuery({ queryKey: ['cases'], queryFn: () => api<{ items: Case[] }>('/cases') });
  const {
    data: c,
    isLoading,
    error,
    refetch,
  } = useQuery({
    queryKey: ['investigation', caseId],
    queryFn: () => api<Investigation>(`/investigation/${caseId}`),
    enabled: !!caseId,
  });
  useEffect(() => {
    if (c) {
      setNotes(c.notes);
      setAction(c.recommended_action);
      setTab('Overview');
    }
  }, [c?.id]);
  async function update(fields: Record<string, string>, name: string) {
    if (!caseId) return;
    setBusy(name);
    try {
      await api(`/cases/${caseId}`, { method: 'PATCH', body: JSON.stringify(fields) });
      await refetch();
      client.invalidateQueries({ queryKey: ['cases'] });
      notify(
        name === 'notes'
          ? 'Analyst notes saved'
          : name === 'action'
            ? 'Review recommendation recorded'
            : 'Case status updated',
      );
    } catch (e) {
      notify((e as Error).message, 'error');
    } finally {
      setBusy('');
    }
  }
  async function report() {
    setBusy('report');
    try {
      await download(`/investigation/${caseId}/report`, `${caseId}-MuleHunter.pdf`);
      notify('Investigation report downloaded');
    } catch (e) {
      notify((e as Error).message, 'error');
    } finally {
      setBusy('');
    }
  }
  if (!caseId) {
    const rows = (cases?.items || []).filter(
      (c) =>
        (status === 'all' || c.status === status) &&
        (c.id + ' ' + c.title).toLowerCase().includes(query.toLowerCase()),
    );
    return (
      <>
        <PageHeader
          eyebrow="INVESTIGATOR WORKSPACE"
          title="Turn signals into evidence"
          description="A traceable record of what was observed, why it matters, and what comes next."
        >
          <Button
            onClick={() => saveJson(cases?.items || [], 'mulehunter-case-register.json')}
            disabled={!cases?.items.length}
          >
            <Download size={14} />
            Export register
          </Button>
          <Button variant="primary" onClick={() => setCreate(true)}>
            <FilePlus2 size={15} />
            New investigation
          </Button>
        </PageHeader>
        <div className="case-summary-grid">
          {[
            { label: 'Total investigations', value: cases?.items.length || 0, icon: FolderSearch },
            {
              label: 'Awaiting review',
              value: cases?.items.filter((c) => c.status === 'open').length || 0,
              icon: Clock3,
            },
            {
              label: 'Escalated',
              value: cases?.items.filter((c) => c.status === 'escalated').length || 0,
              icon: ShieldAlert,
            },
            {
              label: 'Closed cases',
              value: cases?.items.filter((c) => c.status === 'closed').length || 0,
              icon: Check,
            },
          ].map((s) => (
            <Panel key={s.label}>
              <s.icon size={18} />
              <div>
                <span>{s.label}</span>
                <strong>{s.value}</strong>
              </div>
            </Panel>
          ))}
        </div>
        <Panel>
          <PanelHeader
            title="Case register"
            subtitle="Automatically surfaced networks and analyst-created investigations."
          />
          <div className="explorer-toolbar">
            <div className="inline-search">
              <Search size={15} />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search case ID or title…"
                aria-label="Search investigations"
              />
            </div>
            <select
              aria-label="Filter case status"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            >
              <option value="all">All statuses</option>
              <option value="open">Open</option>
              <option value="in_review">In review</option>
              <option value="escalated">Escalated</option>
              <option value="closed">Closed</option>
            </select>
          </div>
          {casesLoading ? (
            <Loading />
          ) : casesError ? (
            <ErrorState error={casesError} retry={refetchCases} />
          ) : !rows.length ? (
            <Empty
              title="No investigations in this view"
              description="Create a case from an account or detected network, or change your filters."
            >
              <Button onClick={() => setCreate(true)}>New investigation</Button>
            </Empty>
          ) : (
            <div className="table-scroll">
              <table className="cases-table">
                <thead>
                  <tr>
                    <th>CASE / INVESTIGATION</th>
                    <th>ACCOUNTS</th>
                    <th>PEAK RISK AT CREATION</th>
                    <th>STATUS</th>
                    <th>CREATED</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {rows.map((c) => (
                    <tr key={c.id} onClick={() => nav(`/investigations/${c.id}`)}>
                      <td>
                        <button
                          className="case-title-link"
                          onClick={() => nav(`/investigations/${c.id}`)}
                        >
                          <span className="case-file-icon">
                            <FolderSearch size={19} />
                          </span>
                          <span>
                            <strong>{c.title}</strong>
                            <small>{c.id}</small>
                          </span>
                        </button>
                      </td>
                      <td>
                        <Users size={13} />
                        {c.account_ids.length}
                      </td>
                      <td>
                        <Score value={c.risk_score} />
                      </td>
                      <td>
                        <Status status={c.status} />
                      </td>
                      <td>{date(c.created_at)}</td>
                      <td>
                        <button className="table-arrow" aria-label={`Open ${c.id}`}>
                          <ArrowUpRight size={15} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <div className="network-footer">
            <span>{rows.length} investigations in this view</span>
            <span>Local, persistent case records</span>
          </div>
        </Panel>
        <div className="method-note">
          <Info size={20} />
          <div>
            <h3>Decision support, with the investigator in control</h3>
            <p>
              Case evidence is captured at creation; the account graph continues to reflect current
              analysis. Statuses and recommended actions are local case records only. The platform
              never blocks accounts, contacts banks or files reports automatically.
            </p>
          </div>
        </div>
        {create && <CreateCaseModal onClose={() => setCreate(false)} />}
      </>
    );
  }
  return (
    <>
      <button className="back-link" onClick={() => nav('/investigations')}>
        <ArrowLeft size={14} />
        Back to investigations
      </button>
      {isLoading ? (
        <Loading label="Opening the investigation file…" />
      ) : error ? (
        <ErrorState error={error} retry={refetch} />
      ) : c ? (
        <>
          <PageHeader
            eyebrow={`${c.id} / INVESTIGATION FILE`}
            title={c.title}
            description={`Opened ${date(c.created_at)} · ${c.account_ids.length} fictional accounts in scope`}
          >
            <Button
              onClick={() => update({ status: 'escalated' }, 'status')}
              disabled={c.status === 'escalated'}
              loading={busy === 'status'}
            >
              <ShieldAlert size={14} />
              {c.status === 'escalated' ? 'Escalated for review' : 'Escalate case'}
            </Button>
            <Button variant="primary" onClick={report} loading={busy === 'report'}>
              <Download size={15} />
              Download report
            </Button>
          </PageHeader>
          <div className="case-overview-stats">
            <div>
              <span className="eyebrow">PEAK RISK AT CREATION</span>
              <Score value={c.risk_score} large />
              <Badge level={c.risk_level} />
            </div>
            <div>
              <span>ACCOUNTS IN SCOPE</span>
              <strong>{c.account_ids.length}</strong>
            </div>
            <div>
              <span>CONNECTED VOLUME</span>
              <strong>{money(c.volume, true)}</strong>
            </div>
            <div>
              <span>TRANSACTIONS</span>
              <strong>{count(c.transaction_count)}</strong>
            </div>
            <div>
              <span>CASE STATUS</span>
              <Status status={c.status} />
            </div>
          </div>
          <div className="case-detail-grid">
            <div className="case-main">
              <Panel>
                <div className="case-tabs">
                  {['Overview', 'AI evidence', 'Transaction timeline'].map((t) => (
                    <button className={tab === t ? 'active' : ''} key={t} onClick={() => setTab(t)}>
                      {t}
                    </button>
                  ))}
                </div>
                {tab === 'Overview' ? (
                  <>
                    <PanelHeader
                      title="Investigation network"
                      subtitle="Current topology for all accounts in case scope."
                      icon={<Network size={16} />}
                    >
                      <span className="subtle-tag">{c.network.nodes.length} ACCOUNTS</span>
                    </PanelHeader>
                    <NetworkGraph data={c.network} onSelect={selectAccount} />
                    <div className="case-patterns">
                      <span className="section-eyebrow">OBSERVED PATTERNS</span>
                      <div className="pattern-tags">
                        {c.patterns.length ? (
                          c.patterns.map((p) => <span key={p}>{p}</span>)
                        ) : (
                          <span>No active network motifs</span>
                        )}
                      </div>
                    </div>
                  </>
                ) : tab === 'AI evidence' ? (
                  <div className="case-evidence padded">
                    <div className="intelligence-label">
                      <ShieldCheckIcon />
                      Structured evidence at case creation
                    </div>
                    <p className="micro-note">
                      Captured {date(c.created_at)} at {time(c.created_at)} IST. Current account
                      scores may evolve as new payments arrive.
                    </p>
                    <div className="evidence-list">
                      {c.evidence.map((e, i) => (
                        <div className="evidence-item" key={e.title}>
                          <span className="evidence-number">{String(i + 1).padStart(2, '0')}</span>
                          <div>
                            <h4>{e.title}</h4>
                            <p>{e.detail}</p>
                            <span className="evidence-tag">{e.signal} intelligence layer</span>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="notice">
                      <Info size={16} />
                      <p>
                        Potential exposure is gross connected volume, not verified loss. The same
                        funds may appear at multiple hops. Synthetic models and deterministic rules
                        provide signals, not proof of wrongdoing.
                      </p>
                    </div>
                  </div>
                ) : (
                  <>
                    <PanelHeader
                      title="Payment trail"
                      subtitle={`Latest ${c.timeline.length} of ${c.transaction_count} in-scope transfers, in event-time order.`}
                    />
                    <TransactionTable transactions={c.timeline.slice().reverse()} compact />
                  </>
                )}
              </Panel>
              <Panel className="case-accounts">
                <PanelHeader
                  title="Accounts in scope"
                  subtitle="Live account analysis, separate from the case-creation snapshot."
                />
                <div className="table-scroll">
                  <table className="simple-table">
                    <thead>
                      <tr>
                        <th>ACCOUNT</th>
                        <th>CURRENT RISK</th>
                        <th>TRANSFERS</th>
                        <th>PRIMARY SIGNAL</th>
                        <th />
                      </tr>
                    </thead>
                    <tbody>
                      {c.accounts
                        .sort((a, b) => b.risk_score - a.risk_score)
                        .map((a) => (
                          <tr key={a.id}>
                            <td>
                              <button className="account-link" onClick={() => selectAccount(a.id)}>
                                {a.id}
                              </button>
                            </td>
                            <td>
                              <Score value={a.risk_score} />
                            </td>
                            <td>{a.metrics.transaction_count}</td>
                            <td className="muted">{a.explanation.primary_reason}</td>
                            <td>
                              <button
                                className="table-arrow"
                                onClick={() => selectAccount(a.id)}
                                aria-label={`Review ${a.id}`}
                              >
                                <ChevronRight size={14} />
                              </button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </Panel>
            </div>
            <aside className="case-sidebar">
              <Panel>
                <PanelHeader title="Investigator controls" />
                <div className="case-controls">
                  <label>
                    Case status
                    <select
                      value={c.status}
                      disabled={!!busy}
                      onChange={(e) => update({ status: e.target.value }, 'status')}
                    >
                      <option value="open">Open</option>
                      <option value="in_review">In review</option>
                      <option value="escalated">Escalated</option>
                      <option value="closed">Closed</option>
                    </select>
                  </label>
                  <label>
                    Recommended action
                    <select value={action} onChange={(e) => setAction(e.target.value)}>
                      {[
                        'Monitor',
                        'Request Additional Verification',
                        'Temporarily Flag',
                        'Escalate for Investigation',
                      ].map((a) => (
                        <option key={a}>{a}</option>
                      ))}
                    </select>
                  </label>
                  <Button
                    onClick={() => update({ recommended_action: action }, 'action')}
                    loading={busy === 'action'}
                  >
                    <Check size={14} />
                    Record recommendation
                  </Button>
                  <div className="notice">
                    <Info size={15} />
                    <p>
                      Recording a recommendation does not perform the action or notify any external
                      institution.
                    </p>
                  </div>
                </div>
              </Panel>
              <Panel className="analyst-notes-panel">
                <PanelHeader title="Analyst notes" icon={<MessageSquare size={16} />}>
                  <span className="subtle-tag">PRIVATE TO DEMO</span>
                </PanelHeader>
                <div className="analyst-notes">
                  <textarea
                    aria-label="Investigator notes"
                    placeholder="Record findings, questions and follow-up actions…"
                    maxLength={8000}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                  />
                  <div>
                    <span>{notes.length} / 8,000</span>
                    <Button
                      onClick={() => update({ notes }, 'notes')}
                      loading={busy === 'notes'}
                      disabled={notes === c.notes}
                    >
                      <Save size={14} />
                      Save notes
                    </Button>
                  </div>
                </div>
              </Panel>
              <div className="case-file-note">
                <FileText size={22} />
                <h3>Evidence you can take with you.</h3>
                <p>
                  The downloadable PDF includes case metadata, captured evidence, current account
                  scores, analyst notes and methodology limitations.
                </p>
                <button className="section-link" onClick={report}>
                  Generate PDF report
                  <ArrowUpRight size={13} />
                </button>
              </div>
            </aside>
          </div>
        </>
      ) : null}
    </>
  );
}
function ShieldCheckIcon() {
  return <Check size={17} />;
}
