import { test, expect } from '@playwright/test';

test.describe.configure({ mode: 'serial' });
let accountId = '';
let secondAccountId = '';
let caseId = '';

test.beforeAll(async ({ request }) => {
  await request.post('/api/simulate', { data: { action: 'stop' } });
  const response = await request.post('/api/simulate', { data: { action: 'reset' } });
  expect(response.ok()).toBeTruthy();
  const accounts = await (await request.get('/api/accounts?limit=2')).json();
  accountId = accounts.items[0].id;
  secondAccountId = accounts.items[1].id;
});

test('command center renders real metrics, connected graph and live transport', async ({
  page,
}) => {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Fraud command center.' })).toBeVisible();
  await expect(page.locator('.metric-value').first()).toHaveText('5,000');
  await expect(page.locator('.react-flow__node-account').first()).toBeVisible();
  expect(await page.locator('.react-flow__node-account').count()).toBe(90);
  await expect(page.getByText('Live connection', { exact: true })).toBeVisible();
  expect(errors).toEqual([]);
});

test('risk filter, node selection, Fraud DNA and structured evidence all work', async ({
  page,
}) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Critical', exact: true }).click();
  await expect(page.locator('.react-flow__node-account').first()).toBeVisible();
  await page.locator('.react-flow__node-account').first().click();
  const drawer = page.getByRole('dialog');
  await expect(drawer).toBeVisible();
  await expect(drawer.locator('.account-summary h2')).toHaveText(/ACC-/);
  await drawer.getByRole('button', { name: 'Fraud DNA', exact: true }).click();
  await expect(drawer.locator('.recharts-radar').first()).toBeVisible();
  await drawer.getByRole('button', { name: 'AI evidence', exact: true }).click();
  await expect(drawer.getByText('Explainable, not a black box')).toBeVisible();
  await expect(drawer.locator('.evidence-item').first()).toBeVisible();
  await page.getByRole('button', { name: 'Close account details' }).click();
  await expect(drawer).not.toBeVisible();
});

test('global account search and network focus work without hard-coded account data', async ({
  page,
}) => {
  await page.goto('/');
  await page.getByRole('button', { name: /Search intelligence/ }).click();
  await page.locator('.search-modal-input input').fill(accountId);
  await page
    .getByRole('button')
    .filter({ has: page.locator('strong', { hasText: accountId }) })
    .last()
    .click();
  await expect(page.locator('.account-drawer .account-summary h2')).toHaveText(accountId);
  await page.getByRole('button', { name: 'Close account details' }).click();
  await page.goto('/network');
  await page.getByRole('textbox', { name: 'Search account in network' }).fill(accountId);
  await page.getByRole('button', { name: 'Locate', exact: true }).click();
  await expect(page).toHaveURL(new RegExp('account=' + accountId));
  await expect(page.getByText(`Account focus: ${accountId}`)).toBeVisible();
  await expect(page.locator('.react-flow__node-account').first()).toBeVisible();
  await page.getByRole('button', { name: 'Zoom in', exact: true }).click();
  await page.getByRole('button', { name: 'Fit network to view' }).click();
});

test('money flow replays stored time-ordered transfers', async ({ page }) => {
  await page.goto(`/money-flow?account=${accountId}`);
  await expect(page.locator('.flow-account').first()).toBeVisible();
  const initial = await page.locator('.flow-account.active').count();
  await page.getByRole('button', { name: 'Replay money flow', exact: true }).click();
  await expect
    .poll(async () => page.locator('.flow-account.active').count())
    .toBeGreaterThan(initial);
  await page.getByRole('button', { name: 'Pause replay', exact: true }).click();
  await page.getByRole('button', { name: 'Reset replay' }).click();
  await expect(page.getByRole('slider', { name: 'Money flow timeline' })).toHaveValue('0');
});

test('case creation, notes persistence, escalation and PDF report download', async ({
  page,
  request,
}) => {
  await page.goto('/investigations');
  await page.getByRole('button', { name: 'New investigation', exact: true }).click();
  const dialog = page.getByRole('dialog');
  await dialog.getByLabel('Case title').fill('End-to-end synthetic investigation');
  await dialog
    .getByRole('combobox', { name: 'Add an account to this case' })
    .selectOption(accountId);
  await dialog
    .getByRole('combobox', { name: 'Add an account to this case' })
    .selectOption(secondAccountId);
  await dialog.getByRole('button', { name: 'Create case', exact: true }).click();
  await expect(page).toHaveURL(/investigations\/CASE-/);
  caseId = page.url().split('/').at(-1)!;
  await page
    .getByRole('textbox', { name: 'Investigator notes' })
    .fill('Verified synthetic evidence. Follow up on the rapid pass-through pattern.');
  await page.getByRole('button', { name: 'Save notes', exact: true }).click();
  await expect(page.getByText('Analyst notes saved')).toBeVisible();
  await page.reload();
  await expect(page.getByRole('textbox', { name: 'Investigator notes' })).toHaveValue(
    'Verified synthetic evidence. Follow up on the rapid pass-through pattern.',
  );
  await page.getByRole('button', { name: 'Escalate case', exact: true }).click();
  await expect(page.getByRole('combobox', { name: 'Case status', exact: true })).toHaveValue(
    'escalated',
  );
  await page
    .getByRole('combobox', { name: 'Recommended action', exact: true })
    .selectOption('Monitor');
  await page.getByRole('button', { name: 'Record recommendation', exact: true }).click();
  await expect(page.getByText('Review recommendation recorded')).toBeVisible();
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Download report', exact: true }).click();
  const download = await downloadPromise;
  expect(download.suggestedFilename()).toBe(`${caseId}-MuleHunter.pdf`);
  const report = await request.get(`/api/investigation/${caseId}/report`);
  expect((await report.body()).subarray(0, 5).toString()).toBe('%PDF-');
});

test('manual analysis persists a payment and the lab reset requires confirmation', async ({
  page,
  request,
}) => {
  const before = await (await request.get('/api/dashboard')).json();
  await page.goto('/simulation');
  await page.getByRole('combobox', { name: 'Manual transaction sender' }).selectOption(accountId);
  await page
    .getByRole('combobox', { name: 'Manual transaction receiver' })
    .selectOption(secondAccountId);
  await page.getByRole('button', { name: 'Analyze & ingest' }).click();
  await expect(page.locator('.manual-result')).toBeVisible();
  const after = await (await request.get('/api/dashboard')).json();
  expect(after.total_transactions).toBe(before.total_transactions + 1);
  await page.getByRole('button', { name: /Reset network to baseline/ }).click();
  await expect(page.getByRole('dialog', { name: 'Restore the baseline network?' })).toBeVisible();
  await page.getByRole('button', { name: 'Keep current network' }).click();
  const kept = await (await request.get('/api/dashboard')).json();
  expect(kept.total_transactions).toBe(after.total_transactions);
  await page.getByRole('button', { name: 'Fan-in attack', exact: true }).click();
  await page.getByRole('button', { name: 'Inject pattern', exact: true }).click();
  await expect(page.getByText('Synthetic pattern injected', { exact: true })).toBeVisible();
  const injected = await (await request.get('/api/dashboard')).json();
  expect(injected.total_accounts).toBe(after.total_accounts + 12);
  expect(injected.total_transactions).toBeGreaterThan(after.total_transactions);
});

test('demo attack builds a network, sends a live critical alert and creates evidence', async ({
  page,
  request,
}) => {
  await page.goto('/');
  const before = await (await request.get('/api/dashboard')).json();
  await page.getByRole('button', { name: 'Demo attack', exact: true }).click();
  await expect(page.locator('.attack-progress-card')).toBeVisible();
  await expect(page.locator('.attack-progress-card h3')).toHaveText(
    'Emerging fraud network detected',
    { timeout: 30000 },
  );
  const after = await (await request.get('/api/dashboard')).json();
  expect(after.total_accounts).toBe(before.total_accounts + 12);
  expect(after.active_fraud_networks).toBeGreaterThan(before.active_fraud_networks);
  expect(after.attack_progress.risk_score).toBeGreaterThanOrEqual(81);
  expect(after.attack_progress.ring_id).toBeTruthy();
  await page.getByRole('button', { name: 'Review evidence', exact: true }).click();
  await expect(page.locator('.account-drawer .account-risk-summary .risk-badge')).toHaveText(
    'CRITICAL',
  );
  await page.getByRole('button', { name: 'AI evidence', exact: true }).click();
  await expect(page.locator('.account-drawer .evidence-item').first()).toBeVisible();
});

test('stream start and stop update actual transaction counts', async ({ page, request }) => {
  await page.goto('/');
  const before = await (await request.get('/api/dashboard')).json();
  await page.getByRole('button', { name: 'Resume stream', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Pause stream', exact: true })).toBeVisible();
  await expect
    .poll(async () => (await (await request.get('/api/dashboard')).json()).total_transactions, {
      timeout: 15000,
    })
    .toBeGreaterThan(before.total_transactions);
  await page.getByRole('button', { name: 'Pause stream', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Resume stream', exact: true })).toBeVisible();
  const stopped = await (await request.get('/api/dashboard')).json();
  expect(stopped.stream_running).toBe(false);
});

test('mobile navigation and landing page remain usable without horizontal overflow', async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/');
  await page.getByRole('button', { name: 'Open navigation' }).click();
  await page.getByRole('link', { name: 'Simulation lab LAB' }).click();
  await expect(page).toHaveURL(/simulation$/);
  await expect(
    page.getByRole('heading', { name: 'Build the threat. Test the defense.' }),
  ).toBeVisible();
  expect(await page.evaluate(() => document.body.scrollWidth <= window.innerWidth)).toBe(true);
  await page.goto('/welcome');
  await expect(page.getByRole('heading', { name: 'MuleHunter AI.' })).toBeVisible();
  await page.getByRole('button', { name: 'Start monitoring' }).click();
  await expect(page.getByRole('heading', { name: 'Fraud command center.' })).toBeVisible();
  expect(await page.evaluate(() => document.body.scrollWidth <= window.innerWidth)).toBe(true);
});
